/* Холст — the clipper (v2.17).
   A page card first (cover, site, author, date, reading time), then: what to take, where,
   as what, linked to what, importance 1–11, the network. One style for every choice. */
const $ = s => document.querySelector(s);
const bg = (op, data) => chrome.runtime.sendMessage({ to: 'bg', op, data });
const esc = s => String(s || '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const ymd = n => { const d = new Date(Date.now() + n * 864e5); return d.toISOString().slice(0, 10); };
const tmo = (p, ms) => Promise.race([p, new Promise(r => setTimeout(() => r(null), ms))]);
/* ---------- the choices ---------- */
const TAKE = [['url', 'Ссылка', 'link', 'Закладка: ссылка и карточка страницы — обложка, сайт, автор, дата'], ['art', 'Текст статьи', 'article', 'Основной текст страницы — без меню и рекламы'], ['sel', 'Выделенное', 'sel', 'Выделенный на странице текст'], ['desc', 'Описание', 'desc', 'Краткое описание страницы'], ['vis', 'Снимок экрана', 'shot', 'Снимок видимой части'], ['full', 'Вся страница', 'full', 'Снимок всей страницы — прокруткой'], ['area', 'Область', 'area', 'Выделите мышью часть страницы — снимок только её']];
const TAKEYT = [['chap', 'Главы', 'chapters', 'Главы видео — в карточку на доске и в запись']];
const SNAP = ['vis', 'full', 'area'];
const WHERE = [['lo', 'Задачник', 'tasks', 'Запись в Life OS — задача, заметка, материал, проект…'], ['board', 'Доска', 'board', 'На доску — карточкой, обложкой, строкой или содержимым'], ['kb', 'Источники', 'book', 'В базу знаний: расшифровка, цитаты, советник']];
const VIEW = [['card', 'Карточка'], ['cover', 'Обложка'], ['compact', 'Строка'], ['live', 'Содержимое']];
const EKDEF = [['task', 'Задача'], ['note', 'Заметка'], ['resource', 'Материал'], ['project', 'Проект'], ['goal', 'Цель'], ['epic', 'Эпик'], ['habit', 'Привычка'], ['area', 'Сфера'], ['vision', 'Видение'], ['metric', 'Метрика']];
const AIO = [['tag', 'Тэгинг', 'tag', 'Ярлыки, связи, статус, действие — по правилам вашей системы'], ['form', 'Форминг', 'form', 'В какой форме это жить: задачи, конспект, материал, проект…'], ['rank', 'Ранкинг', 'rank', 'Вес — насколько это важно вам сейчас, и доверие'], ['sum', 'Конспект', 'note', 'Главное страницы — отдельной заметкой, связанной с ней'], ['tasks', 'Задачи из страницы', 'split', 'Раздробить на задачи — на согласование'], ['kb', 'В источники', 'book', 'Страница — в базу знаний: как истина или как акценты']];
const KBM = [['truth', 'Как истина', 'truth', 'Источнику доверяю: факты и ответы строятся на нём'], ['acc', 'Как акценты', 'acc', 'Ценен не как истина, а тем, что подсвечивает аспекты и нюансы']];
const DUE = [['', 'Нет'], ['0', 'Сегодня'], ['1', 'Завтра'], ['7', 'Через неделю']];
const TYPES = { article: 'статья', 'video.other': 'видео', video: 'видео', 'video.movie': 'фильм', product: 'товар', book: 'книга', profile: 'профиль', 'music.song': 'музыка', recipe: 'рецепт', event: 'событие', course: 'курс', newsarticle: 'новость', blogposting: 'пост', videoobject: 'видео' };
/* ---------- state ---------- */
const ST = { take: new Set(['url']), where: new Set(['lo']), view: 'card', ek: 'task', rel: [], imp: '', due: '', ai: new Set(), kbm: 'truth', P: {}, ping: null, cat: null, dup: [], siteMem: true };
let tab, host = '';
/* ---------- drawing the choices — one style for all ---------- */
const chip = (k, l, ic, t, on, cls) => `<button class="chip${on ? ' on' : ''}${cls ? ' ' + cls : ''}" data-k="${esc(k)}" aria-pressed="${on ? 'true' : 'false'}"${t ? ` title="${esc(t)}"` : ''}>${ic ? hi(ic) : ''}<span>${esc(l)}</span></button>`;
function drawTake() {
  const L = TAKE.concat(ST.P.yt ? TAKEYT : []).filter(([k]) => !(k === 'sel' && !ST.P.sel) && !(k === 'art' && !ST.P.words && !ST.P.yt) && !(k === 'desc' && !ST.P.desc));
  $('#take').innerHTML = L.map(([k, l, ic, t]) => chip(k, k === 'sel' ? `${l} · ${ST.P.sel.length > 999 ? Math.round(ST.P.sel.length / 1000) + ' тыс.' : ST.P.sel.length} симв.` : k === 'art' && ST.P.words ? `${l} · ${Math.max(1, Math.round(ST.P.words / 180))} мин` : l, ic, t, ST.take.has(k))).join('');
}
function drawWhere() {
  $('#where').innerHTML = WHERE.map(([k, l, ic, t]) => chip(k, l, ic, t, ST.where.has(k))).join('');
  $('#boardOpts').hidden = !ST.where.has('board'); $('#asBlk').hidden = !ST.where.has('lo');
  $('#view').innerHTML = VIEW.map(([k, l]) => `<button class="${ST.view === k ? 'on' : ''}" data-k="${k}" aria-pressed="${ST.view === k}">${l}</button>`).join('');
  $('#dueRow').hidden = !(ST.where.has('lo') && ST.ek === 'task');
}
const ix = k => { const i = EKDEF.findIndex(x => x[0] === k); return i < 0 ? 99 : i; };
function drawEk() { const L = (ST.ping && ST.ping.kinds ? ST.ping.kinds.map(x => [x.k, x.l]) : EKDEF).sort((a, b) => ix(a[0]) - ix(b[0])); $('#ek').innerHTML = L.map(([k, l]) => chip(k, l, '', '', ST.ek === k, 'k-' + k)).join(''); $('#dueRow').hidden = !(ST.where.has('lo') && ST.ek === 'task'); }
function drawImp() { $('#imp').innerHTML = Array.from({ length: 11 }, (_, i) => String(i + 1)).map(v => `<button class="${ST.imp === v ? 'on' : ''}${v === '11' ? ' x11' : ''}" data-k="${v}" aria-pressed="${ST.imp === v}" title="${v === '11' ? 'Исключительный случай' : 'Важность ' + v + ' из 10'}">${v}</button>`).join(''); propsSum(); }
function drawDue() { $('#due').innerHTML = DUE.map(([k, l]) => `<button class="${ST.due === k ? 'on' : ''}" data-k="${k}" aria-pressed="${ST.due === k}">${l}</button>`).join(''); }
function propsSum() { const t = [ST.imp ? 'важность ' + ST.imp : '', ST.where.has('lo') && ST.ek === 'task' && (ST.due || $('#dueD').value) ? 'срок' : '', $('#tags').value.trim() ? 'метки' : ''].filter(Boolean); $('#propsSum').textContent = t.join(' · '); }
function drawAi() {
  $('#aiOpts').innerHTML = AIO.map(([k, l, ic, t]) => chip(k, l, ic, t, k === 'kb' ? ST.where.has('kb') : ST.ai.has(k))).join('');
  $('#kbMode').hidden = !ST.where.has('kb'); $('#kbMode').innerHTML = KBM.map(([k, l, ic, t]) => chip(k, l, ic, t, ST.kbm === k)).join('');
  const n = [...ST.ai].length; $('#aiSum').textContent = n ? 'разберёт: ' + AIO.filter(([k]) => ST.ai.has(k)).map(x => x[1].toLowerCase()).join(', ') : '';
  aiHelp();
}
/* the network list: working first, the personal paid main one, the rest dimmed with the reason */
function drawPick(cur) {
  const A = (ST.ping && ST.ping.ai217) || { list: [], main: '' }, s = $('#aiPick');
  const ok = A.list.filter(x => x.st === 'ok'), bad = A.list.filter(x => x.st !== 'ok');
  s.innerHTML = `<option value="">Сначала бесплатные</option><option value="__main">Личная платная основная${A.main ? ' — ' + esc(A.mainName) : ' — не подключена'}</option>${ok.map(x => `<option value="${esc(x.p)}">${esc(x.l)}</option>`).join('')}${bad.length ? `<optgroup label="Не работают сейчас">${bad.map(x => `<option value="${esc(x.p)}" disabled>${esc(x.l)}</option>`).join('')}</optgroup>` : ''}<option value="__set">Подключить ещё нейросети…</option>`;
  s.value = [...s.options].some(o => o.value === cur && !o.disabled) ? cur : '';
}
function aiHelp() {
  const A = (ST.ping && ST.ping.ai217) || {}, h = $('#aiHelp'), v = $('#aiPick').value;
  if (v !== '__main' || A.main) { h.hidden = true; return; }
  h.hidden = false;
  h.innerHTML = `<b>Своя платная нейросеть ещё не подключена</b>
    <ol><li>Возьмите ключ API — подписка ChatGPT Plus или Claude Pro ключа не даёт, нужен ключ с балансом (обычно хватает $5 надолго):
      <ul><li><b>ChatGPT</b> — <code>platform.openai.com/api-keys</code> → «Create new secret key», баланс — «Billing».</li><li><b>Claude</b> — <code>console.anthropic.com</code> → «API Keys» → «Create Key», баланс — «Billing».</li><li><b>Gemini</b> — <code>aistudio.google.com/apikey</code>, платный уровень — включить оплату в Google Cloud.</li></ul></li>
      <li>В Холсте: <code>Меню</code> → <code>Нейросети</code> → нужная → вставьте ключ → <code>Выбрать</code>.</li>
      <li>Здесь: блок <code>Нейросеть</code> → «Личная платная основная» → отметьте, что сделать: тэгинг, форминг, ранкинг, конспект, в источники → <code>Сохранить в Холст</code>.</li>
      <li>Результат — фиолетовым, на согласование: в Холсте кнопка со скрепкой на панели функций.</li></ol>
    <button class="ob" id="aiSet">${hi('open')}<span>Открыть нейросети в Холсте</span></button>`;
  $('#aiSet').addEventListener('click', () => { bg('open', { ai: 1 }); window.close(); });
}
/* ---------- the page card ---------- */
function drawCard() {
  const P = ST.P, Y = P.yt;
  const img = Y ? Y.thumb : P.ytch ? P.ytch.chAv : P.img;
  $('#cv').hidden = !img; if (img) { $('#cvImg').src = img; $('#cvImg').onerror = () => { $('#cv').hidden = true; }; }
  $('#cvDur').hidden = !(Y && Y.dur); if (Y && Y.dur) $('#cvDur').textContent = dur(Y.dur);
  const fav = Y ? Y.chAv : P.ytch ? '' : P.fav; $('#fav').hidden = !fav; if (fav) { $('#fav').src = fav; $('#fav').className = Y ? 'av' : ''; $('#fav').onerror = () => { $('#fav').hidden = true; }; }
  $('#site').textContent = Y ? (Y.ch || 'YouTube') : P.ytch ? P.ytch.ch : P.site || host;
  const meta = Y ? [Y.views ? num(Y.views) + ' просмотров' : '', Y.date ? when(Y.date) : '', Y.chapters && Y.chapters.length ? Y.chapters.length + ' глав' : ''] : [P.author, P.date ? when(P.date) : '', P.words > 150 ? Math.max(1, Math.round(P.words / 180)) + ' мин чтения' : '', typeName(P.type)];
  $('#meta').textContent = meta.filter(Boolean).join(' · ');
}
const num = n => (n >= 1e6 ? (n / 1e6).toFixed(n >= 1e7 ? 0 : 1).replace('.', ',') + ' млн' : n >= 1e3 ? Math.round(n / 1e3) + ' тыс.' : String(n));
const dur = s => { const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0'); };
const when = d => { const t = Date.parse(d); return t ? new Date(t).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short', year: 'numeric' }) : ''; };
const typeName = t => TYPES[String(t || '').toLowerCase()] || '';
function metaOut() {
  const P = ST.P, Y = P.yt;
  if (Y) return { yt: 1, id: Y.id, thumb: Y.thumb, ch: Y.ch, chUrl: Y.chUrl, chAv: Y.chAv, dur: Y.dur, views: Y.views, date: Y.date, chapters: ST.take.has('chap') ? Y.chapters : [], desc: (Y.desc || '').slice(0, 600) };
  if (P.ytch) return { img: P.ytch.banner || P.ytch.chAv, fav: P.ytch.chAv, site: P.ytch.ch, type: 'канал YouTube', desc: P.desc };
  return { img: P.img, fav: P.fav, site: P.site, author: P.author, date: P.date, read: P.words > 150 ? Math.max(1, Math.round(P.words / 180)) : 0, type: typeName(P.type), desc: (P.desc || '').slice(0, 400) };
}
/* ---------- «Связать»: search over the whole structure ---------- */
async function relLoad() { if (ST.cat) return ST.cat; const r = await tmo(bg('rel').catch(() => null), 6000); ST.cat = r && r.ok ? r.data || [] : []; return ST.cat; }
function relFind(id) { for (const c of ST.cat || []) { const x = c.items.find(i => i.id === id); if (x) return Object.assign({ c: c.c, cl: c.l }, x); } return null; }
function drawRelOn() { $('#relOn').innerHTML = ST.rel.map(id => { const x = relFind(id) || { t: id, c: '' }; return `<span class="chip on relc c-${esc(x.c)}" title="${esc(x.cl ? x.cl + (x.p ? ' · ' + x.p : '') : '')}"><span>${esc(x.t)}</span><button data-un="${esc(id)}" title="Убрать связь" aria-label="Убрать связь">${hi('close')}</button></span>`; }).join(''); }
async function drawRelList() {
  const q = $('#relQ').value.trim().toLowerCase(), box = $('#relList'), cat = await relLoad();
  const hit = x => !q || (x.t + ' ' + (x.p || '')).toLowerCase().includes(q);
  const groups = cat.map(c => [c, c.items.filter(x => hit(x) && !ST.rel.includes(x.id)).slice(0, q ? 8 : 4)]).filter(([, l]) => l.length);
  box.hidden = false;
  box.innerHTML = groups.length ? groups.map(([c, l]) => `<div class="rg"><div class="rgh">${esc(c.l)}</div>${l.map(x => `<button class="ri c-${esc(c.c)}" data-rel="${esc(x.id)}"><span>${esc(x.t)}</span>${x.p ? `<small>${esc(x.p)}</small>` : ''}</button>`).join('')}</div>`).join('') : `<div class="rgh">${cat.length ? 'Ничего не нашлось' : 'Холст не ответил — связать можно будет в нём'}</div>`;
}
/* ---------- doubles: where exactly — open it ---------- */
function drawDup() {
  const L = ST.dup || [], d = $('#dup'); if (!L.length) { d.hidden = true; $('#go').textContent = 'Сохранить в Холст'; return; }
  d.hidden = false;
  d.innerHTML = `<b>Эта страница уже есть в Холсте</b><div class="dl">${L.slice(0, 6).map((x, i) => `<div class="dr"><span><small>${esc(x.where)}</small>${esc(x.t)}</span>${x.b ? `<button class="ob sm" data-dup="${i}" title="Открыть этот объект на его доске">${hi('open')}<span>На доске</span></button>` : x.id ? `<button class="ob sm" data-dup="${i}" title="Показать на этой странице виджет со всем, что о ней в задачнике">${hi('widget')}<span>Виджет страницы</span></button>` : x.kb ? `<button class="ob sm" data-dup="${i}" title="Открыть в Источниках">${hi('open')}<span>Открыть</span></button>` : ''}</div>`).join('')}</div><p class="hint">Сохранить ещё раз можно — получится вторая копия.</p>`;
  $('#go').textContent = 'Сохранить вторую копию';
}
async function openDup(x) {
  if (x.b) { await bg('open', { b: x.b, i: x.i }); window.close(); return; }
  if (x.kb) { await bg('open', { kb: x.kb }); window.close(); return; }
  if (x.id) { const W = (await chrome.storage.local.get('widgets')).widgets || {}; W['page:' + tab.url] = Object.assign({}, W['page:' + tab.url] || {}, { on: 1, mode: 'page', scope: 'page' }); await chrome.storage.local.set({ widgets: W }); await chrome.tabs.sendMessage(tab.id, { op: 'widget-refresh' }).catch(() => chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['widget.js'] }).catch(() => {})); window.close(); }
}
/* ---------- the page: what is on it (runs inside the page) ---------- */
function pageInfo() {
  const q = s => document.querySelector(s), m = n => ((q(`meta[property="${n}"]`) || q(`meta[name="${n}"]`) || {}).content || '').trim();
  const abs = u => { try { return u ? new URL(u, location.href).href : ''; } catch (e) { return ''; } };
  const ld = []; for (const s of document.querySelectorAll('script[type="application/ld+json"]')) { try { const add = x => { if (!x) return; if (Array.isArray(x)) x.forEach(add); else { ld.push(x); if (x['@graph']) add(x['@graph']); } }; add(JSON.parse(s.textContent)); } catch (e) { /* broken JSON-LD */ } }
  const tp = x => [].concat(x['@type'] || []).join(' ');
  const L = ld.find(x => /Article|Posting|VideoObject|Product|Recipe|Book|Course|Event/.test(tp(x))) || {};
  const nm = a => (typeof a === 'string' ? a : Array.isArray(a) ? a.map(nm).filter(Boolean).join(', ') : (a && a.name) || '');
  const imgOf = x => (typeof x === 'string' ? x : Array.isArray(x) ? imgOf(x[0]) : (x && (x.url || x.contentUrl)) || '');
  let best = null, bestN = 0; const score = el => [...el.querySelectorAll('p, li')].reduce((s, p) => s + (p.innerText || '').length, 0);
  for (const c of document.querySelectorAll('article, main, [role=main], .post-content, .entry-content, .article-body, .article__body, .post, #content')) { const n = score(c); if (n > bestN) { best = c; bestN = n; } }
  if (!best || bestN < 400) { const par = new Map(); for (const p of document.querySelectorAll('p')) { const e = p.parentElement; par.set(e, (par.get(e) || 0) + (p.innerText || '').length); } for (const [e, n] of par) if (n > bestN) { best = e; bestN = n; } }
  const text = best ? (best.innerText || '').replace(/\n{3,}/g, '\n\n').trim().slice(0, 60000) : '', words = text ? text.split(/\s+/).length : 0;
  const sel = String(getSelection() || '').trim(); let selHtml = '';
  if (sel) { try { const c = document.createElement('div'); c.appendChild(getSelection().getRangeAt(0).cloneContents()); selHtml = c.innerHTML; } catch (e) { /* plain text is enough */ } }
  const ico = q('link[rel~="icon"][sizes="32x32"], link[rel~="icon"][sizes="64x64"], link[rel="apple-touch-icon"], link[rel~="icon"]');
  const res = { title: m('og:title') || document.title, desc: m('og:description') || m('description') || L.description || '', img: abs(m('og:image') || m('twitter:image') || imgOf(L.image)), site: m('og:site_name') || location.hostname.replace(/^www\./, ''), fav: ico ? abs(ico.getAttribute('href')) : location.origin + '/favicon.ico', author: m('author') || m('article:author') || nm(L.author), date: m('article:published_time') || L.datePublished || L.uploadDate || '', type: m('og:type') || tp(L).split(' ')[0] || '', text, words, sel, selHtml };
  const yid = (location.href.match(/[?&]v=([\w-]{11})/) || location.pathname.match(/\/shorts\/([\w-]{11})/) || [])[1];
  const isYt = /(^|\.)youtube\.com$/.test(location.hostname) || !!document.querySelector('#movie_player');
  if (isYt && yid) {
    const V = ld.find(x => tp(x).includes('VideoObject')) || {}, iso = String(V.duration || ''), dm = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/), vEl = q('video');
    const dur = dm && (dm[1] || dm[2] || dm[3]) ? (+dm[1] || 0) * 3600 + (+dm[2] || 0) * 60 + (+dm[3] || 0) : vEl && isFinite(vEl.duration) ? Math.round(vEl.duration) : 0;
    const chA = q('#owner #channel-name a, ytd-video-owner-renderer #channel-name a, ytd-channel-name a'), av = q('#owner #avatar img, ytd-video-owner-renderer #avatar img, ytd-video-owner-renderer img');
    const dEl = q('#description-inline-expander, ytd-text-inline-expander, #description'), dtext = (dEl && dEl.innerText) || V.description || '';
    const ch = []; for (const line of String(dtext).split('\n')) { const mm = line.match(/^\s*((?:\d{1,2}:)?\d{1,2}:\d{2})\s*[-–—:|]?\s*(.{2,90})$/); if (mm) ch.push({ s: mm[1].split(':').map(Number).reduce((a, b) => a * 60 + b, 0), t: mm[2].trim() }); }
    const ist = [].concat(V.interactionStatistic || [])[0], h1 = q('h1.ytd-watch-metadata yt-formatted-string, h1.ytd-watch-metadata');
    res.yt = { id: yid, thumb: 'https://i.ytimg.com/vi/' + yid + '/hqdefault.jpg', ch: chA ? chA.textContent.trim() : nm(V.author), chUrl: chA ? chA.href : '', chAv: av ? av.currentSrc || av.src || '' : '', dur, views: +(V.interactionCount || (ist && ist.userInteractionCount) || 0), date: V.uploadDate || V.datePublished || '', chapters: ch.length >= 2 && ch[0].s === 0 ? ch.slice(0, 60) : [], desc: String(dtext).slice(0, 3000) };
    if (h1 && h1.textContent.trim()) res.title = h1.textContent.trim(); if (res.yt.desc) res.desc = res.yt.desc.slice(0, 400);
  } else if (/(^|\.)youtube\.com$/.test(location.hostname) && /^\/(@|channel\/|c\/|user\/)/.test(location.pathname)) {
    const av = q('yt-page-header-renderer yt-avatar-shape img, #channel-header #avatar img, yt-decorated-avatar-view-model img'), n = q('yt-page-header-renderer h1, #channel-header #channel-name, yt-dynamic-text-view-model h1');
    res.ytch = { chAv: av ? av.currentSrc || av.src || '' : '', ch: n ? n.textContent.trim() : res.site, banner: res.img };
  }
  return res;
}
/* ---------- start ---------- */
(async () => {
  hiFill();
  $('.logo').innerHTML = hi('logo');
  const forced = +new URLSearchParams(location.search).get('tab'); /* the clipper for a given tab — also used by the tests */
  [tab] = forced ? [await chrome.tabs.get(forced)] : await chrome.tabs.query({ active: true, currentWindow: true });
  try { host = new URL(tab.url).hostname; } catch (e) { host = ''; }
  $('#title').value = tab.title || tab.url;
  try { const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: pageInfo }); ST.P = (r && r.result) || {}; } catch (e) { ST.P = {}; }
  if (ST.P.title) $('#title').value = ST.P.title;
  const st = await chrome.storage.local.get(['holstUrl', 'widgets', 'last', 'sites', 'queue', 'siteMem']);
  $('#hurl').value = st.holstUrl || 'https://podkindmitry.github.io/holst/';
  ST.siteMem = st.siteMem !== false; $('#siteMem').checked = ST.siteMem;
  const L = st.last || {}, R = (ST.siteMem && st.sites && st.sites[host]) || {};
  const pick = o => { if (o.take) ST.take = new Set(o.take.filter(k => !SNAP.includes(k) || k === 'vis' || k === 'full')); if (o.where) ST.where = new Set(o.where); if (o.ek) ST.ek = o.ek; if (o.view) ST.view = o.view; if (o.ai) ST.ai = new Set(o.ai); if (o.kbm) ST.kbm = o.kbm; };
  pick(L); pick(R);
  if (ST.P.sel) ST.take.add('sel'); if (ST.P.yt) ST.take.add('chap');
  if (!ST.where.size) ST.where.add('lo');
  drawCard(); drawTake(); drawWhere(); drawEk(); drawImp(); drawDue(); drawAi(); drawPick(L.aiPick || '');
  if (ST.ai.size) $('#aiBlk').open = true;
  const q = (st.queue || []).length; if (q) { $('#q').hidden = false; $('#q').textContent = `В очереди: ${q} — уйдут, когда откроется Холст`; }
  /* the widget part of the settings */
  const W = st.widgets || {}, rule = W['page:' + tab.url] || W['site:' + host];
  $('#wgOn').checked = !!(rule && rule.on); segSimple('#wgScope', [['site', 'На всём сайте'], ['page', 'Только эта страница']], (rule && rule.scope) || 'site'); segSimple('#wgMode', [['page', 'Об этой странице'], ['all', 'Весь задачник']], (rule && rule.mode) || 'page');
  $('#ver').textContent = 'Расширение ' + chrome.runtime.getManifest().version + '. Обновить: в Холсте шапочка → «Устройства» → «Обновить расширение» — одной кнопкой, виджеты и настройки сохранятся.';
  /* Холст */
  const ping = await tmo(bg('ping').catch(() => null), 5000), P = ping && ping.ok ? ping.data : null; ST.ping = P;
  $('#st').textContent = P ? 'Холст ' + P.v + (P.board ? ' · ' + P.board.name : '') : 'Холст закрыт — сохраню в очередь';
  $('#st').classList.toggle('off', !P);
  if (P) { drawEk(); drawPick(L.aiPick || ''); aiHelp(); }
  const [bd, dup] = await Promise.all([tmo(bg('boards').catch(() => null), 5000), tmo(bg('dup', { url: tab.url }).catch(() => null), 5000)]);
  if (bd && bd.ok) for (const b of bd.data) if (!P || !P.board || b.id !== P.board.id) opt('#board', b.id, b.n);
  if (L.board) $('#board').value = L.board;
  if (dup && dup.ok && dup.data) { ST.dup = dup.data; drawDup(); }
  frames();
  relLoad().then(() => drawRelOn());
})();
const opt = (sel, v, t) => { const o = document.createElement('option'); o.value = v; o.textContent = t; $(sel).appendChild(o); };
function segSimple(sel, L, cur) { const b = $(sel); b.dataset.v = cur; b.innerHTML = L.map(([k, l]) => `<button class="${k === cur ? 'on' : ''}" data-k="${k}" aria-pressed="${k === cur}">${l}</button>`).join(''); }
async function frames() { const f = $('#frame'); f.innerHTML = '<option value="">Центр экрана</option>'; const r = await tmo(bg('frames', { board: $('#board').value }).catch(() => null), 5000); if (r && r.ok) for (const x of r.data) opt('#frame', x.id, x.t); }
/* ---------- the clicks ---------- */
document.addEventListener('click', e => {
  const b = e.target.closest('button'); if (!b) return;
  const box = b.parentElement && b.parentElement.id, k = b.dataset.k;
  if (box === 'take') { if (ST.take.has(k)) ST.take.delete(k); else { if (SNAP.includes(k)) SNAP.forEach(x => ST.take.delete(x)); ST.take.add(k); } drawTake(); }
  else if (box === 'where') { if (ST.where.has(k) && ST.where.size > 1) ST.where.delete(k); else ST.where.add(k); drawWhere(); drawAi(); }
  else if (box === 'view') { ST.view = k; drawWhere(); }
  else if (box === 'ek') { ST.ek = k; drawEk(); }
  else if (box === 'imp') { ST.imp = ST.imp === k ? '' : k; drawImp(); }
  else if (box === 'due') { ST.due = k; $('#dueD').value = ''; drawDue(); propsSum(); }
  else if (box === 'aiOpts') { if (k === 'kb') { if (ST.where.has('kb')) { if (ST.where.size > 1) ST.where.delete('kb'); } else ST.where.add('kb'); drawWhere(); } else if (ST.ai.has(k)) ST.ai.delete(k); else ST.ai.add(k); drawAi(); }
  else if (box === 'kbMode') { ST.kbm = k; drawAi(); }
  else if (box === 'wgScope' || box === 'wgMode') { segSimple('#' + box, [...b.parentElement.children].map(x => [x.dataset.k, x.textContent]), k); saveWidget(); }
  else if (b.dataset.rel) { ST.rel.push(b.dataset.rel); $('#relQ').value = ''; drawRelOn(); $('#relList').hidden = true; $('#relQ').blur(); }
  else if (b.dataset.un) { ST.rel = ST.rel.filter(x => x !== b.dataset.un); drawRelOn(); }
  else if (b.dataset.dup != null) openDup(ST.dup[+b.dataset.dup]);
  else if (b.id === 'setBtn') { const s = $('#setView').hidden; $('#setView').hidden = !s; $('#mainView').hidden = s; $('footer').hidden = s; b.innerHTML = hi(s ? 'back' : 'gear'); b.title = s ? 'Назад' : 'Настройки расширения'; b.classList.toggle('open', s); }
  else if (b.id === 'tabsAll') tabsAll(b);
});
$('#relQ').addEventListener('focus', drawRelList); $('#relQ').addEventListener('input', drawRelList);
document.addEventListener('pointerdown', e => { if (!e.target.closest('.rel')) $('#relList').hidden = true; });
$('#relQ').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); const f = $('#relList [data-rel]'); if (f) f.click(); } if (e.key === 'Escape') $('#relList').hidden = true; });
$('#board').addEventListener('change', frames);
$('#dueD').addEventListener('change', () => { ST.due = ''; drawDue(); propsSum(); });
$('#tags').addEventListener('input', propsSum);
$('#aiPick').addEventListener('change', e => { if (e.target.value === '__set') { bg('open', { ai: 1 }); window.close(); return; } aiHelp(); });
$('#hurl').addEventListener('change', e => chrome.storage.local.set({ holstUrl: e.target.value.trim() }));
$('#siteMem').addEventListener('change', e => { ST.siteMem = e.target.checked; chrome.storage.local.set({ siteMem: ST.siteMem }); });
$('#wgOn').addEventListener('change', saveWidget);
async function saveWidget() {
  const W = (await chrome.storage.local.get('widgets')).widgets || {}, scope = $('#wgScope').dataset.v || 'site', mode = $('#wgMode').dataset.v || 'page', key = scope === 'page' ? 'page:' + tab.url : 'site:' + host;
  const old = W['page:' + tab.url] || W['site:' + host] || {}; delete W['page:' + tab.url]; delete W['site:' + host];
  if ($('#wgOn').checked) W[key] = Object.assign({}, old, { on: 1, mode, scope });
  await chrome.storage.local.set({ widgets: W }); chrome.tabs.sendMessage(tab.id, { op: 'widget-refresh' }).catch(() => chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['widget.js'] }).catch(() => {}));
}
async function tabsAll(b) {
  const tabs = (await chrome.tabs.query({ currentWindow: true })).filter(t => /^https?:/.test(t.url || '') && !/podkindmitry\.github\.io\/holst/.test(t.url));
  b.disabled = true; b.querySelector('span:last-child').textContent = 'Сохраняю ' + tabs.length + '…';
  const r = await bg('tabs-all', { tabs: tabs.map(t => ({ url: t.url, title: t.title, site: (() => { try { return new URL(t.url).hostname; } catch (e) { return ''; } })() })), rel: ST.rel });
  b.querySelector('span:last-child').textContent = r && r.ok ? `Готово: ${tabs.length}${r.queued ? ' — в очереди' : ''}` : 'Не получилось'; setTimeout(() => window.close(), 1200);
}
/* ---------- the whole page: scroll, take each screen, glue ---------- */
async function fullShot() {
  const run = (func, args) => chrome.scripting.executeScript({ target: { tabId: tab.id }, func, args: args || [] }).then(r => r[0].result);
  const dim = await run(() => { const el = document.scrollingElement || document.documentElement; const s = { y: scrollY, h: Math.min(el.scrollHeight, 16000), vh: innerHeight, w: innerWidth, dpr: devicePixelRatio, sb: el.style.scrollBehavior }; el.style.scrollBehavior = 'auto'; return s; });
  const cv = document.createElement('canvas'); cv.width = Math.round(dim.w * dim.dpr); cv.height = Math.round(dim.h * dim.dpr); const g = cv.getContext('2d');
  for (let y = 0; y < dim.h; y += dim.vh) {
    const at = await run(t => { scrollTo(0, t); if (t > 0) for (const el of document.querySelectorAll('body *')) { const p = getComputedStyle(el).position; if ((p === 'fixed' || p === 'sticky') && !el.dataset.hst) { el.dataset.hst = el.style.visibility || '-'; el.style.visibility = 'hidden'; } } return scrollY; }, [y]);
    await new Promise(r => setTimeout(r, 550));
    const url = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 82 });
    const img = await new Promise((ok, no) => { const m = new Image(); m.onload = () => ok(m); m.onerror = no; m.src = url; });
    g.drawImage(img, 0, Math.round(at * dim.dpr));
    $('#go').textContent = 'Снимаю страницу… ' + Math.min(100, Math.round((y + dim.vh) / dim.h * 100)) + '%';
  }
  await run(s => { for (const el of document.querySelectorAll('[data-hst]')) { el.style.visibility = el.dataset.hst === '-' ? '' : el.dataset.hst; delete el.dataset.hst; } scrollTo(0, s.y); (document.scrollingElement || document.documentElement).style.scrollBehavior = s.sb || ''; }, [dim]);
  const k = Math.min(1, 2400 / cv.width); if (k < 1) { const c2 = document.createElement('canvas'); c2.width = Math.round(cv.width * k); c2.height = Math.round(cv.height * k); c2.getContext('2d').drawImage(cv, 0, 0, c2.width, c2.height); return c2.toDataURL('image/jpeg', 0.82); }
  return cv.toDataURL('image/jpeg', 0.82);
}
/* ---------- save ---------- */
function payload() {
  const P = ST.P, parts = [];
  if (ST.take.has('sel') && P.sel) parts.push(P.sel); if (ST.take.has('desc') && P.desc) parts.push(P.desc); if (ST.take.has('art') && (P.text || (P.yt && P.yt.desc))) parts.push(P.text || P.yt.desc);
  const due = ST.due !== '' ? ymd(+ST.due) : $('#dueD').value || '';
  return { v217: 1, title: $('#title').value.trim() || tab.title, url: tab.url, noEmbed: ST.take.has('url') ? 0 : 1, site: host, text: parts.join('\n\n'), html: ST.take.has('sel') ? P.selHtml || '' : '', desc: P.desc || '', meta: metaOut(), where: { lo: ST.where.has('lo') ? 1 : 0, board: ST.where.has('board') ? 1 : 0, kb: ST.where.has('kb') ? 1 : 0 }, ek: ST.ek, rel: ST.rel.slice(), imp: ST.imp, due: ST.where.has('lo') && ST.ek === 'task' ? due : '', tags: $('#tags').value.split(/\s+/).map(x => x.replace(/^#/, '')).filter(Boolean), intent: $('#intent').value.trim(), board: $('#board').value, frame: $('#frame').value, view: ST.view, ai: { on: ST.ai.size || ST.where.has('kb') ? 1 : 0, tag: ST.ai.has('tag') ? 1 : 0, form: ST.ai.has('form') ? 1 : 0, rank: ST.ai.has('rank') ? 1 : 0, sum: ST.ai.has('sum') ? 1 : 0, tasks: ST.ai.has('tasks') ? 1 : 0, kb: ST.where.has('kb') ? ST.kbm : '', pick: $('#aiPick').value === '__set' ? '' : $('#aiPick').value } };
}
async function remember() {
  const cur = { take: [...ST.take], where: [...ST.where], ek: ST.ek, view: ST.view, ai: [...ST.ai], kbm: ST.kbm };
  const st = await chrome.storage.local.get('sites'), sites = st.sites || {}; if (ST.siteMem && host) sites[host] = cur;
  await chrome.storage.local.set({ last: Object.assign({ aiPick: $('#aiPick').value, board: $('#board').value }, cur), sites });
}
$('#go').addEventListener('click', async () => {
  const b = $('#go'); b.disabled = true; b.textContent = 'Сохраняю…';
  await remember();
  const d = payload();
  if (ST.take.has('area')) { await chrome.storage.local.set({ pending: d }); await bg('area-start', { tabId: tab.id }); window.close(); return; }
  try { if (ST.take.has('vis')) d.image = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 80 }); else if (ST.take.has('full')) d.image = await fullShot(); } catch (e) { /* not allowed on this page */ }
  const r = await bg('clip', d).catch(e => ({ ok: false, data: String(e && e.message || e) }));
  const ok = r && r.ok && r.data && r.data.ok !== false;
  b.textContent = ok ? (r.queued ? 'Холст закрыт — в очереди, уйдёт сам' : 'Сохранено') : 'Не получилось: ' + ((r && r.data) || 'откройте Холст');
  b.classList.toggle('done', !!ok); setTimeout(() => window.close(), ok ? 900 : 4000);
});
