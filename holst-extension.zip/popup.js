const $ = s => document.querySelector(s);
const bg = (op, data) => chrome.runtime.sendMessage({ to: 'bg', op, data });
const seg = (sel, attr, def) => { const box = $(sel); let v = def; box.addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; box.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); v = b.dataset[attr]; box.dispatchEvent(new Event('pick')); }); return () => v; };
const kind = seg('#kind', 'k', 'task'), due = seg('#due', 'd', ''), pr = seg('#pr', 'p', ''), wgScope = seg('#wgScope', 's', 'site'), wgMode = seg('#wgMode', 'm', 'page');
let tab, page = {};
const ymd = n => { const d = new Date(Date.now() + n * 864e5); return d.toISOString().slice(0, 10); };
(async () => {
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  $('#title').value = tab.title || tab.url;
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => {
      const sel = String(getSelection() || ''), m = n => (document.querySelector(`meta[name="${n}"],meta[property="${n}"]`) || {}).content || '';
      const main = document.querySelector('article, main, [role=main]') || document.body;
      return { sel, desc: m('description') || m('og:description'), text: (main.innerText || '').replace(/\n{3,}/g, '\n\n').slice(0, 20000), selHtml: sel ? (() => { const c = document.createElement('div'); c.appendChild(getSelection().getRangeAt(0).cloneContents()); return c.innerHTML; })() : '' };
    } });
    page = r.result || {};
  } catch (e) { page = {}; }
  $('#selN').textContent = page.sel ? `(${page.sel.length} симв.)` : '(нет)'; if (!page.sel) $('#wSel').checked = false;
  const st = await chrome.storage.local.get(['holstUrl', 'widgets', 'last']); $('#hurl').value = st.holstUrl || 'https://podkindmitry.github.io/holst/';
  const host = new URL(tab.url).hostname, W = st.widgets || {}, rule = W['page:' + tab.url] || W['site:' + host];
  if (rule) { $('#wgOn').checked = !!rule.on; }
  const ping = await bg('ping').catch(() => null);
  $('#st').textContent = ping && ping.ok ? 'Холст ' + ping.data.v + (ping.data.board ? ' · ' + ping.data.board.name : '') : 'Холст откроется во вкладке';
  const pj = await bg('projects').catch(() => null);
  if (pj && pj.ok) for (const p of pj.data) { const o = document.createElement('option'); o.value = p.id; o.textContent = p.t; $('#dest').appendChild(o); }
  if (st.last && st.last.dest) $('#dest').value = st.last.dest;
})();
$('#kind').addEventListener('pick', () => { $('#taskOpts').style.display = kind() === 'board' ? 'none' : ''; });
$('#hurl').addEventListener('change', e => chrome.storage.local.set({ holstUrl: e.target.value.trim() }));
$('#go').addEventListener('click', async () => {
  const b = $('#go'); b.disabled = true; b.textContent = 'Отправляю…';
  let image = ''; if ($('#wShot').checked) { try { image = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 80 }); } catch (e) { /* not allowed here */ } }
  const parts = []; if ($('#wSel').checked && page.sel) parts.push(page.sel); if ($('#wDesc').checked && page.desc) parts.push(page.desc); if ($('#wText').checked && page.text) parts.push(page.text);
  const d = due(), base = { title: $('#title').value.trim() || tab.title, url: $('#wUrl').checked ? tab.url : '', text: parts.join('\n\n'), html: $('#wSel').checked ? page.selHtml : '', site: new URL(tab.url).hostname };
  const task = Object.assign({ kind: 'task', due: d === '' ? '' : ymd(+d), pr: pr(), tags: $('#tags').value.split(/\s+/).map(x => x.replace(/^#/, '')).filter(Boolean), dest: $('#dest').value }, base);
  const res = [];
  if (kind() !== 'board') res.push(await bg('clip', task));
  if (kind() !== 'task') res.push(await bg('clip', Object.assign({ kind: 'board', image }, base)));
  chrome.storage.local.set({ last: { dest: $('#dest').value } });
  const ok = res.every(r => r && r.ok && r.data && r.data.ok !== false);
  b.textContent = ok ? 'Добавлено ✓' : 'Не получилось: ' + ((res.find(r => !r || !r.ok) || {}).data || 'откройте Холст'); setTimeout(() => window.close(), ok ? 900 : 4000);
});
$('#wgOn').addEventListener('change', saveWidget); $('#wgScope').addEventListener('pick', saveWidget); $('#wgMode').addEventListener('pick', saveWidget);
async function saveWidget() {
  const W = (await chrome.storage.local.get('widgets')).widgets || {}, host = new URL(tab.url).hostname, key = wgScope() === 'page' ? 'page:' + tab.url : 'site:' + host;
  delete W['page:' + tab.url]; delete W['site:' + host];
  if ($('#wgOn').checked) W[key] = Object.assign({ on: 1, mode: wgMode(), scope: wgScope() }, W[key] || {}, { on: 1, mode: wgMode(), scope: wgScope() });
  await chrome.storage.local.set({ widgets: W }); chrome.tabs.sendMessage(tab.id, { op: 'widget-refresh' }).catch(() => {});
}
