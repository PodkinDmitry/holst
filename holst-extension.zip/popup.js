/* Холст — the clipper (v2.18).
   One panel for every way in: the button of the browser, the button in the YouTube player,
   «В Холст» in the ⋮ menu under a video and the list of videos of a page — the same panel
   (inside the page it opens in a frame). What to take: the universal options for any site
   and the options of this site (YouTube: transcript, comments, chapters). Selected options
   are yellow; purple is only for information. */
const $ = s => document.querySelector(s);
const bg = (op, data) => chrome.runtime.sendMessage({ to: 'bg', op, data });
const esc = s => String(s || '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const ymd = n => { const d = new Date(Date.now() + n * 864e5); return d.toISOString().slice(0, 10); };
const tmo = (p, ms) => Promise.race([p, new Promise(r => setTimeout(() => r(null), ms))]);
const QP = new URLSearchParams(location.search), EMB = QP.get('embed') === '1';
const hostOf = u => { try { return new URL(u).hostname; } catch (e) { return ''; } };
/* ---------- errors are shown, never swallowed ---------- */
function showErr(m) { const e = $('#err'); if (!e) return; e.hidden = false; e.textContent = 'Ошибка: ' + m + '. Если повторяется — перезапустите расширение: chrome://extensions → «Холст» → ⟳.'; }
addEventListener('error', e => showErr(e.message || 'неизвестная'));
addEventListener('unhandledrejection', e => showErr(String((e.reason && e.reason.message) || e.reason || 'неизвестная')));
function closeUI() { if (EMB) parent.postMessage({ holst218: 'close' }, '*'); else window.close(); }
async function uiHide(h) { if (!EMB) return; parent.postMessage({ holst218: h ? 'hide' : 'show' }, '*'); if (h) await new Promise(r => setTimeout(r, 160)); }
/* ---------- the choices ---------- */
const TAKEU = [['url', 'Ссылка', 'link', 'Карточка страницы: обложка, сайт, автор, дата'], ['page', 'Текст страницы', 'article', 'Весь текст страницы — без меню и рекламы. На любом сайте'], ['sel', 'Выделенное', 'sel', 'Выделенный на странице текст'], ['desc', 'Описание', 'desc', 'Краткое описание страницы'], ['shot', 'Снимок', 'shot', 'Снимок — экран, вся страница, область или кадр видео']];
const SHOTS = [['vis', 'Экран', 'Видимая часть страницы'], ['full', 'Вся страница', 'Вся страница — прокруткой, в настоящих пропорциях'], ['area', 'Область', 'Выделите мышью часть страницы'], ['frame', 'Кадр видео', 'Текущий кадр видео на странице — с моментом']];
const TAKEYT = [['tr', 'Транскрипт', 'text', 'Текст видео — абзацами, с заголовками по главам. Нельзя менять: это запись источника'], ['cm', 'Комментарии', 'bubble', 'Каждый комментарий — карточкой: автор, дата, лайки; ответы — под ним'], ['chap', 'Главы', 'chapters', 'Главы видео — в карточку и в заголовки транскрипта']];
const WHERE = [['lo', 'Задачник', 'tasks', 'Запись в Life OS — задача, заметка, материал, проект…'], ['board', 'Доска', 'board', 'На доску — блоком источника: карточка, снимки, тексты'], ['kb', 'Источники', 'book', 'В базу знаний: расшифровка, цитаты, советник']];
const PLACE = [['free', 'На свободное место', 'Рядом с тем, что на экране, — ничего не перекрывая'], ['over', 'Поверх доски', 'Блок висит над доской: подвиньте за шесть точек и нажмите «Утвердить»']];
const VIEW = [['card', 'Карточка'], ['cover', 'Обложка'], ['compact', 'Строка'], ['live', 'Содержимое']];
const EKDEF = [['task', 'Задача'], ['note', 'Заметка'], ['resource', 'Материал'], ['project', 'Проект'], ['goal', 'Цель'], ['epic', 'Эпик'], ['habit', 'Привычка'], ['area', 'Сфера'], ['vision', 'Видение'], ['metric', 'Метрика']];
const AIO = [['sum', 'Конспект', 'note', 'Главное — в выбранной форме: в блок на доске и заметкой'], ['ann', 'Разметить', 'mark', 'Ключевые мысли, вопросы, действия — подчёркиванием и заметками на полях, на доске'], ['src', 'Сверить с источниками', 'book', 'Где текст противоречит вашим источникам, где они подтверждают, что добавляют'], ['fact', 'Фактчекинг', 'fact', 'Проверить утверждения — в выбранном режиме'], ['tag', 'Тэгинг', 'tag', 'Ярлыки, связи, статус, действие — по правилам вашей системы'], ['form', 'Форминг', 'form', 'В какой форме это жить: задачи, конспект, материал, проект…'], ['rank', 'Ранкинг', 'rank', 'Вес — насколько это важно вам сейчас, и доверие'], ['tasks', 'Задачи из страницы', 'split', 'Раздробить на задачи — на согласование'], ['kb', 'В источники', 'book', 'Страница — в базу знаний: как истина или как акценты']];
const SUMF = [['tldr', 'Резюме', 'Суть в 5–7 предложениях'], ['thesis', 'Тезисы', 'Главные утверждения списком'], ['chapters', 'По разделам', 'Коротко о каждом разделе'], ['ideas', 'Идеи и цитаты', 'Мысли с дословными цитатами'], ['actions', 'План действий', 'Что сделать — чек-лист'], ['questions', 'Вопросы', 'Для размышления и к автору'], ['gloss', 'Глоссарий', 'Термины и определения'], ['lesson', 'Для урока', 'План занятия'], ['cards', 'Карточки', 'Вопрос — ответ, для повторения'], ['critique', 'Критический разбор', 'Сильные и слабые места']];
const FACTM = [['sci', 'Научный консенсус', 'Метаанализы и обзоры выше отдельных исследований'], ['prof', 'Профсообщество', 'Клинические рекомендации, позиции ассоциаций'], ['fresh', 'Актуальность', 'Не устарели ли данные'], ['logic', 'Логика и манипуляции', 'Ошибки рассуждений, давление на эмоции'], ['num', 'Цифры', 'Правдоподобны ли числа и выводы из них']];
const BOARDAI = ['ann', 'src', 'fact'];
const YSTS = ['новое', 'просмотрено', 'в работе', 'разобрано', 'архив'], YACTS = ['посмотреть', 'законспектировать', 'применить', 'обсудить', 'отложить', 'удалить'];
const KBM = [['truth', 'Как истина', 'truth', 'Источнику доверяю: факты и ответы строятся на нём'], ['acc', 'Как акценты', 'acc', 'Ценен не как истина, а тем, что подсвечивает аспекты и нюансы']];
const DUE = [['', 'Нет'], ['0', 'Сегодня'], ['1', 'Завтра'], ['7', 'Через неделю']];
const TYPES = { article: 'статья', 'video.other': 'видео', video: 'видео', 'video.movie': 'фильм', product: 'товар', book: 'книга', profile: 'профиль', 'music.song': 'музыка', recipe: 'рецепт', event: 'событие', course: 'курс', newsarticle: 'новость', blogposting: 'пост', videoobject: 'видео' };
/* ---------- state ---------- */
const ST = { st216: '', act216: '', take: new Set(['url']), shot: 'vis', where: new Set(['lo']), place: 'free', view: 'card', ek: 'task', rel: [], imp: '', due: '', ai: new Set(), form: 'tldr', fact: 'sci', kbm: 'truth', P: {}, ping: null, cat: null, dup: [], siteMem: true, many: null };
let tab, host = '';
/* ---------- drawing the choices — one style for all ---------- */
const chip = (k, l, ic, t, on, cls) => `<button class="chip${on ? ' on' : ''}${cls ? ' ' + cls : ''}" data-k="${esc(k)}" aria-pressed="${on ? 'true' : 'false'}"${t ? ` title="${esc(t)}"` : ''}>${ic ? hi(ic) : ''}<span>${esc(l)}</span></button>`;
const isYt = () => !!ST.P.yt;
function drawTake() {
  const P = ST.P, rem = !!P.remote;
  const L = TAKEU.filter(([k]) => !(rem && k !== 'url') && !(k === 'sel' && !P.sel) && !(k === 'page' && !P.words) && !(k === 'desc' && !P.desc));
  const lab = (k, l) => k === 'sel' ? `${l} · ${P.sel.length > 999 ? Math.round(P.sel.length / 1000) + ' тыс.' : P.sel.length} симв.` : k === 'page' && P.words ? `${l} · ${Math.max(1, Math.round(P.words / 180))} мин` : k === 'shot' && ST.take.has('shot') ? `${l} · ${(SHOTS.find(s => s[0] === ST.shot) || SHOTS[0])[1].toLowerCase()}` : l;
  $('#take').innerHTML = L.map(([k, l, ic, t]) => chip(k, lab(k, l), ic, t, ST.take.has(k))).join('');
  const sh = SHOTS.filter(([k]) => k !== 'frame' || P.video);
  if (!sh.some(s => s[0] === ST.shot)) ST.shot = 'vis';
  $('#shotSub').hidden = !ST.take.has('shot') || rem; $('#shotSub').innerHTML = sh.map(([k, l, t]) => `<button class="${ST.shot === k ? 'on' : ''}" data-k="${k}" title="${esc(t)}" aria-pressed="${ST.shot === k}">${l}</button>`).join('');
  const Y = isYt() ? TAKEYT.filter(([k]) => !(rem && k !== 'tr') && !(k === 'chap' && !(P.yt.chapters || []).length)) : [];
  $('#siteBlk').hidden = !Y.length; $('#siteH').innerHTML = hi('frame') + '<span>Для YouTube</span>';
  $('#takeSite').innerHTML = Y.map(([k, l, ic, t]) => chip(k, l, ic, t, ST.take.has(k))).join('');
}
function drawYt() {
  const on = isYt() || !!ST.many; $('#ytBlk').hidden = !on; if (!on) return;
  const seg = (L, cur) => L.map(v => `<button class="${cur === v ? 'on' : ''}" data-k="${esc(v)}" aria-pressed="${cur === v}">${esc(v)}</button>`).join('');
  $('#ytSt').innerHTML = seg(YSTS, ST.st216); $('#ytAct').innerHTML = seg(YACTS, ST.act216);
  $('#ytSum').textContent = [ST.st216, ST.act216].filter(Boolean).join(' · ');
}
function drawWhere() {
  $('#where').innerHTML = WHERE.map(([k, l, ic, t]) => chip(k, l, ic, t, ST.where.has(k))).join('');
  $('#boardOpts').hidden = !ST.where.has('board'); $('#asBlk').hidden = !ST.where.has('lo');
  $('#place').innerHTML = PLACE.map(([k, l, t]) => `<button class="${ST.place === k ? 'on' : ''}" data-k="${k}" title="${esc(t)}" aria-pressed="${ST.place === k}">${l}</button>`).join('');
  $('#view').innerHTML = VIEW.map(([k, l]) => `<button class="${ST.view === k ? 'on' : ''}" data-k="${k}" aria-pressed="${ST.view === k}">${l}</button>`).join('');
  $('#dueRow').hidden = !(ST.where.has('lo') && ST.ek === 'task');
}
const ix = k => { const i = EKDEF.findIndex(x => x[0] === k); return i < 0 ? 99 : i; };
function drawEk() { const L = (ST.ping && ST.ping.kinds ? ST.ping.kinds.map(x => [x.k, x.l]) : EKDEF).sort((a, b) => ix(a[0]) - ix(b[0])); $('#ek').innerHTML = L.map(([k, l]) => chip(k, l, '', '', ST.ek === k, 'k-' + k)).join(''); $('#dueRow').hidden = !(ST.where.has('lo') && ST.ek === 'task'); }
function drawImp() { $('#imp').innerHTML = Array.from({ length: 11 }, (_, i) => String(i + 1)).map(v => `<button class="${ST.imp === v ? 'on' : ''}${v === '11' ? ' x11' : ''}" data-k="${v}" aria-pressed="${ST.imp === v}" title="${v === '11' ? 'Исключительный случай' : 'Важность ' + v + ' из 10'}">${v}</button>`).join(''); propsSum(); }
function drawDue() { $('#due').innerHTML = DUE.map(([k, l]) => `<button class="${ST.due === k ? 'on' : ''}" data-k="${k}" aria-pressed="${ST.due === k}">${l}</button>`).join(''); }
function propsSum() { const t = [ST.imp ? 'важность ' + ST.imp : '', ST.where.has('lo') && ST.ek === 'task' && (ST.due || $('#dueD').value) ? 'срок' : '', $('#tags').value.trim() ? 'метки' : ''].filter(Boolean); $('#propsSum').textContent = t.join(' · '); }
function drawAi() {
  const forms = (ST.ping && ST.ping.forms && ST.ping.forms.map(f => [f.k, f.l, f.t])) || SUMF, facts = (ST.ping && ST.ping.facts && ST.ping.facts.map(f => [f.k, f.l, f.t])) || FACTM;
  const many = !!ST.many, L = AIO.filter(([k]) => !many || ['tag', 'kb'].includes(k));
  $('#aiOpts').innerHTML = L.map(([k, l, ic, t]) => chip(k, l, ic, t, k === 'kb' ? ST.where.has('kb') : ST.ai.has(k))).join('');
  $('#sumForms').hidden = !ST.ai.has('sum') || many; $('#sumF').innerHTML = forms.map(([k, l, t]) => chip(k, l, '', t, ST.form === k)).join('');
  $('#factBlk').hidden = !ST.ai.has('fact') || many; $('#factM').innerHTML = facts.map(([k, l, t]) => chip(k, l, '', t, ST.fact === k)).join('');
  $('#kbMode').hidden = !ST.where.has('kb'); $('#kbMode').innerHTML = KBM.map(([k, l, ic, t]) => chip(k, l, ic, t, ST.kbm === k)).join('');
  $('#aiBoardHint').hidden = !BOARDAI.some(k => ST.ai.has(k)) || many;
  $('#aiSum').textContent = ST.ai.size ? 'сделает: ' + AIO.filter(([k]) => ST.ai.has(k)).map(x => x[1].toLowerCase()).join(', ') : '';
  aiHelp();
}
/* the network list: working first, the personal paid main one, the rest dimmed with the reason */
function drawPick(cur) {
  const A = (ST.ping && ST.ping.ai217) || { list: [], main: '' }, s = $('#aiPick');
  const ok = A.list.filter(x => x.st === 'ok'), bad = A.list.filter(x => x.st !== 'ok');
  s.innerHTML = `<option value="">Сначала бесплатные</option><option value="__main">Личная платная основная${A.main ? ' — ' + esc(A.mainName) : ' — не подключена'}</option>${ok.map(x => `<option value="${esc(x.p)}">${esc(x.l)}</option>`).join('')}${bad.length ? `<optgroup label="Не работают сейчас">${bad.map(x => `<option value="${esc(x.p)}" disabled>${esc(x.l)}</option>`).join('')}</optgroup>` : ''}<option value="__set">Подключить ещё нейросети…</option>`;
  s.value = [...s.options].some(o => o.value === cur && !o.disabled) ? cur : '';
}
function aiHelp() {
  const A = (ST.ping && ST.ping.ai217) || {}, h = $('#aiHelp'), v = $('#aiPick').value;
  if (v !== '__main' || A.main) { h.hidden = true; return; }
  h.hidden = false;
  h.innerHTML = `<b>Своя платная нейросеть ещё не подключена</b>
    <ol><li>Возьмите ключ API — подписка ChatGPT Plus или Claude Pro ключа не даёт, нужен ключ с балансом:
      <ul><li><b>ChatGPT</b> — <code>platform.openai.com/api-keys</code>.</li><li><b>Claude</b> — <code>console.anthropic.com</code> → «API Keys».</li><li><b>Gemini</b> — <code>aistudio.google.com/apikey</code>.</li></ul></li>
      <li>В Холсте: <code>Меню</code> → <code>Нейросети</code> → нужная → вставьте ключ → <code>Выбрать</code>.</li>
      <li>Здесь: блок <code>Нейросеть</code> → «Личная платная основная» → отметьте, что сделать: конспект, разметка, сверка, фактчекинг, тэгинг… → <code>Сохранить в Холст</code>.</li>
      <li>Результат — фиолетовым, на согласование: на доске — пометки на полях, в задачнике — кнопка со скрепкой на панели функций.</li></ol>
    <button class="ob" id="aiSet">${hi('open')}<span>Открыть нейросети в Холсте</span></button>`;
  $('#aiSet').addEventListener('click', () => { bg('open', { ai: 1 }); closeUI(); });
}
/* ---------- the page card ---------- */
function drawCard() {
  const P = ST.P, Y = P.yt;
  const img = Y ? Y.thumb : P.ytch ? P.ytch.chAv : P.img;
  $('#cv').hidden = !img; if (img) { $('#cvImg').src = img; $('#cvImg').onerror = () => { $('#cv').hidden = true; }; }
  $('#cvDur').hidden = !(Y && Y.dur); if (Y && Y.dur) $('#cvDur').textContent = dur(Y.dur);
  const fav = Y ? Y.chAv : P.ytch ? '' : P.fav; $('#fav').hidden = !fav; if (fav) { $('#fav').src = fav; $('#fav').className = Y ? 'av' : ''; $('#fav').onerror = () => { $('#fav').hidden = true; }; }
  $('#site').textContent = Y ? (Y.ch || 'YouTube') : P.ytch ? P.ytch.ch : P.site || host;
  const meta = Y ? [Y.views ? num(Y.views) + ' просмотров' : '', Y.date ? when(Y.date) : '', Y.chapters && Y.chapters.length ? Y.chapters.length + ' глав' : ''] : [P.author, P.date ? when(P.date) : '', P.words > 150 ? Math.max(1, Math.round(P.words / 180)) + ' мин чтения' : '', typeName(P.type)];
  $('#meta').textContent = meta.filter(Boolean).join(' · ');
}
const num = n => (n >= 1e6 ? (n / 1e6).toFixed(n >= 1e7 ? 0 : 1).replace('.', ',') + ' млн' : n >= 1e3 ? Math.round(n / 1e3) + ' тыс.' : String(n));
const dur = s => { const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0'); };
const when = d => { const t = Date.parse(d); return t ? new Date(t).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short', year: 'numeric' }) : ''; };
const typeName = t => TYPES[String(t || '').toLowerCase()] || '';
function metaOut() {
  const P = ST.P, Y = P.yt;
  if (Y) return { yt: 1, id: Y.id, thumb: Y.thumb, ch: Y.ch, chUrl: Y.chUrl, chAv: Y.chAv, dur: Y.dur, views: Y.views, date: Y.date, chapters: ST.take.has('chap') || ST.take.has('tr') ? Y.chapters || [] : [], desc: (Y.desc || '').slice(0, 600) };
  if (P.ytch) return { img: P.ytch.banner || P.ytch.chAv, fav: P.ytch.chAv, site: P.ytch.ch, type: 'канал YouTube', desc: P.desc };
  return { img: P.img, fav: P.fav, site: P.site, author: P.author, date: P.date, read: P.words > 150 ? Math.max(1, Math.round(P.words / 180)) : 0, type: typeName(P.type), desc: (P.desc || '').slice(0, 400) };
}
/* ---------- «Связать»: search over the whole structure ---------- */
async function relLoad() { if (ST.cat) return ST.cat; const r = await tmo(bg('rel').catch(() => null), 6000); ST.cat = r && r.ok ? r.data || [] : []; return ST.cat; }
function relFind(id) { for (const c of ST.cat || []) { const x = c.items.find(i => i.id === id); if (x) return Object.assign({ c: c.c, cl: c.l }, x); } return null; }
function drawRelOn() { $('#relOn').innerHTML = ST.rel.map(id => { const x = relFind(id) || { t: id, c: '' }; return `<span class="chip on relc c-${esc(x.c)}" title="${esc(x.cl ? x.cl + (x.p ? ' · ' + x.p : '') : '')}"><span>${esc(x.t)}</span><button data-un="${esc(id)}" title="Убрать связь" aria-label="Убрать связь">${hi('close')}</button></span>`; }).join(''); }
async function drawRelList() {
  const q = $('#relQ').value.trim().toLowerCase(), box = $('#relList'), cat = await relLoad();
  const hit = x => !q || (x.t + ' ' + (x.p || '')).toLowerCase().includes(q);
  const groups = cat.map(c => [c, c.items.filter(x => hit(x) && !ST.rel.includes(x.id)).slice(0, q ? 8 : 4)]).filter(([, l]) => l.length);
  box.hidden = false;
  box.innerHTML = groups.length ? groups.map(([c, l]) => `<div class="rg"><div class="rgh">${esc(c.l)}</div>${l.map(x => `<button class="ri c-${esc(c.c)}" data-rel="${esc(x.id)}"><span>${esc(x.t)}</span>${x.p ? `<small>${esc(x.p)}</small>` : ''}</button>`).join('')}</div>`).join('') : `<div class="rgh">${cat.length ? 'Ничего не нашлось' : 'Холст не ответил — связать можно будет в нём'}</div>`;
}
/* ---------- doubles ---------- */
function drawDup() {
  const L = ST.dup || [], d = $('#dup'); if (!L.length) { d.hidden = true; goLabel(); return; }
  d.hidden = false;
  d.innerHTML = `<b>Эта страница уже есть в Холсте</b><div class="dl">${L.slice(0, 6).map((x, i) => `<div class="dr"><span><small>${esc(x.where)}</small>${esc(x.t)}</span>${x.b ? `<button class="ob sm att${ST.attach && ST.attach.i === x.i ? ' on' : ''}" data-att="${i}" title="Добавить снимок, выделенное и «зачем» к этому объекту на доске">${hi('plus')}<span>Добавить к этому</span></button><button class="ob sm" data-dup="${i}" title="Открыть этот объект на его доске">${hi('open')}<span>На доске</span></button>` : x.id ? `<button class="ob sm" data-dup="${i}" title="Показать на этой странице виджет со всем, что о ней в задачнике">${hi('widget')}<span>Виджет страницы</span></button>` : x.kb ? `<button class="ob sm" data-dup="${i}" title="Открыть в Источниках">${hi('open')}<span>Открыть</span></button>` : ''}</div>`).join('')}</div><p class="hint">Сохранить ещё раз можно — получится вторая копия.</p>`;
  goLabel();
}
function goLabel() { const n = ST.many ? [...document.querySelectorAll('#manyL input:checked')].length : 0; $('#go').textContent = ST.many ? (n ? `Сохранить выбранные · ${n}` : 'Отметьте видео') : ST.attach ? 'Добавить к объекту на доске' : ST.dup && ST.dup.length ? 'Сохранить вторую копию' : 'Сохранить в Холст'; $('#go').disabled = !!ST.many && !n; }
async function openDup(x) {
  if (x.b) { await bg('open', { b: x.b, i: x.i }); closeUI(); return; }
  if (x.kb) { await bg('open', { kb: x.kb }); closeUI(); return; }
  if (x.id) { const W = (await chrome.storage.local.get('widgets')).widgets || {}; W['page:' + tab.url] = Object.assign({}, W['page:' + tab.url] || {}, { on: 1, mode: 'page', scope: 'page' }); await chrome.storage.local.set({ widgets: W }); await chrome.tabs.sendMessage(tab.id, { op: 'widget-refresh' }).catch(() => chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['widget.js'] }).catch(() => {})); closeUI(); }
}
/* ---------- the page: what is on it (runs inside the page) ---------- */
function pageInfo() {
  const q = s => document.querySelector(s), m = n => ((q(`meta[property="${n}"]`) || q(`meta[name="${n}"]`) || {}).content || '').trim();
  const abs = u => { try { return u ? new URL(u, location.href).href : ''; } catch (e) { return ''; } };
  const ld = []; for (const s of document.querySelectorAll('script[type="application/ld+json"]')) { try { const add = x => { if (!x) return; if (Array.isArray(x)) x.forEach(add); else { ld.push(x); if (x['@graph']) add(x['@graph']); } }; add(JSON.parse(s.textContent)); } catch (e) { /* broken JSON-LD */ } }
  const tp = x => [].concat(x['@type'] || []).join(' ');
  const L = ld.find(x => /Article|Posting|VideoObject|Product|Recipe|Book|Course|Event/.test(tp(x))) || {};
  const nm = a => (typeof a === 'string' ? a : Array.isArray(a) ? a.map(nm).filter(Boolean).join(', ') : (a && a.name) || '');
  const imgOf = x => (typeof x === 'string' ? x : Array.isArray(x) ? imgOf(x[0]) : (x && (x.url || x.contentUrl)) || '');
  let best = null, bestN = 0; const score = el => [...el.querySelectorAll('p, li')].reduce((s, p) => s + (p.innerText || '').length, 0);
  for (const c of document.querySelectorAll('article, main, [role=main], .post-content, .entry-content, .article-body, .article__body, .post, #content')) { const n = score(c); if (n > bestN) { best = c; bestN = n; } }
  if (!best || bestN < 400) { const par = new Map(); for (const p of document.querySelectorAll('p')) { const e = p.parentElement; par.set(e, (par.get(e) || 0) + (p.innerText || '').length); } for (const [e, n] of par) if (n > bestN) { best = e; bestN = n; } }
  if (!best && document.body) best = document.body;
  const text = best ? (best.innerText || '').replace(/\n{3,}/g, '\n\n').trim().slice(0, 60000) : '', words = text ? text.split(/\s+/).length : 0;
  const sel = String(getSelection() || '').trim(); let selHtml = '';
  if (sel) { try { const c = document.createElement('div'); c.appendChild(getSelection().getRangeAt(0).cloneContents()); selHtml = c.innerHTML; } catch (e) { /* plain text is enough */ } }
  const ico = q('link[rel~="icon"][sizes="32x32"], link[rel~="icon"][sizes="64x64"], link[rel="apple-touch-icon"], link[rel~="icon"]');
  const vids = [...document.querySelectorAll('video')].filter(v => v.videoWidth && v.getBoundingClientRect().width > 120);
  const res = { title: m('og:title') || document.title, desc: m('og:description') || m('description') || L.description || '', img: abs(m('og:image') || m('twitter:image') || imgOf(L.image)), site: m('og:site_name') || location.hostname.replace(/^www\./, ''), fav: ico ? abs(ico.getAttribute('href')) : location.origin + '/favicon.ico', author: m('author') || m('article:author') || nm(L.author), date: m('article:published_time') || L.datePublished || L.uploadDate || '', type: m('og:type') || tp(L).split(' ')[0] || '', text, words, sel, selHtml, video: vids.length > 0 };
  const yid = (location.href.match(/[?&]v=([\w-]{11})/) || location.pathname.match(/\/shorts\/([\w-]{11})/) || [])[1];
  const isYt = /(^|\.)youtube\.com$/.test(location.hostname) || !!document.querySelector('#movie_player');
  if (isYt && yid) {
    const V = ld.find(x => tp(x).includes('VideoObject')) || {}, iso = String(V.duration || ''), dm = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/), vEl = q('video');
    const dur = dm && (dm[1] || dm[2] || dm[3]) ? (+dm[1] || 0) * 3600 + (+dm[2] || 0) * 60 + (+dm[3] || 0) : vEl && isFinite(vEl.duration) ? Math.round(vEl.duration) : 0;
    const chA = q('#owner #channel-name a, ytd-video-owner-renderer #channel-name a, ytd-channel-name a'), av = q('#owner #avatar img, ytd-video-owner-renderer #avatar img, ytd-video-owner-renderer img');
    const dEl = q('#description-inline-expander, ytd-text-inline-expander, #description'), dtext = (dEl && dEl.innerText) || V.description || '';
    const ch = []; for (const line of String(dtext).split('\n')) { const mm = line.match(/^\s*((?:\d{1,2}:)?\d{1,2}:\d{2})\s*[-–—:|]?\s*(.{2,90})$/); if (mm) ch.push({ s: mm[1].split(':').map(Number).reduce((a, b) => a * 60 + b, 0), t: mm[2].trim() }); }
    const ist = [].concat(V.interactionStatistic || [])[0], h1 = q('h1.ytd-watch-metadata yt-formatted-string, h1.ytd-watch-metadata');
    res.yt = { id: yid, thumb: 'https://i.ytimg.com/vi/' + yid + '/hqdefault.jpg', ch: chA ? chA.textContent.trim() : nm(V.author), chUrl: chA ? chA.href : '', chAv: av ? av.currentSrc || av.src || '' : '', dur, views: +(V.interactionCount || (ist && ist.userInteractionCount) || 0), date: V.uploadDate || V.datePublished || '', chapters: ch.length >= 2 && ch[0].s === 0 ? ch.slice(0, 60) : [], desc: String(dtext).slice(0, 3000) };
    if (h1 && h1.textContent.trim()) res.title = h1.textContent.trim(); if (res.yt.desc) res.desc = res.yt.desc.slice(0, 400);
  } else if (/(^|\.)youtube\.com$/.test(location.hostname) && /^\/(@|channel\/|c\/|user\/)/.test(location.pathname)) {
    const av = q('yt-page-header-renderer yt-avatar-shape img, #channel-header #avatar img, yt-decorated-avatar-view-model img'), n = q('yt-page-header-renderer h1, #channel-header #channel-name, yt-dynamic-text-view-model h1');
    res.ytch = { chAv: av ? av.currentSrc || av.src || '' : '', ch: n ? n.textContent.trim() : res.site, banner: res.img };
  }
  return res;
}
/* YouTube, inside the page (the page's own world): the captions of the player; the transcript panel if they fail */
async function ytTr() {
  const toSegs = ev => (ev || []).filter(e => e && e.segs).map(e => ({ s: (e.tStartMs || 0) / 1000, t: e.segs.map(x => x.utf8 || '').join('').replace(/\n/g, ' ').trim() })).filter(x => x.t);
  try {
    const pl = document.querySelector('#movie_player'), pr = (pl && pl.getPlayerResponse && pl.getPlayerResponse()) || window.ytInitialPlayerResponse;
    const L = (pr && pr.captions && pr.captions.playerCaptionsTracklistRenderer && pr.captions.playerCaptionsTracklistRenderer.captionTracks) || [];
    const T = L.find(t => /^ru/.test(t.languageCode) && t.kind !== 'asr') || L.find(t => t.kind !== 'asr') || L.find(t => /^ru/.test(t.languageCode)) || L[0];
    if (T) { const r = await fetch(T.baseUrl + '&fmt=json3', { credentials: 'include' }), x = await r.text(); if (x && x.trim()[0] === '{') { const segs = toSegs(JSON.parse(x).events); if (segs.length) return { segs, lang: T.languageCode, asr: T.kind === 'asr' }; } }
  } catch (e) { /* the panel next */ }
  const read = () => [...document.querySelectorAll('ytd-transcript-segment-renderer')].map(r => { const ts = ((r.querySelector('.segment-timestamp') || {}).textContent || '').trim(), t = ((r.querySelector('.segment-text') || r.querySelector('yt-formatted-string') || {}).textContent || '').trim(); return { s: ts.split(':').map(Number).reduce((a, b) => a * 60 + b, 0) || 0, t }; }).filter(x => x.t);
  let segs = read(), opened = false;
  if (!segs.length) { const b = document.querySelector('ytd-video-description-transcript-section-renderer button, #primary-button button[aria-label*="ранскрипт"], button[aria-label*="ranscript"]'); if (b) { b.click(); opened = true; for (let i = 0; i < 24 && !segs.length; i++) { await new Promise(r => setTimeout(r, 300)); segs = read(); } } }
  if (opened) { const x = document.querySelector('ytd-engagement-panel-section-list-renderer[target-id*="transcript"] #visibility-button button'); if (x) x.click(); }
  return segs.length ? { segs, lang: '', panel: 1 } : { segs: [], err: 'у видео нет субтитров' };
}
/* comments: what is loaded, a little more by scrolling, the replies opened; the place on the page is returned */
async function ytCm(max, rmax) {
  const y0 = scrollY, box = document.querySelector('ytd-comments#comments') || document.querySelector('#comments'); if (!box) return { list: [], err: 'комментариев на странице нет' };
  const threads = () => [...box.querySelectorAll('ytd-comment-thread-renderer')], wait = ms => new Promise(r => setTimeout(r, ms));
  if (!threads().length) { box.scrollIntoView(); for (let i = 0; i < 30 && !threads().length; i++) await wait(300); }
  for (let k = 0; k < 6 && threads().length && threads().length < max; k++) { const t = threads(); t[t.length - 1].scrollIntoView(); await wait(900); }
  const T = threads().slice(0, max); let n = 0;
  for (const th of T) { const b = th.querySelector('#more-replies button, #more-replies-sub-thread button, ytd-comment-replies-renderer #expander-header button'); if (b && n < 12) { b.click(); n++; } }
  if (n) await wait(1800);
  const oa = document.querySelector('#owner a[href^="/@"], ytd-video-owner-renderer a[href^="/@"]'), handle = oa ? (oa.getAttribute('href') || '').replace(/^\//, '') : '';
  const one = el => { const q = s => el.querySelector(s), a = (((q('#author-text') || {}).textContent) || '').trim(), x = q('#content-text'); return { a, t: (((q('#published-time-text') || {}).textContent) || '').trim(), likes: (((q('#vote-count-middle') || {}).textContent) || '').trim(), text: x ? x.innerText.trim() : '', owner: !!(q('#author-comment-badge ytd-author-comment-badge-renderer') || (handle && a === handle)) }; };
  const main = th => th.querySelector(':scope > #comment, :scope > ytd-comment-view-model, :scope > ytd-comment-renderer') || th;
  const list = T.map(th => Object.assign(one(main(th)), { replies: [...th.querySelectorAll('ytd-comment-replies-renderer ytd-comment-view-model, ytd-comment-replies-renderer ytd-comment-renderer')].slice(0, rmax).map(one).filter(x => x.text) })).filter(x => x.text);
  scrollTo(0, y0);
  return { list };
}
/* the current frame of a video on the page */
function vFrame() {
  const v = [...document.querySelectorAll('video')].filter(x => x.videoWidth).sort((a, b) => b.getBoundingClientRect().width - a.getBoundingClientRect().width)[0];
  if (!v) return { err: 'видео на странице не найдено' };
  const r = v.getBoundingClientRect();
  try { const k = Math.min(1, 1920 / v.videoWidth), c = document.createElement('canvas'); c.width = Math.round(v.videoWidth * k); c.height = Math.round(v.videoHeight * k); c.getContext('2d').drawImage(v, 0, 0, c.width, c.height); return { img: c.toDataURL('image/jpeg', 0.88), at: v.currentTime }; }
  catch (e) { return { at: v.currentTime, rect: { x: r.left, y: r.top, w: r.width, h: r.height, vw: innerWidth } }; }
}
/* ---------- start ---------- */
(async () => {
  try {
    hiFill(); $('.logo').innerHTML = hi('logo');
    if (EMB) { document.body.classList.add('emb'); $('#xBtn').hidden = false; }
    const forced = +QP.get('tab');
    [tab] = forced ? [await chrome.tabs.get(forced)] : await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) throw new Error('не нашёл вкладку');
    host = hostOf(tab.url);
    const st = await chrome.storage.local.get(['holstUrl', 'widgets', 'last', 'sites', 'queue', 'siteMem', 'many218']);
    /* what: one video from a list (⋮), many videos, or this page */
    if (QP.get('vid')) { const id = QP.get('vid'); ST.P = { remote: 1, title: QP.get('vt') || 'Видео ' + id, site: 'YouTube', yt: { id, thumb: 'https://i.ytimg.com/vi/' + id + '/hqdefault.jpg', ch: QP.get('vch') || '', chapters: [] } }; }
    else if (QP.get('many') === '1' && st.many218) { ST.many = (st.many218.videos || []).slice(0, 200); ST.P = { many: 1 }; }
    else { const r = await tmo(chrome.scripting.executeScript({ target: { tabId: tab.id }, func: pageInfo }).catch(e => { throw e; }), 6000).catch(() => null); ST.P = (r && r[0] && r[0].result) || {}; }
    $('#title').value = ST.P.title || tab.title || tab.url;
    $('#hurl').value = st.holstUrl || 'https://podkindmitry.github.io/holst/';
    ST.siteMem = st.siteMem !== false; $('#siteMem').checked = ST.siteMem;
    const L = st.last || {}, R = (ST.siteMem && st.sites && st.sites[host]) || {};
    const pick = o => {
      if (o.take) { const t = new Set(); for (const k of o.take) { if (k === 'art') t.add('page'); else if (['vis', 'full'].includes(k)) { t.add('shot'); ST.shot = k; } else if (k !== 'area') t.add(k); } ST.take = t; }
      if (o.shot && o.shot !== 'area') ST.shot = o.shot; if (o.where) ST.where = new Set(o.where); if (o.ek) ST.ek = o.ek; if (o.view) ST.view = o.view; if (o.place) ST.place = o.place;
      if (o.ai) ST.ai = new Set(o.ai); if (o.kbm) ST.kbm = o.kbm; if (o.form) ST.form = o.form; if (o.fact) ST.fact = o.fact;
    };
    pick(L); pick(R);
    if (ST.P.sel) ST.take.add('sel'); if (ST.P.yt && (ST.P.yt.chapters || []).length) ST.take.add('chap');
    if (!ST.where.size) ST.where.add('lo');
    if (ST.many) drawMany(); else drawCard();
    $('#card').hidden = !!ST.many; $('#takeBlk').hidden = !!ST.many;
    drawTake(); drawWhere(); drawEk(); drawImp(); drawDue(); drawAi(); drawYt(); drawPick(L.aiPick || ''); goLabel();
    if (ST.ai.size) $('#aiBlk').open = true;
    const q = (st.queue || []).length; if (q) { $('#q').hidden = false; $('#q').textContent = `В очереди: ${q} — уйдут, когда откроется Холст`; }
    /* the widget: by default only this page; «Весь задачник» on the left */
    const W = st.widgets || {}, rule = W['page:' + tab.url] || W['site:' + host];
    $('#wgOn').checked = !!(rule && rule.on); segSimple('#wgScope', [['page', 'Только эта страница'], ['site', 'На всём сайте']], (rule && rule.scope) || 'page'); segSimple('#wgMode', [['all', 'Весь задачник'], ['page', 'Об этой странице']], (rule && rule.mode) || 'page');
    $('#ver').textContent = 'Расширение ' + chrome.runtime.getManifest().version + '. Обновить: в Холсте шапочка → «Основы» → «Устройства» → «Обновить расширение» — одной кнопкой, виджеты и настройки сохранятся.';
    tabsDraw().catch(() => {});
    /* Холст */
    const ping = await tmo(bg('ping').catch(() => null), 5000), P = ping && ping.ok ? ping.data : null; ST.ping = P;
    $('#st').textContent = P && !P.cached ? 'Холст ' + P.v + (P.board ? ' · ' + P.board.name : '') : 'Холст закрыт — сохраню в очередь';
    $('#st').classList.toggle('off', !P || !!P.cached);
    route220(P);
    if (P) { drawEk(); drawAi(); drawPick(L.aiPick || ''); aiHelp(); }
    const [bd, dup] = await Promise.all([tmo(bg('boards').catch(() => null), 5000), ST.many ? null : tmo(bg('dup', { url: urlOut() }).catch(() => null), 5000)]);
    if (bd && bd.ok) for (const b of bd.data) if (!P || !P.board || b.id !== P.board.id) opt('#board', b.id, b.n);
    if (L.board) $('#board').value = L.board;
    if (dup && dup.ok && dup.data) { ST.dup = dup.data; drawDup(); }
    frames();
    relLoad().then(() => drawRelOn());
  } catch (e) { showErr(String((e && e.message) || e)); }
})();
const urlOut = () => (ST.P.remote && ST.P.yt ? 'https://www.youtube.com/watch?v=' + ST.P.yt.id : tab.url);
const opt = (sel, v, t) => { const o = document.createElement('option'); o.value = v; o.textContent = t; $(sel).appendChild(o); };
function segSimple(sel, L, cur) { const b = $(sel); b.dataset.v = cur; b.innerHTML = L.map(([k, l]) => `<button class="${k === cur ? 'on' : ''}" data-k="${k}" aria-pressed="${k === cur}">${l}</button>`).join(''); }
async function frames() { const f = $('#frame'); f.innerHTML = '<option value="">Свободное место</option>'; const r = await tmo(bg('frames', { board: $('#board').value }).catch(() => null), 5000); if (r && r.ok) for (const x of r.data) opt('#frame', x.id, x.t); }
function drawMany() {
  const L = ST.many || []; $('#manyBlk').hidden = false; $('#manyN').textContent = '· ' + L.length;
  $('#manyL').innerHTML = L.map((v, i) => `<label class="mi"><input type="checkbox" data-i="${i}" checked><img src="https://i.ytimg.com/vi/${esc(v.id)}/default.jpg" alt=""><span title="${esc(v.title)}">${esc(v.title)}<small>${esc(v.channel || '')}</small></span></label>`).join('') || '<p class="hint">Видео на странице не нашлось — прокрутите список, чтобы они загрузились.</p>';
}
/* ---------- tabs: all, highlighted, the group, this site ---------- */
let TABS = {};
async function tabsDraw() {
  const ok = t => /^https?:/.test(t.url || '') && !/podkindmitry\.github\.io\/holst/.test(t.url);
  const all = (await chrome.tabs.query({ currentWindow: true })).filter(ok), hl = all.filter(t => t.highlighted), grp = tab.groupId != null && tab.groupId >= 0 ? all.filter(t => t.groupId === tab.groupId) : [], site = all.filter(t => hostOf(t.url) === host);
  let gname = ''; try { if (grp.length && chrome.tabGroups) gname = (await chrome.tabGroups.get(tab.groupId)).title || ''; } catch (e) { gname = ''; }
  TABS = { all: [all, 'вкладки'], hl: [hl, 'вкладки'], grp: [grp, gname || 'группа вкладок'], site: [site, host] };
  const B = [['all', 'Все вкладки окна', 'tabs', ''], ['hl', 'Выделенные', 'check', 'Ctrl или Cmd + щелчок по вкладкам — выделить несколько'], ['grp', gname ? `Группа «${gname}»` : 'Группа этой вкладки', 'list', 'Вкладки той же группы, что и эта'], ['site', 'Этот сайт · ' + host.replace(/^www\./, ''), 'page', 'Все открытые вкладки этого сайта']];
  $('#tabsG').innerHTML = B.map(([k, l, ic, t]) => `<button class="ob tabb" data-tabs="${k}"${TABS[k][0].length ? '' : ' disabled'}${t ? ` title="${esc(t)}"` : ''}>${hi(ic)}<span>${esc(l)}</span><b>${TABS[k][0].length}</b></button>`).join('');
}
async function tabsSave(b, k) {
  const [L, tag] = TABS[k] || [[], '']; if (!L.length) return;
  b.disabled = true; const s = b.querySelector('span'); s.textContent = 'Сохраняю ' + L.length + '…';
  const r = await bg('tabs-all', { tabs: L.map(t => ({ url: t.url, title: t.title, site: hostOf(t.url) })), rel: ST.rel, tag });
  s.textContent = r && r.ok ? `Готово: ${L.length}${r.queued ? ' — в очереди' : ''}` : 'Не получилось'; setTimeout(closeUI, 1200);
}
/* ---------- the clicks ---------- */
document.addEventListener('click', e => {
  const b = e.target.closest('button'); if (!b) return;
  const box = b.parentElement && b.parentElement.id, k = b.dataset.k;
  if (box === 'take' || box === 'takeSite') { if (ST.take.has(k)) ST.take.delete(k); else ST.take.add(k); drawTake(); }
  else if (box === 'shotSub') { ST.shot = k; drawTake(); }
  else if (box === 'ytSt') { ST.st216 = ST.st216 === k ? '' : k; drawYt(); }
  else if (box === 'ytAct') { ST.act216 = ST.act216 === k ? '' : k; drawYt(); }
  else if (box === 'where') { if (ST.where.has(k) && ST.where.size > 1) ST.where.delete(k); else ST.where.add(k); if (k === 'board' && !ST.where.has('board')) BOARDAI.forEach(x => ST.ai.delete(x)); drawWhere(); drawAi(); }
  else if (box === 'place') { ST.place = k; drawWhere(); }
  else if (box === 'view') { ST.view = k; drawWhere(); }
  else if (box === 'ek') { ST.ek = k; drawEk(); }
  else if (box === 'imp') { ST.imp = ST.imp === k ? '' : k; drawImp(); }
  else if (box === 'due') { ST.due = k; $('#dueD').value = ''; drawDue(); propsSum(); }
  else if (box === 'aiOpts') { if (k === 'kb') { if (ST.where.has('kb')) { if (ST.where.size > 1) ST.where.delete('kb'); } else ST.where.add('kb'); drawWhere(); } else if (ST.ai.has(k)) ST.ai.delete(k); else { ST.ai.add(k); if (BOARDAI.includes(k) && !ST.where.has('board')) { ST.where.add('board'); drawWhere(); } } drawAi(); }
  else if (box === 'sumF') { ST.form = k; drawAi(); }
  else if (box === 'factM') { ST.fact = k; drawAi(); }
  else if (box === 'kbMode') { ST.kbm = k; drawAi(); }
  else if (box === 'wgScope' || box === 'wgMode') { segSimple('#' + box, [...b.parentElement.children].map(x => [x.dataset.k, x.textContent]), k); saveWidget(); }
  else if (b.dataset.rel) { ST.rel.push(b.dataset.rel); $('#relQ').value = ''; drawRelOn(); $('#relList').hidden = true; $('#relQ').blur(); }
  else if (b.dataset.un) { ST.rel = ST.rel.filter(x => x !== b.dataset.un); drawRelOn(); }
  else if (b.dataset.att != null) { const x = ST.dup[+b.dataset.att]; ST.attach = ST.attach && ST.attach.i === x.i ? null : { b: x.b, i: x.i }; drawDup(); }
  else if (b.dataset.dup != null) openDup(ST.dup[+b.dataset.dup]);
  else if (b.dataset.tabs) tabsSave(b, b.dataset.tabs);
  else if (b.id === 'xBtn') closeUI();
  else if (b.id === 'setBtn') { const s = $('#setView').hidden; $('#setView').hidden = !s; $('#mainView').hidden = s; $('footer').hidden = s; b.innerHTML = hi(s ? 'back' : 'gear'); b.title = s ? 'Назад' : 'Настройки расширения'; b.classList.toggle('open', s); }
});
document.addEventListener('change', e => { if (e.target.closest('#manyL')) goLabel(); if (e.target.id === 'manyAll') { document.querySelectorAll('#manyL input').forEach(c => { c.checked = e.target.checked; }); goLabel(); } });
$('#relQ').addEventListener('focus', drawRelList); $('#relQ').addEventListener('input', drawRelList);
document.addEventListener('pointerdown', e => { if (!e.target.closest('.rel')) $('#relList').hidden = true; });
$('#relQ').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); const f = $('#relList [data-rel]'); if (f) f.click(); } if (e.key === 'Escape') $('#relList').hidden = true; });
document.addEventListener('keydown', e => { if (e.key === 'Escape' && EMB && !e.target.closest('.rel')) closeUI(); });
$('#board').addEventListener('change', frames);
$('#dueD').addEventListener('change', () => { ST.due = ''; drawDue(); propsSum(); });
$('#tags').addEventListener('input', propsSum);
$('#aiPick').addEventListener('change', e => { if (e.target.value === '__set') { bg('open', { ai: 1 }); closeUI(); return; } aiHelp(); });
$('#hurl').addEventListener('change', e => chrome.storage.local.set({ holstUrl: e.target.value.trim() }));
$('#siteMem').addEventListener('change', e => { ST.siteMem = e.target.checked; chrome.storage.local.set({ siteMem: ST.siteMem }); });
$('#wgOn').addEventListener('change', saveWidget);
async function saveWidget() {
  const W = (await chrome.storage.local.get('widgets')).widgets || {}, scope = $('#wgScope').dataset.v || 'page', mode = $('#wgMode').dataset.v || 'page', key = scope === 'page' ? 'page:' + tab.url : 'site:' + host;
  const old = W['page:' + tab.url] || W['site:' + host] || {}; delete W['page:' + tab.url]; delete W['site:' + host];
  if ($('#wgOn').checked) W[key] = Object.assign({}, old, { on: 1, mode, scope });
  await chrome.storage.local.set({ widgets: W }); chrome.tabs.sendMessage(tab.id, { op: 'widget-refresh' }).catch(() => chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['widget.js'] }).catch(() => {}));
}
/* ---------- snapshots ---------- */
const run = (func, args, world) => chrome.scripting.executeScript(Object.assign({ target: { tabId: tab.id }, func, args: args || [] }, world ? { world } : {})).then(r => r[0] && r[0].result);
const loadImg = url => new Promise((ok, no) => { const m = new Image(); m.onload = () => ok(m); m.onerror = no; m.src = url; });
/* the whole page: scroll, take each screen, glue — the width of the real screenshots sets the scale */
async function fullShot() {
  const dim = await run(() => { const el = document.scrollingElement || document.documentElement; const s = { y: scrollY, h: Math.min(el.scrollHeight, 16000), vh: innerHeight, w: innerWidth, sb: el.style.scrollBehavior }; el.style.scrollBehavior = 'auto'; return s; });
  let cv = null, g = null, sc = 1;
  for (let y = 0; y < dim.h; y += dim.vh) {
    const at = await run(t => { scrollTo(0, t); if (t > 0) for (const el of document.querySelectorAll('body *')) { const p = getComputedStyle(el).position; if ((p === 'fixed' || p === 'sticky') && !el.dataset.hst) { el.dataset.hst = el.style.visibility || '-'; el.style.visibility = 'hidden'; } } return scrollY; }, [y]);
    await new Promise(r => setTimeout(r, 550));
    const img = await loadImg(await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 82 }));
    if (!cv) { sc = img.naturalWidth / dim.w; cv = document.createElement('canvas'); cv.width = img.naturalWidth; cv.height = Math.round(dim.h * sc); g = cv.getContext('2d'); }
    g.drawImage(img, 0, Math.round(at * sc), img.naturalWidth, img.naturalHeight);
    $('#go').textContent = 'Снимаю страницу… ' + Math.min(100, Math.round((y + dim.vh) / dim.h * 100)) + '%';
  }
  await run(s => { for (const el of document.querySelectorAll('[data-hst]')) { el.style.visibility = el.dataset.hst === '-' ? '' : el.dataset.hst; delete el.dataset.hst; } scrollTo(0, s.y); (document.scrollingElement || document.documentElement).style.scrollBehavior = s.sb || ''; }, [dim]);
  const k = Math.min(1, 2400 / cv.width); if (k < 1) { const c2 = document.createElement('canvas'); c2.width = Math.round(cv.width * k); c2.height = Math.round(cv.height * k); c2.getContext('2d').drawImage(cv, 0, 0, c2.width, c2.height); return c2.toDataURL('image/jpeg', 0.82); }
  return cv.toDataURL('image/jpeg', 0.82);
}
async function frameShot() {
  const r = await run(vFrame); if (!r || r.err) throw new Error((r && r.err) || 'кадр не получился');
  if (r.img) return r;
  const img = await loadImg(await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 88 })), d = img.naturalWidth / (r.rect.vw || img.naturalWidth);
  const c = document.createElement('canvas'); c.width = Math.round(r.rect.w * d); c.height = Math.round(r.rect.h * d); c.getContext('2d').drawImage(img, r.rect.x * d, r.rect.y * d, c.width, c.height, 0, 0, c.width, c.height);
  return { img: c.toDataURL('image/jpeg', 0.88), at: r.at };
}
/* ---------- save ---------- */
function payload() {
  const P = ST.P, T = ST.take, parts = {};
  if (T.has('sel') && P.sel) { parts.sel = P.sel; parts.selHtml = P.selHtml || ''; }
  if (T.has('desc') && P.desc) parts.desc = P.desc;
  if (T.has('page') && P.text) parts.page = P.text;
  if (isYt() && T.has('tr')) parts.tr = 1;
  if (isYt() && T.has('chap')) parts.chapters = P.yt.chapters || [];
  const due = ST.due !== '' ? ymd(+ST.due) : $('#dueD').value || '', A = ST.ai;
  return { attach220: ST.attach || undefined, v218: 1, v217: 1, title: $('#title').value.trim() || tab.title, url: urlOut(), noEmbed: T.has('url') ? 0 : 1, site: P.remote ? 'youtube.com' : host, text: [parts.sel, parts.desc, parts.page].filter(Boolean).join('\n\n'), html: parts.selHtml || '', desc: P.desc || '', meta: metaOut(), parts, shot: T.has('shot') && !P.remote ? ST.shot : '', where: { lo: ST.where.has('lo') ? 1 : 0, board: ST.where.has('board') ? 1 : 0, kb: ST.where.has('kb') ? 1 : 0 }, ek: ST.ek, rel: ST.rel.slice(), imp: ST.imp, due: ST.where.has('lo') && ST.ek === 'task' ? due : '', tags: $('#tags').value.split(/\s+/).map(x => x.replace(/^#/, '')).filter(Boolean), intent: $('#intent').value.trim(), st216: isYt() ? ST.st216 : '', act216: isYt() ? ST.act216 : '', board: $('#board').value, frame: $('#frame').value, place: ST.place, view: ST.view,
    ai: { on: A.size || ST.where.has('kb') ? 1 : 0, tag: A.has('tag') ? 1 : 0, form: A.has('form') ? 1 : 0, rank: A.has('rank') ? 1 : 0, sum: A.has('sum') ? 1 : 0, sumForm: ST.form, ann: A.has('ann') ? 1 : 0, src: A.has('src') ? 1 : 0, fact: A.has('fact') ? 1 : 0, factMode: ST.fact, tasks: A.has('tasks') ? 1 : 0, kb: ST.where.has('kb') ? ST.kbm : '', pick: $('#aiPick').value === '__set' ? '' : $('#aiPick').value } };
}
async function remember() {
  const cur = { take: [...ST.take], shot: ST.shot, where: [...ST.where], ek: ST.ek, view: ST.view, place: ST.place, ai: [...ST.ai], kbm: ST.kbm, form: ST.form, fact: ST.fact };
  const st = await chrome.storage.local.get('sites'), sites = st.sites || {}; if (ST.siteMem && host && !ST.many && !ST.P.remote) sites[host] = cur;
  await chrome.storage.local.set({ last: Object.assign({ aiPick: $('#aiPick').value, board: $('#board').value }, cur), sites });
}
$('#go').addEventListener('click', async () => {
  const b = $('#go'); b.disabled = true; b.textContent = 'Сохраняю…';
  try {
    await remember();
    if (ST.many) {
      const vids = [...document.querySelectorAll('#manyL input:checked')].map(c => ST.many[+c.dataset.i]);
      const r = await bg('yt-many', { videos: vids, where: { lo: ST.where.has('lo') ? 1 : 0, board: ST.where.has('board') ? 1 : 0, kb: ST.where.has('kb') ? 1 : 0 }, intent: $('#intent').value.trim(), imp: ST.imp, st216: ST.st216, act216: ST.act216, ai: { pick: $('#aiPick').value === '__set' ? '' : $('#aiPick').value, tag: ST.ai.has('tag') ? 1 : 0 } }).catch(e => ({ ok: false, data: String(e && e.message || e) }));
      done(r && r.ok, r && r.ok ? `Готово: ${vids.length}` : (r && r.data) || 'откройте Холст'); return;
    }
    const d = payload(), T = ST.take, P = ST.P;
    /* the parts that live on the page: transcript, comments */
    if (d.parts.tr && !P.remote) { b.textContent = 'Беру транскрипт…'; const r = await tmo(run(ytTr, [], 'MAIN').catch(() => null), 15000); if (r && r.segs && r.segs.length) { d.parts.trSegs = r.segs; d.parts.trLang = r.lang || ''; } }
    if (isYt() && T.has('cm') && !P.remote) { b.textContent = 'Собираю комментарии…'; const r = await tmo(run(ytCm, [40, 12]).catch(() => null), 25000); if (r && r.list && r.list.length) d.parts.cm = r.list; }
    if (d.shot === 'area') { await chrome.storage.local.set({ pending: d }); await bg('area-start', { tabId: tab.id }); closeUI(); return; }
    if (d.shot) {
      b.textContent = 'Снимаю…'; await uiHide(true);
      try {
        if (d.shot === 'vis') d.image = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 82 });
        else if (d.shot === 'full') d.image = await fullShot();
        else if (d.shot === 'frame') { const f = await frameShot(); d.image = f.img; d.parts.frameAt = f.at; }
      } catch (e) { showErr('снимок не получился: ' + ((e && e.message) || e)); }
      finally { await uiHide(false); }
    }
    b.textContent = 'Сохраняю…';
    const r = await bg('clip', d).catch(e => ({ ok: false, data: String(e && e.message || e) }));
    const ok = r && r.ok && r.data && r.data.ok !== false;
    done(ok, ok ? (r.queued ? 'Холст закрыт — в очереди, уйдёт сам' : 'Сохранено') : 'Не получилось: ' + ((r && (r.data && r.data.err || r.data)) || 'откройте Холст'));
  } catch (e) { showErr(String((e && e.message) || e)); b.disabled = false; goLabel(); }
});
function done(ok, msg) { const b = $('#go'); b.textContent = msg; b.classList.toggle('done', !!ok); setTimeout(closeUI, ok ? 900 : 4000); }

/* 2.20: where the saved goes — this browser's Холст → Google Drive → every device */
function route220(P) {
  const el = $('#route220'); if (!el) return; const D = (P && P.drive) || null;
  chrome.storage.local.get('sys220').then(r => {
    const C = r.sys220 || {}, dr = D || C.drive || null;
    el.hidden = false;
    if (!P && !C.at) { el.className = 'route220'; el.innerHTML = 'Холст закрыт — сохраню в очередь, он откроется в фоне и заберёт сам.'; return; }
    if (dr && dr.on) { el.className = 'route220'; el.innerHTML = `Куда уйдёт: <b>Холст этого браузера</b> → <b>Google Диск${dr.email ? ' ' + esc(dr.email) : ''}</b> → все ваши браузеры и устройства.${P ? '' : ' Холст закрыт — уйдёт из очереди.'}`; }
    else { el.className = 'route220 warn'; el.innerHTML = 'В этом браузере Холст не подключён к Google Диску — сохранённое останется только здесь. Чтобы попадало в аккаунт в другом браузере: Холст → облако вверху → Google Диск тем же аккаунтом.'; }
  });
}
