const $ = s => document.querySelector(s);
const bg = (op, data) => chrome.runtime.sendMessage({ to: 'bg', op, data });
const seg = (sel, attr, def) => { const box = $(sel); let v = def; box.addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; box.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); v = b.dataset[attr]; box.dispatchEvent(new Event('pick')); }); return () => v; };
const kind = seg('#kind', 'k', 'task'), due = seg('#due', 'd', ''), pr = seg('#pr', 'p', ''), shot = seg('#shot', 's', ''), wgScope = seg('#wgScope', 's', 'site'), wgMode = seg('#wgMode', 'm', 'page');
let tab, page = {};
const ymd = n => { const d = new Date(Date.now() + n * 864e5); return d.toISOString().slice(0, 10); };
const esc = s => String(s || '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const opt = (sel, v, t) => { const o = document.createElement('option'); o.value = v; o.textContent = t; $(sel).appendChild(o); };
(async () => {
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  $('#title').value = tab.title || tab.url;
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => {
      const sel = String(getSelection() || ''), m = n => (document.querySelector(`meta[name="${n}"],meta[property="${n}"]`) || {}).content || '';
      const main = document.querySelector('article, main, [role=main]') || document.body;
      return { sel, desc: m('description') || m('og:description'), text: (main.innerText || '').replace(/\n{3,}/g, '\n\n').slice(0, 20000), selHtml: sel ? (() => { const c = document.createElement('div'); c.appendChild(getSelection().getRangeAt(0).cloneContents()); return c.innerHTML; })() : '' };
    } });
    page = r.result || {};
  } catch (e) { page = {}; }
  $('#selN').textContent = page.sel ? `(${page.sel.length} симв.)` : '(нет)'; if (!page.sel) $('#wSel').checked = false;
  const st = await chrome.storage.local.get(['holstUrl', 'widgets', 'last']); $('#hurl').value = st.holstUrl || 'https://podkindmitry.github.io/holst/';
  const host = new URL(tab.url).hostname, W = st.widgets || {}, rule = W['page:' + tab.url] || W['site:' + host];
  if (rule) { $('#wgOn').checked = !!rule.on; }
  const ping = await bg('ping').catch(() => null), P = ping && ping.ok ? ping.data : null;
  $('#st').textContent = P ? 'Холст ' + P.v + (P.board ? ' · ' + P.board.name : '') : 'Холст откроется во вкладке';
  for (const a of (P && P.ais) || []) opt('#aiPick', a.p, a.l);
  const [pj, bd, dup] = await Promise.all([bg('projects').catch(() => null), bg('boards').catch(() => null), bg('dup', { url: tab.url }).catch(() => null)]);
  if (pj && pj.ok) for (const p of pj.data) opt('#dest', p.id, p.t);
  if (bd && bd.ok) for (const b of bd.data) if (!P || !P.board || b.id !== P.board.id) opt('#board', b.id, b.n);
  if (dup && dup.ok && dup.data && dup.data.length) { const d = $('#dup'); d.hidden = false; d.innerHTML = `<b>Эта ссылка уже есть в Холсте</b><ul>${dup.data.slice(0, 5).map(x => `<li>${esc(x.where)}: ${esc(x.t)}</li>`).join('')}</ul>Добавить ещё раз — можно, но это будет дубль.`; $('#go').textContent = 'Всё равно добавить'; }
  const L = st.last || {}; if (L.dest) $('#dest').value = L.dest; if (L.aiPick) $('#aiPick').value = L.aiPick; if (L.board) $('#board').value = L.board;
  frames();
})();
async function frames() {
  const f = $('#frame'); f.innerHTML = '<option value="">Центр экрана</option>';
  const r = await bg('frames', { board: $('#board').value }).catch(() => null);
  if (r && r.ok) for (const x of r.data) opt('#frame', x.id, x.t);
}
$('#board').addEventListener('change', frames);
$('#kind').addEventListener('pick', () => { $('#taskOpts').style.display = kind() === 'board' ? 'none' : ''; $('#boardOpts').style.display = kind() === 'task' ? 'none' : ''; });
$('#hurl').addEventListener('change', e => chrome.storage.local.set({ holstUrl: e.target.value.trim() }));
/* the whole page: scroll, take each screen, glue */
async function fullShot() {
  const run = (func, args) => chrome.scripting.executeScript({ target: { tabId: tab.id }, func, args: args || [] }).then(r => r[0].result);
  const dim = await run(() => { const el = document.scrollingElement || document.documentElement; const s = { y: scrollY, h: Math.min(el.scrollHeight, 16000), vh: innerHeight, w: innerWidth, dpr: devicePixelRatio, sb: el.style.scrollBehavior }; el.style.scrollBehavior = 'auto'; return s; });
  const cv = document.createElement('canvas'); cv.width = Math.round(dim.w * dim.dpr); cv.height = Math.round(dim.h * dim.dpr); const g = cv.getContext('2d');
  for (let y = 0, i = 0; y < dim.h; y += dim.vh, i++) {
    const at = await run(t => { scrollTo(0, t); if (t > 0) for (const el of document.querySelectorAll('body *')) { const p = getComputedStyle(el).position; if ((p === 'fixed' || p === 'sticky') && !el.dataset.hst) { el.dataset.hst = el.style.visibility || '-'; el.style.visibility = 'hidden'; } } return scrollY; }, [y]);
    await new Promise(r => setTimeout(r, 550));
    const url = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 82 });
    const img = await new Promise((ok, no) => { const m = new Image(); m.onload = () => ok(m); m.onerror = no; m.src = url; });
    g.drawImage(img, 0, Math.round(at * dim.dpr));
    $('#go').textContent = 'Снимаю страницу… ' + Math.min(100, Math.round((y + dim.vh) / dim.h * 100)) + '%';
  }
  await run(s => { for (const el of document.querySelectorAll('[data-hst]')) { el.style.visibility = el.dataset.hst === '-' ? '' : el.dataset.hst; delete el.dataset.hst; } scrollTo(0, s.y); (document.scrollingElement || document.documentElement).style.scrollBehavior = s.sb || ''; }, [dim]);
  const k = Math.min(1, 2400 / cv.width); if (k < 1) { const c2 = document.createElement('canvas'); c2.width = Math.round(cv.width * k); c2.height = Math.round(cv.height * k); c2.getContext('2d').drawImage(cv, 0, 0, c2.width, c2.height); return c2.toDataURL('image/jpeg', 0.82); }
  return cv.toDataURL('image/jpeg', 0.82);
}
$('#go').addEventListener('click', async () => {
  const b = $('#go'); b.disabled = true; b.textContent = 'Отправляю…';
  let image = '';
  try { if (shot() === 'vis') image = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 80 }); else if (shot() === 'full') image = await fullShot(); } catch (e) { /* not allowed on this page */ }
  const parts = []; if ($('#wSel').checked && page.sel) parts.push(page.sel); if ($('#wDesc').checked && page.desc) parts.push(page.desc); if ($('#wText').checked && page.text) parts.push(page.text);
  const d = due(), ai = $('#ai').checked, base = { title: $('#title').value.trim() || tab.title, url: $('#wUrl').checked ? tab.url : '', text: parts.join('\n\n'), html: $('#wSel').checked ? page.selHtml : '', site: new URL(tab.url).hostname, intent: $('#intent').value.trim(), desc: page.desc || '', aiPick: $('#aiPick').value, image };
  const task = Object.assign({ kind: 'task', due: d === '' ? '' : ymd(+d), pr: pr(), tags: $('#tags').value.split(/\s+/).map(x => x.replace(/^#/, '')).filter(Boolean), dest: $('#dest').value, resource: $('#res').checked, ai }, base);
  const res = [];
  if (kind() !== 'board') res.push(await bg('clip', task));
  if (kind() !== 'task') res.push(await bg('clip', Object.assign({ kind: 'board', board: $('#board').value, frame: $('#frame').value, ai: ai && kind() === 'board' }, base)));
  chrome.storage.local.set({ last: { dest: $('#dest').value, aiPick: $('#aiPick').value, board: $('#board').value } });
  const ok = res.every(r => r && r.ok && r.data && r.data.ok !== false);
  b.textContent = ok ? 'Добавлено' : 'Не получилось: ' + ((res.find(r => !r || !r.ok) || {}).data || 'откройте Холст'); setTimeout(() => window.close(), ok ? 900 : 4000);
});
$('#wgOn').addEventListener('change', saveWidget); $('#wgScope').addEventListener('pick', saveWidget); $('#wgMode').addEventListener('pick', saveWidget);
async function saveWidget() {
  const W = (await chrome.storage.local.get('widgets')).widgets || {}, host = new URL(tab.url).hostname, key = wgScope() === 'page' ? 'page:' + tab.url : 'site:' + host;
  delete W['page:' + tab.url]; delete W['site:' + host];
  if ($('#wgOn').checked) W[key] = Object.assign({ on: 1, mode: wgMode(), scope: wgScope() }, W[key] || {}, { on: 1, mode: wgMode(), scope: wgScope() });
  await chrome.storage.local.set({ widgets: W }); chrome.tabs.sendMessage(tab.id, { op: 'widget-refresh' }).catch(() => chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['widget.js'] }).catch(() => {}));
}
