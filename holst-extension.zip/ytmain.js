/* Холст 2.23 — YouTube, main world: learns which channel id (UC…) stands behind which @handle.
   Imported folders (PocketTube) know channels by id, YouTube links show handles — this script reads what the page
   already has (the subscriptions in the side guide, cards of the feed, the page data) and tells the extension. */
(() => {
  if (window.__holstYtMain) return; window.__holstYtMain = 1;
  const seen = new Set(), done = new WeakMap(); let buf = [], tm = 0;
  const flush = () => { tm = 0; if (!buf.length) return; const b = buf; buf = []; try { window.postMessage({ __holstYtMap: b }, location.origin); } catch (e) {} };
  const scan = o => {
    if (!o) return; let s; try { s = JSON.stringify(o); } catch (e) { return; } if (!s || s.indexOf('canonicalBaseUrl') < 0) return;
    const re = /"browseEndpoint":\{([^{}]*)\}/g; let m;
    while ((m = re.exec(s))) {
      const id = (m[1].match(/"browseId":"(UC[\w-]{22})"/) || [])[1], h = (m[1].match(/"canonicalBaseUrl":"(\/@[^"]+)"/) || [])[1];
      if (id && h && !seen.has(id + h)) { seen.add(id + h); buf.push([id, h]); }
    }
    if (buf.length && !tm) tm = setTimeout(flush, 300);
  };
  const SEL = 'ytd-guide-renderer, ytd-guide-entry-renderer, ytd-rich-item-renderer, ytd-video-renderer, ytd-compact-video-renderer, ytd-grid-video-renderer, ytd-channel-renderer, ytd-video-owner-renderer, ytd-grid-channel-renderer, ytd-reel-item-renderer';
  const tick = () => {
    for (const el of document.querySelectorAll(SEL)) { const d = el.data || (el.__data && el.__data.data); if (!d || done.get(el) === d) continue; done.set(el, d); scan(d); }
  };
  scan(window.ytInitialData);
  window.addEventListener('yt-navigate-finish', () => setTimeout(tick, 600));
  window.addEventListener('message', e => { if (e.source === window && e.data && e.data.__holstYtMapAsk) { seen.clear(); tick(); scan(window.ytInitialData); } });
  setInterval(tick, 3000); setTimeout(tick, 800);
})();
