/* Холст — the extension's background (v2.21: the right click for everything, screenshots of areas with scrolling and of scrolling blocks, chats of Claude by iterations, rewatches, hidden channels. v2.20: works with Холст closed — a cache of boards, projects and video properties, any request queued; watched zones of videos. v2.18: one panel for every way in, tabs by selection, group and site; v2.17).
   Finds (or opens) the Холст tab and relays requests from the popup, the widgets, YouTube.
   v2.17: a queue when Холст is closed; quick save without the popup; selected text into
   the page's element or as its own record; highlights; a snapshot of an area; all tabs;
   settings and widgets kept in Холст and returned after a reinstall; one-click update. */
const DEF_URL = 'https://podkindmitry.github.io/holst/';
const holstUrl = async () => ((await chrome.storage.local.get('holstUrl')).holstUrl || DEF_URL);
let readyWaiters = [];
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.op === 'bridge-ready') { const w = readyWaiters; readyWaiters = []; w.forEach(f => f(sender.tab && sender.tab.id)); setTimeout(flushQueue, 2500); setTimeout(restoreState, 3000); setTimeout(() => sysPull(true), 4500); setTimeout(ywFlush, 5000); return; }
  if (msg && msg.op === 'area-rect') { areaDone(msg.rect, sender.tab).then(reply, e => reply({ ok: false, data: String(e && e.message || e) })); return true; }
  if (!msg || msg.to !== 'bg') return;
  if (msg.op === 'badge') { const n = +(msg.data && msg.data.n) || 0; chrome.action.setBadgeBackgroundColor({ color: '#8b5cf6' }); chrome.action.setBadgeText({ text: n ? (n > 99 ? '99+' : String(n)) : '' }); reply({ ok: true }); return; }
  if (msg.op === 'fetch') { xfetch(msg.data, sender).then(reply, e => reply({ ok: false, err: String(e && e.message || e) })); return true; }
  if (msg.op === 'whimgrab') { whimGrab223(msg.data).then(reply, e => reply({ ok: false, err: String(e && e.message || e) })); return true; }
  if (msg.op === 'kbfetch') { kbfetch(msg.data, sender).then(reply, e => reply({ ok: false, err: String(e && e.message || e) })); return true; }
  if (msg.op === 'my-tab') { reply({ ok: true, id: sender.tab && sender.tab.id }); return; }
  if (msg.op === 'reload') { reply({ ok: true }); setTimeout(() => chrome.runtime.reload(), 300); return; }
  if (msg.op === 'shot221') { stitch221(msg.data.tabId, msg.data.windowId, { full: 1 }).then(img => reply({ ok: true, data: img }), e => reply({ ok: false, data: String(e && e.message || e) })); return true; }
  if (msg.op === 'claude221') { claude221(msg.data.tabId, msg.data).then(r => reply({ ok: true, data: r }), e => reply({ ok: false, data: String(e && e.message || e) })); return true; }
  if (msg.op === 'yt-block') { ytBlock221(msg.data).then(reply, e => reply({ ok: false, data: String(e && e.message || e) })); return true; }
  if (msg.op === 'area-start') { areaStart(msg.data.tabId).then(reply, e => reply({ ok: false, data: String(e && e.message || e) })); return true; }
  if (msg.op === 'tabs-all') { tabsAll(msg.data).then(reply, e => reply({ ok: false, data: String(e && e.message || e) })); return true; }
  if (msg.op === 'open') { openIn(msg.data).then(reply, e => reply({ ok: false, data: String(e && e.message || e) })); return true; }
  if (msg.op === 'clip') { clip(msg.data).then(reply, e => reply({ ok: false, data: String(e && e.message || e) })); return true; }
  if (msg.op === 'yt-watch') { ytWatch(msg.data).then(reply, e => reply({ ok: false, data: String(e && e.message || e) })); return true; }
  if (CACHED.includes(msg.op)) { cached(msg.op, msg.data).then(reply, e => reply({ ok: false, data: String(e && e.message || e) })); return true; }
  if (QUEUED.includes(msg.op)) { queued(msg.op, msg.data).then(reply, e => reply({ ok: false, data: String(e && e.message || e) })); return true; }
  if (msg.op === 'kb-add') { relay('kb-add', msg.data).then(async r => { const id = await holstTab(false); if (id) { const t = await chrome.tabs.update(id, { active: true }); chrome.windows.update(t.windowId, { focused: true }).catch(() => {}); } reply(r); }, e => reply({ ok: false, data: String(e && e.message || e) })); return true; }
  relay(msg.op, msg.data).then(reply, e => reply({ ok: false, data: String(e && e.message || e) }));
  return true;
});
async function holstTab(open) {
  const base = await holstUrl();
  const tabs = await chrome.tabs.query({ url: base + '*' });
  if (tabs.length) return tabs[0].id;
  if (!open) return null;
  const t = await chrome.tabs.create({ url: base, active: false, pinned: true });
  await new Promise(res => { const to = setTimeout(res, 12000); readyWaiters.push(() => { clearTimeout(to); setTimeout(res, 1800); }); });
  return t.id;
}
async function relay(op, data, noOpen) {
  let id = await holstTab(!noOpen); if (!id) throw new Error('Холст закрыт');
  try { await ensureBridge(id); return await chrome.tabs.sendMessage(id, { to: 'holst', op, data }); }
  catch (e) { await new Promise(r => setTimeout(r, 1500)); id = await holstTab(!noOpen); if (!id) throw e; await ensureBridge(id); return chrome.tabs.sendMessage(id, { to: 'holst', op, data }); }
}
async function ensureBridge(tabId) {
  try { await chrome.scripting.executeScript({ target: { tabId }, files: ['bridge.js'] }); } catch (e) { /* already there or not allowed */ }
}
/* ---------- the queue: nothing is lost when Холст is closed or not answering ---------- */
async function clip(d) {
  try { const r = await relay('clip', d); if (r && r.ok) return r; throw new Error((r && r.data) || 'нет ответа'); }
  catch (e) { const q = (await chrome.storage.local.get('queue')).queue || []; q.push({ d, at: Date.now() }); await chrome.storage.local.set({ queue: q.slice(-200) }); badgeQ(q.length); return { ok: true, queued: true, data: { ok: true } }; }
}
async function flushQueue() {
  const q = (await chrome.storage.local.get('queue')).queue || []; if (!q.length) return;
  const id = await holstTab(false); if (!id) return;
  const left = [];
  for (const x of q) { try { const r = await relay(x.op || 'clip', x.d, true); if (!(r && r.ok)) left.push(x); } catch (e) { left.push(x); } }
  await chrome.storage.local.set({ queue: left }); badgeQ(left.length);
}
const badgeQ = n => { chrome.action.setBadgeBackgroundColor({ color: '#d97706' }); chrome.action.setBadgeText({ text: n ? String(n) : '' }); };
chrome.alarms && chrome.alarms.onAlarm.addListener(a => { if (a.name === 'queue') { flushQueue(); sysPull(false); ywFlush(); } });
/* ---------- open something in Холст and show the tab ---------- */
async function openIn(d) {
  const r = await relay(d.ai ? 'open-ai' : 'open', d); const id = await holstTab(false);
  if (id) { const t = await chrome.tabs.update(id, { active: true }); chrome.windows.update(t.windowId, { focused: true }).catch(() => {}); }
  return r;
}
/* ---------- quick save: the page, with the choice remembered for this site ---------- */
chrome.commands.onCommand.addListener(async cmd => {
  if (cmd !== 'quick-save') return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); if (!tab || !/^https?:/.test(tab.url || '')) return;
  const r = await quickSave(tab); mark(tab.id, r);
});
async function pageMeta(tabId) {
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: () => {
      const q = s => document.querySelector(s), m = n => ((q(`meta[property="${n}"]`) || q(`meta[name="${n}"]`) || {}).content || '').trim();
      const ico = q('link[rel~="icon"], link[rel="apple-touch-icon"]'); let fav = ''; try { fav = ico ? new URL(ico.getAttribute('href'), location.href).href : location.origin + '/favicon.ico'; } catch (e) { fav = ''; }
      return { title: m('og:title') || document.title, desc: m('og:description') || m('description'), img: m('og:image'), site: m('og:site_name') || location.hostname.replace(/^www\./, ''), fav, sel: String(getSelection() || '').trim() };
    } });
    return (r && r.result) || {};
  } catch (e) { return {}; }
}
async function quickSave(tab, extra) {
  const host = (() => { try { return new URL(tab.url).hostname; } catch (e) { return ''; } })(), st = await chrome.storage.local.get(['sites', 'last']), R = (st.sites && st.sites[host]) || st.last || {};
  const P = await pageMeta(tab.id), where = new Set(R.where || ['lo']);
  return clip(Object.assign({ v218: 1, v217: 1, parts: { desc: (R.take || []).includes('desc') ? P.desc || '' : '', sel: P.sel || '' }, place: R.place || 'free', title: P.title || tab.title, url: tab.url, site: host, text: (R.take || []).includes('desc') ? P.desc || '' : '', desc: P.desc || '', meta: { img: P.img, fav: P.fav, site: P.site, desc: (P.desc || '').slice(0, 400) }, where: { lo: where.has('lo') ? 1 : 0, board: where.has('board') ? 1 : 0, kb: where.has('kb') ? 1 : 0 }, ek: R.ek || 'resource', view: R.view || 'card', rel: [], ai: { on: 0 } }, extra || {}));
}
const mark = (tabId, r) => { const ok = r && r.ok; chrome.action.setBadgeBackgroundColor({ color: ok ? (r.queued ? '#d97706' : '#2fa36b') : '#e5484d', tabId }); chrome.action.setBadgeText({ text: ok ? (r.queued ? '…' : '✓') : '!', tabId }); setTimeout(() => chrome.action.setBadgeText({ text: '', tabId }), 2500); };
/* ---------- all tabs of the window ---------- */
async function tabsAll(d) {
  let q = 0;
  for (const t of (d.tabs || []).slice(0, 100)) { const r = await clip({ v217: 1, title: t.title || t.url, url: t.url, site: t.site, where: { lo: 1 }, ek: 'resource', rel: d.rel || [], tags: ['вкладки'].concat(d.tag && d.tag !== 'вкладки' ? [d.tag] : []), ai: { on: 0 } }); if (r.queued) q++; }
  return { ok: true, queued: q };
}
/* ---------- a snapshot of an area: the page lets you draw a rectangle ---------- */
async function areaStart(tabId) { await chrome.scripting.executeScript({ target: { tabId }, files: ['area.js'] }); return { ok: true }; }
async function areaDone(rect, tab) {
  const st = await chrome.storage.local.get('pending'), d = st.pending; await chrome.storage.local.remove('pending'); if (!d || !rect) return { ok: false };
  if (rect.scroll) { d.image = await stitch221(tab.id, tab.windowId, { el: rect.el, x: rect.x, w: rect.w, y0: rect.y0, h: rect.h }); const r = await clip(d); mark(tab.id, r); return r; }
  const url = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
  const bmp = await createImageBitmap(await (await fetch(url)).blob()), k = rect.dpr || 1;
  const w = Math.max(1, Math.round(rect.w * k)), h = Math.max(1, Math.round(rect.h * k)), c = new OffscreenCanvas(w, h);
  c.getContext('2d').drawImage(bmp, Math.round(rect.x * k), Math.round(rect.y * k), w, h, 0, 0, w, h);
  const blob = await c.convertToBlob({ type: 'image/jpeg', quality: 0.86 }), buf = new Uint8Array(await blob.arrayBuffer());
  let bin = ''; for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  d.image = 'data:image/jpeg;base64,' + btoa(bin);
  const r = await clip(d); mark(tab.id, r); return r;
}
/* ---------- right click ---------- */
/* v2.19: one build at a time — two quick calls (install + startup) used to create the same items twice
   (Vivaldi: «Cannot create item with duplicate id») */
let menusBusy = Promise.resolve();
function menus() {
  menusBusy = menusBusy.then(() => new Promise(done => chrome.contextMenus.removeAll(() => {
    void chrome.runtime.lastError;
    const C = (id, title, contexts, parentId) => chrome.contextMenus.create(Object.assign({ id, title, contexts }, parentId ? { parentId } : {}), () => void chrome.runtime.lastError);
    C('holst', 'Холст', ['page', 'selection', 'link', 'image', 'video']);
    C('sel-board', 'Выделенное → на доску', ['selection'], 'holst');
    C('hl-task', 'Выделенное → задачей к этой странице', ['selection'], 'holst');
    C('hl-entity', 'Выделенное → заметкой, связанной со страницей', ['selection'], 'holst');
    C('hl-notes', 'Выделенное → в текст элемента этой страницы', ['selection'], 'holst');
    C('sel-term', 'Выделенное → в глоссарий, термином', ['selection'], 'holst');
    C('sel-card', 'Выделенное → в карточки для повторения', ['selection'], 'holst');
    C('sel-kb', 'Выделенное → в источники, цитатой', ['selection'], 'holst');
    C('sel-ask', 'Спросить нейросеть о выделенном', ['selection'], 'holst');
    C('sel-search', 'Найти выделенное в Холсте', ['selection'], 'holst');
    C('link-save', 'Ссылку — материалом в задачник', ['link'], 'holst');
    C('link-board', 'Ссылку — на доску карточкой', ['link'], 'holst');
    C('link-task', 'Ссылку — задачей «прочитать»', ['link'], 'holst');
    C('link-kb', 'Ссылку — в источники', ['link'], 'holst');
    C('img-board', 'Картинку — на доску', ['image'], 'holst');
    C('img-lo', 'Картинку — в задачник к этой странице', ['image'], 'holst');
    C('video-frame', 'Кадр видео — на доску', ['video'], 'holst');
    C('page-save', 'Сохранить страницу — сразу, как для этого сайта', ['page'], 'holst');
    C('page-full', 'Снимок всей страницы — на доску', ['page'], 'holst');
    C('page-area', 'Снимок области, можно с прокруткой — на доску', ['page'], 'holst');
    chrome.contextMenus.create({ id: 'page-claude', title: 'Чат Claude — на доску по итерациям', contexts: ['page'], parentId: 'holst', documentUrlPatterns: ['https://claude.ai/*'] }, () => void chrome.runtime.lastError);
    C('page-widget', 'Виджет задач на этой странице', ['page'], 'holst');
    done();
  })));
  return menusBusy;
}
chrome.runtime.onInstalled.addListener(menus);
chrome.runtime.onStartup && chrome.runtime.onStartup.addListener(menus);
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const id = info.menuItemId, host = (() => { try { return new URL(tab.url).hostname; } catch (e) { return ''; } })();
  if (id === 'page-widget') { const r = (await chrome.storage.local.get('widgets')).widgets || {}; r['page:' + tab.url] = Object.assign({}, r['page:' + tab.url] || {}, { on: 1, mode: 'page', scope: 'page' }); await chrome.storage.local.set({ widgets: r }); chrome.tabs.sendMessage(tab.id, { op: 'widget-refresh' }).catch(() => {}); return; }
  if (/^hl-/.test(id)) {
    const text = String(info.selectionText || '').trim(); if (!text) return;
    let r; try { r = await relay('hl', { url: tab.url, title: tab.title, site: host, text, mode: id === 'hl-notes' ? 'notes' : id === 'hl-task' ? 'task' : 'entity' }); } catch (e) { r = { ok: false }; }
    mark(tab.id, r && r.ok ? { ok: true } : r);
    if (r && r.ok) { chrome.tabs.sendMessage(tab.id, { op: 'hl-mark', text }).catch(() => {}); const k = 'hl:' + key(tab.url), st = await chrome.storage.local.get(k); await chrome.storage.local.set({ [k]: (st[k] || []).concat({ t: text.slice(0, 2000), at: Date.now() }).slice(-300) }); }
    return;
  }
  if (await ctxMenu221(id, info, tab, host)) return;
  if (id === 'page-save') { mark(tab.id, await quickSave(tab)); return; }
  if (id === 'link-save') { mark(tab.id, await clip({ v217: 1, title: info.selectionText || info.linkUrl, url: info.linkUrl, site: host, where: { lo: 1 }, ek: 'resource', rel: [], ai: { on: 0 } })); return; }
  if (id === 'img-board') {
    let image = ''; try { const b = await (await fetch(info.srcUrl)).blob(); const buf = new Uint8Array(await b.arrayBuffer()); let bin = ''; for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000)); image = 'data:' + (b.type || 'image/png') + ';base64,' + btoa(bin); } catch (e) { /* the link only */ }
    mark(tab.id, await clip({ v217: 1, title: tab.title, url: tab.url, noEmbed: 1, site: host, image, where: { board: 1 }, rel: [], ai: { on: 0 } }));
  }
});
const key = u => { try { const x = new URL(u); x.hash = ''; [...x.searchParams.keys()].filter(k => /^(utm_|fbclid|gclid|yclid)/.test(k)).forEach(k => x.searchParams.delete(k)); return x.href; } catch (e) { return String(u || ''); } };
/* ---------- after an install or an update: everything comes back ---------- */
chrome.runtime.onInstalled.addListener(async () => {
  chrome.alarms && chrome.alarms.create('queue', { periodInMinutes: 1 });
  const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] }).catch(() => []);
  for (const t of tabs) {
    if (/^https:\/\/podkindmitry\.github\.io\/holst\//.test(t.url || '')) { chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['bridge.js'] }).catch(() => {}); continue; }
    chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['widget.js', 'hl.js'] }).catch(() => {});
    if (/^https:\/\/www\.youtube\.com\//.test(t.url || '')) chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['yt.js'] }).catch(() => {});
  }
  setTimeout(restoreState, 4000);
});
/* the extension's settings and widgets live in Холст too: a new install gets them back */
const KEEP = ['widgets', 'last', 'sites', 'siteMem', 'holstUrl', 'ytPick', 'feed221', 'feedp221', 'yb221', 'pres221'];
async function restoreState() {
  const st = await chrome.storage.local.get(KEEP.concat('restored217'));
  if (st.restored217 && st.widgets && Object.keys(st.widgets).length) return;
  let r; try { r = await relay('state-get', {}, true); } catch (e) { return; }
  const S = r && r.ok && r.data; if (!S) { chrome.storage.local.set({ restored217: 1 }); return; }
  const put = { restored217: 1 }; for (const k of KEEP) if (S[k] != null && (st[k] == null || (k === 'widgets' && !Object.keys(st[k] || {}).length))) put[k] = S[k];
  if (S.hl) for (const [k, v] of Object.entries(S.hl)) put[k] = v;
  await chrome.storage.local.set(put);
  const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] }).catch(() => []);
  for (const t of tabs) chrome.tabs.sendMessage(t.id, { op: 'widget-refresh' }).catch(() => {});
}
let saveT = 0;
chrome.storage.onChanged.addListener((ch, area) => {
  if (area !== 'local' || !Object.keys(ch).some(k => KEEP.includes(k) || k.startsWith('hl:'))) return;
  clearTimeout(saveT); saveT = setTimeout(async () => {
    const all = await chrome.storage.local.get(null), out = {}; for (const k of KEEP) if (all[k] != null) out[k] = all[k];
    out.hl = {}; for (const k of Object.keys(all)) if (k.startsWith('hl:')) out.hl[k] = all[k];
    out.v = chrome.runtime.getManifest().version; relay('state-set', out, true).catch(() => {});
  }, 1500);
});

/* v2.13: a request for the Холст page — only from the Холст tab, only to AI services and Google */
const XOK = [/^https:\/\/api\.anthropic\.com\//, /^https:\/\/[a-z0-9.-]+\.(openai|groq|cerebras|mistral|deepseek|x|together|cohere|perplexity)\.(com|ai|xyz)\//, /^https:\/\/(openrouter\.ai|api\.x\.ai|api\.deepseek\.com|integrate\.api\.nvidia\.com|router\.huggingface\.co|generativelanguage\.googleapis\.com|dashscope-intl\.aliyuncs\.com|api\.perplexity\.ai)\//];
async function xfetch(d, sender) {
  const base = await holstUrl(), from = (sender && sender.tab && sender.tab.url) || '';
  if (!from.startsWith(base) && !/^http:\/\/localhost/.test(from)) return { ok: false, err: 'запрос не из вкладки Холста' };
  if (!XOK.some(r => r.test(d.url))) return { ok: false, err: 'этот адрес расширение не пропускает' };
  const r = await fetch(d.url, { method: (d.init && d.init.method) || 'GET', headers: (d.init && d.init.headers) || {}, body: d.init && d.init.body });
  const headers = {}; r.headers.forEach((v, k) => { headers[k] = v; });
  return { ok: true, status: r.status, statusText: r.statusText, headers, body: await r.text() };
}

/* v2.14: pages for «Источники» — articles, Telegram channels, YouTube pages and transcripts.
   Only from the Холст tab; reading only (GET), except YouTube's own transcript request.
   v2.15: the same reading road brings boards from Miro and files from FigJam. */
async function kbfetch(d, sender) {
  const base = await holstUrl(), from = (sender && sender.tab && sender.tab.url) || '';
  if (!from.startsWith(base) && !/^http:\/\/localhost/.test(from)) return { ok: false, err: 'запрос не из вкладки Холста' };
  const u = String(d.url || ''), m = ((d.init && d.init.method) || 'GET').toUpperCase();
  if (!/^https:\/\//.test(u)) return { ok: false, err: 'только https' };
  if (m !== 'GET' && !/^https:\/\/www\.youtube\.com\/youtubei\/v1\/get_transcript/.test(u)) return { ok: false, err: 'расширение только читает страницы' };
  const r = await fetch(u, { method: m, headers: (d.init && d.init.headers) || {}, body: m === 'GET' ? undefined : d.init.body, credentials: /^https:\/\/api\.(miro|figma)\.com\//.test(u) ? 'omit' : 'include' });
  if (d.init && d.init.bin) {
    if (!r.ok) return { ok: true, status: r.status, body: '' };
    const buf = await r.arrayBuffer(); if (buf.byteLength > 12e6) return { ok: true, status: 413, body: '' };
    let bin = ''; const u8 = new Uint8Array(buf); for (let i = 0; i < u8.length; i += 0x8000) bin += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
    return { ok: true, status: r.status, body: 'data:' + (r.headers.get('content-type') || 'application/octet-stream').split(';')[0] + ';base64,' + btoa(bin) };
  }
  const body = await r.text();
  return { ok: true, status: r.status, body: body.length > 8e6 ? body.slice(0, 8e6) : body };
}

/* ---------- v2.20: working with Холст closed ---------- */
/* what the popup, the widget and YouTube need — kept here; asked from Холст when it is open */
const CACHED = ['ping', 'boards', 'projects', 'yt-info', 'yt-known', 'yt-moments'];
const QUEUED = ['yt-moment', 'add', 'yt-add', 'yt-status', 'yt-many', 'ctx221', 'feed-save', 'yt-unblock'];
async function sysPull(force) {
  const st = await chrome.storage.local.get('sys220'), C = st.sys220 || {};
  if (!force && C.at && Date.now() - C.at < 10 * 60000) return C;
  try { const r = await relay('sys-cache', {}, true); if (r && r.ok && r.data && r.data.ok) { await chrome.storage.local.set({ sys220: r.data }); return r.data; } } catch (e) { /* Холст closed */ }
  return C;
}
async function fromCache(op, d) {
  const C = (await chrome.storage.local.get('sys220')).sys220 || {};
  if (op === 'ping') return C.at ? { ok: true, data: { v: '', board: null, ai217: C.ai217, drive: C.drive, cached: 1 } } : null;
  if (op === 'boards') return C.boards ? { ok: true, data: C.boards } : null;
  if (op === 'projects') return C.projects ? { ok: true, data: C.projects } : null;
  if (op === 'yt-info') { const v = (C.v || {})[d.id]; return { ok: true, data: v ? { task: v.in ? { id: '', st: v.t ? 'done' : 'todo' } : null, kb: v.kb ? { w: v.w } : null, st216: v.st || '', act216: v.act || '', w216: v.w != null ? v.w : '', cached: 1 } : { cached: 1 } }; }
  if (op === 'yt-known') return { ok: true, data: { ch: Object.entries(C.ch || {}).map(([u, w]) => ({ url: 'https://' + u, w })), comps: [] } };
  if (op === 'yt-moments') { const w = (await chrome.storage.local.get('yw:' + d.id))['yw:' + d.id] || null; return { ok: true, data: { list: ((C.mom || {})[d.id] || []).map(([s, t, ai]) => ({ s, t, ai: !!ai })), w } }; }
  return null;
}
async function cached(op, d) {
  try { const r = await relay(op, d, true); if (r && (r.ok || r.data)) return r; } catch (e) { /* closed — the cache answers */ }
  const c = await fromCache(op, d); if (c) return c;
  return relay(op, d);
}
async function queued(op, d) {
  try { const r = await relay(op, d, true); if (r && r.ok) return r; } catch (e) { /* closed */ }
  try { const r = await relay(op, d); if (r && r.ok) return r; } catch (e) { /* not answering */ }
  const q = (await chrome.storage.local.get('queue')).queue || []; q.push({ op, d, at: Date.now() }); await chrome.storage.local.set({ queue: q.slice(-200) }); badgeQ(q.length); return { ok: true, queued: true, data: { ok: true, queued: 1 } };
}
/* watched zones of videos: kept here, given to Холст */
function zMerge(a, b) { const L = (a || []).concat(b || []).map(z => [+z[0], +z[1]]).filter(z => z[1] > z[0]).sort((p, q) => p[0] - q[0]), out = []; for (const z of L) { const l = out[out.length - 1]; if (l && z[0] <= l[1] + 2) l[1] = Math.max(l[1], z[1]); else out.push(z.slice()); } return out; }
async function ytWatch(d) {
  if (!d || !d.id) return { ok: false }; const k = 'yw:' + d.id, o = (await chrome.storage.local.get(k))[k] || { d: 0, z: [] };
  o.d = Math.max(o.d || 0, +d.d || 0); o.z = zMerge(o.z, d.z); o.at = Date.now(); o.dirty = 1;
  /* sessions: the first watch and rewatches — counters that only grow */
  if (d.sess) { o.cs = o.cs || {}; const c = o.cs[d.sess] || (o.cs[d.sess] = { ws: 0, rws: 0, at: Date.now() }); c.ws = Math.max(c.ws, +d.ws || 0); const add = Math.max(0, (+d.rws || 0) - c.rws); c.rws = Math.max(c.rws, +d.rws || 0); o.rws = (o.rws || 0) + add;
    const need = Math.min(30, (o.d || 60) * 0.5), needR = Math.min(30, (o.d || 60) * 0.3);
    if (!c.n && c.ws >= need) { c.n = 1; o.n = (o.n || 0) + 1; if (!o.f) o.f = Date.now(); }
    if (!c.r && c.rws >= needR) { c.r = 1; o.rw = (o.rw || 0) + 1; }
    const keys = Object.keys(o.cs).sort((a, b) => o.cs[b].at - o.cs[a].at); for (const x of keys.slice(6)) delete o.cs[x]; }
  await chrome.storage.local.set({ [k]: o });
  const pc = o.d ? Math.min(100, Math.round(o.z.reduce((s, z) => s + z[1] - z[0], 0) / o.d * 100)) : 0;
  try { const r = await relay('yt-watch', { id: d.id, d: o.d, z: o.z, n: o.n || 0, rw: o.rw || 0, rws: Math.round(o.rws || 0), f: o.f || 0 }, true); if (r && r.ok) { o.dirty = 0; await chrome.storage.local.set({ [k]: o }); } } catch (e) { /* later */ }
  return { ok: true, data: { pc, z: o.z, d: o.d, n: o.n || 0, rw: o.rw || 0 } };
}
async function ywFlush() {
  const all = await chrome.storage.local.get(null), keys = Object.keys(all).filter(k => k.startsWith('yw:') && all[k] && all[k].dirty); if (!keys.length) return;
  const id = await holstTab(false); if (!id) return;
  for (const k of keys.slice(0, 200)) { const o = all[k]; try { const r = await relay('yt-watch', { id: k.slice(3), d: o.d, z: o.z, n: o.n || 0, rw: o.rw || 0, rws: Math.round(o.rws || 0), f: o.f || 0 }, true); if (r && r.ok) { o.dirty = 0; await chrome.storage.local.set({ [k]: o }); } } catch (e) { return; } }
}

/* ===================== v2.21 ===================== */
const sleep221 = ms => new Promise(r => setTimeout(r, ms));
const exec221 = (tabId, func, args) => chrome.scripting.executeScript({ target: { tabId }, func, args: args || [] }).then(r => r && r[0] && r[0].result);
/* screenshots that scroll: the page itself or the block that scrolls inside it (a chat, a mailbox) */
function pickScroller221() {
  document.querySelectorAll('[data-hshot221]').forEach(n => n.removeAttribute('data-hshot221'));
  const de = document.scrollingElement || document.documentElement; if (de.scrollHeight > innerHeight + 120) return false;
  let best = null, bs = 0;
  for (const el of document.querySelectorAll('body *')) { if (el.scrollHeight <= el.clientHeight + 40 || el.clientHeight < 200) continue; const cs = getComputedStyle(el); if (!/(auto|scroll|overlay)/.test(cs.overflowY)) continue; const r = el.getBoundingClientRect(); if (r.width < 240) continue; const s = r.width * Math.min(r.height, innerHeight); if (s > bs) { bs = s; best = el; } }
  if (best) { best.setAttribute('data-hshot221', '1'); return true; } return false;
}
async function stitch221(tabId, windowId, o) {
  if (o.full) o.el = await exec221(tabId, pickScroller221);
  const D = await exec221(tabId, sel => { const el = sel ? document.querySelector('[data-hshot221]') : null, sc = el || document.scrollingElement || document.documentElement, box = el ? el.getBoundingClientRect() : { left: 0, top: 0 };
    const s = { top: Math.max(0, box.top), left: Math.max(0, box.left), vw: el ? el.clientWidth : innerWidth, vh: el ? Math.min(el.clientHeight, innerHeight - Math.max(0, box.top)) : innerHeight, y: el ? el.scrollTop : scrollY, H: sc.scrollHeight, iw: innerWidth, sb: sc.style.scrollBehavior };
    sc.style.scrollBehavior = 'auto'; return s; }, [!!o.el]);
  const y0 = o.y0 != null ? o.y0 : 0, H = Math.min(o.h != null ? o.h : D.H - y0, 30000), x = o.x != null ? o.x : D.left, w = o.w != null ? o.w : D.vw;
  let cv = null, g = null, k = 1;
  try {
    for (let y = y0, first = true; y < y0 + H; y += D.vh, first = false) {
      const at = await exec221(tabId, (yy, sel, hide) => { const el = sel ? document.querySelector('[data-hshot221]') : null; if (el) el.scrollTop = yy; else scrollTo(scrollX, yy);
        if (hide) for (const n of document.querySelectorAll('body *')) { const p = getComputedStyle(n).position; if ((p === 'fixed' || p === 'sticky') && !n.dataset.hst && !(el && n.contains(el))) { n.dataset.hst = n.style.visibility || '-'; n.style.visibility = 'hidden'; } }
        return el ? el.scrollTop : scrollY; }, [y, !!o.el, !first || !!o.el]);
      await sleep221(600);
      const url = await chrome.tabs.captureVisibleTab(windowId, { format: 'png' }), bmp = await createImageBitmap(await (await fetch(url)).blob());
      if (!cv) { k = bmp.width / D.iw; cv = new OffscreenCanvas(Math.max(1, Math.round(w * k)), Math.max(1, Math.round(H * k))); g = cv.getContext('2d'); }
      const from = Math.max(y, at), to = Math.min(y0 + H, at + D.vh); if (to > from) g.drawImage(bmp, Math.round(x * k), Math.round((D.top + from - at) * k), Math.round(w * k), Math.round((to - from) * k), 0, Math.round((from - y0) * k), Math.round(w * k), Math.round((to - from) * k));
      if (at + D.vh >= D.H - 1) break;
    }
  } finally {
    await exec221(tabId, (s, sel) => { for (const n of document.querySelectorAll('[data-hst]')) { n.style.visibility = n.dataset.hst === '-' ? '' : n.dataset.hst; delete n.dataset.hst; } const el = sel ? document.querySelector('[data-hshot221]') : null; if (el) { el.scrollTop = s.y; el.style.scrollBehavior = s.sb || ''; } else { scrollTo(scrollX, s.y); (document.scrollingElement || document.documentElement).style.scrollBehavior = s.sb || ''; } }, [D, !!o.el]).catch(() => {});
  }
  if (!cv) throw new Error('снимок не получился');
  let out = cv; const kk = Math.min(1, 2400 / cv.width); if (kk < 1) { out = new OffscreenCanvas(Math.round(cv.width * kk), Math.round(cv.height * kk)); out.getContext('2d').drawImage(cv, 0, 0, out.width, out.height); }
  const blob = await out.convertToBlob({ type: 'image/jpeg', quality: 0.84 }), buf = new Uint8Array(await blob.arrayBuffer());
  let bin = ''; for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  return 'data:image/jpeg;base64,' + btoa(bin);
}
/* a chat of Claude, as it is: iterations, the thinking, files, artifacts */
function claudeChat221() {
  const q = (r, s) => r.querySelector(s), qa = (r, s) => [...r.querySelectorAll(s)];
  const clean = el => { const c = el.cloneNode(true); qa(c, 'button, svg, [role="button"], .sr-only, [aria-hidden="true"], textarea, input').forEach(n => n.remove()); return c.innerHTML; };
  const title = ((q(document, '[data-testid="chat-title-button"]') || q(document, '[data-testid="chat-menu-trigger"]') || {}).textContent || document.title.replace(/\s*[-–|]\s*Claude\s*$/i, '')).trim();
  const projA = q(document, 'a[href^="/project/"]'), project = projA ? projA.textContent.trim() : '';
  const U = qa(document, '[data-testid="user-message"]');
  let A = qa(document, '.font-claude-response, .font-claude-message, [data-testid="assistant-message"]'); A = A.filter(a => !A.some(b => b !== a && b.contains(a)));
  const all = U.map(e => ({ r: 'u', e })).concat(A.map(e => ({ r: 'a', e }))).sort((x, y) => (x.e.compareDocumentPosition(y.e) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1));
  const turns = []; let cur = null;
  const boxOf = e => e.closest('[data-test-render-count]') || (e.parentElement && e.parentElement.parentElement) || e;
  for (const m of all) {
    if (m.r === 'u') { cur = { u: { html: clean(m.e), text: (m.e.innerText || '').trim(), files: [] }, a: null, arts: [] }; turns.push(cur);
      for (const f of qa(boxOf(m.e), '[data-testid="file-thumbnail"], [data-testid*="attachment"]')) { const n = ((f.getAttribute('title') || f.innerText || '') + '').trim().split('\n')[0].slice(0, 120); if (n && !cur.u.files.some(x => x.name === n)) cur.u.files.push({ name: n }); }
      continue; }
    if (!cur) { cur = { u: null, a: null, arts: [] }; turns.push(cur); }
    const box = boxOf(m.e); let think = null;
    const tb = qa(box, 'button, [role="button"], summary').find(b => /thought|thinking|размышл|думал/i.test(b.innerText || ''));
    if (tb) { const reg = (tb.closest('details') || tb.parentElement || tb).nextElementSibling || (tb.closest('div') || tb).nextElementSibling; const t = reg && !m.e.contains(reg) ? (reg.innerText || '').trim() : ''; if (t.length > 20) think = { text: t.slice(0, 20000) }; }
    const html = clean(m.e), text = (m.e.innerText || '').trim();
    if (cur.a) { cur.a.html += html; cur.a.text += '\n' + text; } else cur.a = { html, text, think };
    for (const x of qa(box, '[data-testid*="artifact"], .artifact-block-cell, [class*="artifact-block"]')) { const t = ((x.innerText || '') + '').trim().split('\n').filter(Boolean); if (!t[0] || cur.arts.some(a => a.title === t[0])) continue; const ln = x.closest('a[href]') || q(x, 'a[href]'); cur.arts.push({ title: t[0].slice(0, 120), kind: (t[1] || '').slice(0, 60), url: ln ? ln.href : '' }); }
  }
  return { title: title || 'Чат Claude', project, shared: /^\/share\//.test(location.pathname), url: location.origin + location.pathname, turns, n: turns.length };
}
async function claude221(tabId, o = {}) {
  const C = await exec221(tabId, claudeChat221); if (!C) throw new Error('не чат Claude');
  /* an open artifact: its page as HTML, so a private one works on the board too */
  try {
    const R = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: () => /claudeusercontent\.com$/.test(location.hostname) && document.documentElement ? { t: document.title || '', html: '<!doctype html>' + document.documentElement.outerHTML } : null });
    const L = (R || []).map(r => r.result).filter(x => x && x.html && x.html.length > 200);
    if (L.length && C.turns.length) { const last = C.turns[C.turns.length - 1]; for (const f of L) { const a = last.arts.find(x => x.title && f.t && (x.title.includes(f.t) || f.t.includes(x.title))) || null; if (a) a.html = f.html; else last.arts.push({ title: f.t || 'Артефакт', kind: 'HTML', html: f.html }); } }
  } catch (e) { /* no frames */ }
  return C;
}
/* the video frame under the right click */
function vFrame221() {
  const v = [...document.querySelectorAll('video')].filter(x => x.videoWidth).sort((a, b) => b.getBoundingClientRect().width - a.getBoundingClientRect().width)[0]; if (!v) return { err: 'видео не найдено' };
  try { const k = Math.min(1, 1920 / v.videoWidth), c = document.createElement('canvas'); c.width = Math.round(v.videoWidth * k); c.height = Math.round(v.videoHeight * k); c.getContext('2d').drawImage(v, 0, 0, c.width, c.height); return { img: c.toDataURL('image/jpeg', 0.88), at: v.currentTime }; }
  catch (e) { const r = v.getBoundingClientRect(); return { at: v.currentTime, rect: { x: r.left, y: r.top, w: r.width, h: r.height, vw: innerWidth } }; }
}
async function img64221(url) { const b = await (await fetch(url)).blob(), buf = new Uint8Array(await b.arrayBuffer()); let bin = ''; for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000)); return 'data:' + (b.type || 'image/png') + ';base64,' + btoa(bin); }
async function ctxMenu221(id, info, tab, host) {
  const base = { v217: 1, title: tab.title, url: tab.url, site: host, rel: [], ai: { on: 0 } }, text = String(info.selectionText || '').trim();
  const focus = async () => { const hid = await holstTab(false); if (hid) { const t = await chrome.tabs.update(hid, { active: true }); chrome.windows.update(t.windowId, { focused: true }).catch(() => {}); } };
  const K = { 'sel-board': 'board', 'sel-term': 'term', 'sel-card': 'card', 'sel-kb': 'kb', 'sel-ask': 'ask', 'sel-search': 'search' }[id];
  if (K) { if (!text) return true; let r; try { r = await relay('ctx221', { kind: K, text, url: tab.url, title: tab.title, site: host }); } catch (e) { r = await queued('ctx221', { kind: K, text, url: tab.url, title: tab.title, site: host }); } mark(tab.id, r && r.ok !== false ? { ok: true, queued: r && r.queued } : r); if (K === 'ask' || K === 'search') await focus(); return true; }
  if (id === 'link-board') { mark(tab.id, await clip(Object.assign({}, base, { title: text || info.linkUrl, url: info.linkUrl, where: { board: 1 }, view: 'card' }))); return true; }
  if (id === 'link-task') { mark(tab.id, await clip(Object.assign({}, base, { title: 'Прочитать: ' + (text || info.linkUrl), url: info.linkUrl, where: { lo: 1 }, ek: 'task' }))); return true; }
  if (id === 'link-kb') { let r; try { r = await relay('kb-add', { url: info.linkUrl }); } catch (e) { r = { ok: false }; } mark(tab.id, r); return true; }
  if (id === 'img-lo') { let image = ''; try { image = await img64221(info.srcUrl); } catch (e) { image = ''; } mark(tab.id, await clip(Object.assign({}, base, { noEmbed: 1, image, where: { lo: 1 }, ek: 'resource' }))); return true; }
  if (id === 'video-frame') {
    const r = await exec221(tab.id, vFrame221).catch(() => null); let image = r && r.img;
    if (!image && r && r.rect) { const url = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' }), bmp = await createImageBitmap(await (await fetch(url)).blob()), d = bmp.width / (r.rect.vw || bmp.width), c = new OffscreenCanvas(Math.round(r.rect.w * d), Math.round(r.rect.h * d)); c.getContext('2d').drawImage(bmp, r.rect.x * d, r.rect.y * d, c.width, c.height, 0, 0, c.width, c.height); const b = new Uint8Array(await (await c.convertToBlob({ type: 'image/jpeg', quality: 0.88 })).arrayBuffer()); let bin = ''; for (let i = 0; i < b.length; i += 0x8000) bin += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000)); image = 'data:image/jpeg;base64,' + btoa(bin); }
    if (!image) { mark(tab.id, { ok: false }); return true; }
    mark(tab.id, await clip(Object.assign({}, base, { noEmbed: 1, image, where: { board: 1 }, parts: { frameAt: r && r.at } }))); return true;
  }
  if (id === 'page-full') { let image = ''; try { image = await stitch221(tab.id, tab.windowId, { full: 1 }); } catch (e) { mark(tab.id, { ok: false }); return true; } mark(tab.id, await clip(Object.assign({}, base, { image, shot: 'full', where: { board: 1 } }))); return true; }
  if (id === 'page-area') { await chrome.storage.local.set({ pending: Object.assign({}, base, { shot: 'area', where: { board: 1 } }) }); await areaStart(tab.id); return true; }
  if (id === 'page-claude') { try { const C = await claude221(tab.id); mark(tab.id, await clip(Object.assign({}, base, { title: C.title, url: C.url, claude221: C, where: { board: 1 } }))); } catch (e) { mark(tab.id, { ok: false }); } return true; }
  return false;
}
/* hiding a channel in the feed: here at once, in Холст for keeps */
async function ytBlock221(d) {
  if (!d || !d.ch) return { ok: false }; const B = (await chrome.storage.local.get('yb221')).yb221 || {};
  if (d.off) delete B[d.ch]; else B[d.ch] = { n: d.n || d.ch, until: +d.until || 0, at: Date.now(), url: d.url || '' };
  await chrome.storage.local.set({ yb221: B });
  try { await relay(d.off ? 'yt-unblock' : 'yt-block', d, true); } catch (e) { await queued(d.off ? 'yt-unblock' : 'yt-block', d); }
  return { ok: true };
}

/* v2.23: the formatting of a Whimsical board — the board opens in a background tab, whim.js takes the copy */
async function whimGrab223(d) {
  const url = String((d && d.url) || ''); if (!/^https:\/\/whimsical\.com\//.test(url)) return { ok: false, err: 'не ссылка Whimsical' };
  const tab = await chrome.tabs.create({ url, active: false });
  try {
    const t0 = Date.now();
    while (Date.now() - t0 < 40000) { const t = await chrome.tabs.get(tab.id); if (t.status === 'complete') break; await new Promise(r => setTimeout(r, 500)); }
    for (let i = 0; i < 12; i++) {
      try { const r = await chrome.tabs.sendMessage(tab.id, { op: 'whim-grab' }); if (r) return r; } catch (e) { /* the script is not ready yet */ }
      if (i === 3) { try { await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['whim.js'] }); } catch (e) { /* ignore */ } }
      await new Promise(r => setTimeout(r, 1500));
    }
    return { ok: false, err: 'вкладка Whimsical не ответила' };
  } finally { try { await chrome.tabs.remove(tab.id); } catch (e) { /* closed already */ } }
}
