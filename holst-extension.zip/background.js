/* Finds (or opens) the Холст tab and relays requests from the popup and the widgets. */
const DEF_URL = 'https://podkindmitry.github.io/holst/';
const holstUrl = async () => ((await chrome.storage.local.get('holstUrl')).holstUrl || DEF_URL);
let readyWaiters = [];
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.op === 'bridge-ready') { const w = readyWaiters; readyWaiters = []; w.forEach(f => f(sender.tab && sender.tab.id)); return; }
  if (!msg || msg.to !== 'bg') return;
  if (msg.op === 'badge') { const n = +(msg.data && msg.data.n) || 0; chrome.action.setBadgeBackgroundColor({ color: '#8b5cf6' }); chrome.action.setBadgeText({ text: n ? (n > 99 ? '99+' : String(n)) : '' }); reply({ ok: true }); return; }
  if (msg.op === 'fetch') { xfetch(msg.data, sender).then(reply, e => reply({ ok: false, err: String(e && e.message || e) })); return true; }
  if (msg.op === 'kbfetch') { kbfetch(msg.data, sender).then(reply, e => reply({ ok: false, err: String(e && e.message || e) })); return true; }
  relay(msg.op, msg.data).then(reply, e => reply({ ok: false, data: String(e && e.message || e) }));
  return true;
});
async function holstTab(open) {
  const base = await holstUrl();
  const tabs = await chrome.tabs.query({ url: base + '*' });
  if (tabs.length) return tabs[0].id;
  if (!open) return null;
  const t = await chrome.tabs.create({ url: base, active: false, pinned: true });
  await new Promise(res => { const to = setTimeout(res, 12000); readyWaiters.push(() => { clearTimeout(to); setTimeout(res, 1800); }); });
  return t.id;
}
async function relay(op, data) {
  let id = await holstTab(true);
  try { await ensureBridge(id); return await chrome.tabs.sendMessage(id, { to: 'holst', op, data }); }
  catch (e) { await new Promise(r => setTimeout(r, 1500)); id = await holstTab(true); await ensureBridge(id); return chrome.tabs.sendMessage(id, { to: 'holst', op, data }); }
}
async function ensureBridge(tabId) {
  try { await chrome.scripting.executeScript({ target: { tabId }, files: ['bridge.js'] }); } catch (e) { /* already there or not allowed */ }
}
/* right click on a page, a selection, a link or a picture */
/* v2.16: tabs opened before the extension was installed or updated get the widget and the YouTube button without a reload */
chrome.runtime.onInstalled.addListener(async () => {
  const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] }).catch(() => []);
  for (const t of tabs) { if (/^https:\/\/podkindmitry\.github\.io\/holst\//.test(t.url || '')) continue; chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['widget.js'] }).catch(() => {}); if (/^https:\/\/www\.youtube\.com\//.test(t.url || '')) chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['yt.js'] }).catch(() => {}); }
});
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id: 'holst-page', title: 'В Холст: страница задачей', contexts: ['page', 'selection', 'link', 'image'] });
  chrome.contextMenus.create({ id: 'holst-board', title: 'В Холст: на доску', contexts: ['page', 'selection', 'link', 'image'] });
  chrome.contextMenus.create({ id: 'holst-widget', title: 'Холст: виджет задач на этом сайте', contexts: ['page'] });
});
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === 'holst-widget') { const r = (await chrome.storage.local.get('widgets')).widgets || {}; const h = new URL(tab.url).hostname; r['site:' + h] = { on: 1, mode: 'page', scope: 'site' }; await chrome.storage.local.set({ widgets: r }); chrome.tabs.sendMessage(tab.id, { op: 'widget-refresh' }).catch(() => {}); return; }
  let image = '';
  if (info.mediaType === 'image' && info.srcUrl) { try { const b = await (await fetch(info.srcUrl)).blob(); image = await new Promise(res => { const r = new FileReader(); r.onload = () => res(r.result); r.readAsDataURL(b); }); } catch (e) { /* link only */ } }
  const url = info.linkUrl || tab.url, title = info.linkUrl ? (info.selectionText || info.linkUrl) : tab.title;
  const res = await relay('clip', { kind: info.menuItemId === 'holst-board' ? 'board' : 'task', title, url, text: info.selectionText || '', image, site: new URL(tab.url).hostname });
  chrome.action.setBadgeText({ text: res && res.ok && res.data && res.data.ok !== false ? '✓' : '!', tabId: tab.id }); setTimeout(() => chrome.action.setBadgeText({ text: '', tabId: tab.id }), 2500);
});

/* v2.13: a request for the Холст page — only from the Холст tab, only to AI services and Google */
const XOK = [/^https:\/\/api\.anthropic\.com\//, /^https:\/\/[a-z0-9.-]+\.(openai|groq|cerebras|mistral|deepseek|x|together|cohere|perplexity)\.(com|ai|xyz)\//, /^https:\/\/(openrouter\.ai|api\.x\.ai|api\.deepseek\.com|integrate\.api\.nvidia\.com|router\.huggingface\.co|generativelanguage\.googleapis\.com|dashscope-intl\.aliyuncs\.com|api\.perplexity\.ai)\//];
async function xfetch(d, sender) {
  const base = await holstUrl(), from = (sender && sender.tab && sender.tab.url) || '';
  if (!from.startsWith(base) && !/^http:\/\/localhost/.test(from)) return { ok: false, err: 'запрос не из вкладки Холста' };
  if (!XOK.some(r => r.test(d.url))) return { ok: false, err: 'этот адрес расширение не пропускает' };
  const r = await fetch(d.url, { method: (d.init && d.init.method) || 'GET', headers: (d.init && d.init.headers) || {}, body: d.init && d.init.body });
  const headers = {}; r.headers.forEach((v, k) => { headers[k] = v; });
  return { ok: true, status: r.status, statusText: r.statusText, headers, body: await r.text() };
}

/* v2.14: pages for «Источники» — articles, Telegram channels, YouTube pages and transcripts.
   Only from the Холст tab; reading only (GET), except YouTube's own transcript request.
   v2.15: the same reading road brings boards from Miro and files from FigJam. */
async function kbfetch(d, sender) {
  const base = await holstUrl(), from = (sender && sender.tab && sender.tab.url) || '';
  if (!from.startsWith(base) && !/^http:\/\/localhost/.test(from)) return { ok: false, err: 'запрос не из вкладки Холста' };
  const u = String(d.url || ''), m = ((d.init && d.init.method) || 'GET').toUpperCase();
  if (!/^https:\/\//.test(u)) return { ok: false, err: 'только https' };
  if (m !== 'GET' && !/^https:\/\/www\.youtube\.com\/youtubei\/v1\/get_transcript/.test(u)) return { ok: false, err: 'расширение только читает страницы' };
  const r = await fetch(u, { method: m, headers: (d.init && d.init.headers) || {}, body: m === 'GET' ? undefined : d.init.body, credentials: /^https:\/\/api\.(miro|figma)\.com\//.test(u) ? 'omit' : 'include' });
  /* v2.15: pictures for the Miro and FigJam import come back as data */
  if (d.init && d.init.bin) {
    if (!r.ok) return { ok: true, status: r.status, body: '' };
    const buf = await r.arrayBuffer(); if (buf.byteLength > 12e6) return { ok: true, status: 413, body: '' };
    let bin = ''; const u8 = new Uint8Array(buf); for (let i = 0; i < u8.length; i += 0x8000) bin += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
    return { ok: true, status: r.status, body: 'data:' + (r.headers.get('content-type') || 'application/octet-stream').split(';')[0] + ';base64,' + btoa(bin) };
  }
  const body = await r.text();
  return { ok: true, status: r.status, body: body.length > 8e6 ? body.slice(0, 8e6) : body };
}
