/* Холст — the extension's background (v2.17).
   Finds (or opens) the Холст tab and relays requests from the popup, the widgets, YouTube.
   v2.17: a queue when Холст is closed; quick save without the popup; selected text into
   the page's element or as its own record; highlights; a snapshot of an area; all tabs;
   settings and widgets kept in Холст and returned after a reinstall; one-click update. */
const DEF_URL = 'https://podkindmitry.github.io/holst/';
const holstUrl = async () => ((await chrome.storage.local.get('holstUrl')).holstUrl || DEF_URL);
let readyWaiters = [];
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.op === 'bridge-ready') { const w = readyWaiters; readyWaiters = []; w.forEach(f => f(sender.tab && sender.tab.id)); setTimeout(flushQueue, 2500); setTimeout(restoreState, 3000); return; }
  if (msg && msg.op === 'area-rect') { areaDone(msg.rect, sender.tab).then(reply, e => reply({ ok: false, data: String(e && e.message || e) })); return true; }
  if (!msg || msg.to !== 'bg') return;
  if (msg.op === 'badge') { const n = +(msg.data && msg.data.n) || 0; chrome.action.setBadgeBackgroundColor({ color: '#8b5cf6' }); chrome.action.setBadgeText({ text: n ? (n > 99 ? '99+' : String(n)) : '' }); reply({ ok: true }); return; }
  if (msg.op === 'fetch') { xfetch(msg.data, sender).then(reply, e => reply({ ok: false, err: String(e && e.message || e) })); return true; }
  if (msg.op === 'kbfetch') { kbfetch(msg.data, sender).then(reply, e => reply({ ok: false, err: String(e && e.message || e) })); return true; }
  if (msg.op === 'reload') { reply({ ok: true }); setTimeout(() => chrome.runtime.reload(), 300); return; }
  if (msg.op === 'area-start') { areaStart(msg.data.tabId).then(reply, e => reply({ ok: false, data: String(e && e.message || e) })); return true; }
  if (msg.op === 'tabs-all') { tabsAll(msg.data).then(reply, e => reply({ ok: false, data: String(e && e.message || e) })); return true; }
  if (msg.op === 'open') { openIn(msg.data).then(reply, e => reply({ ok: false, data: String(e && e.message || e) })); return true; }
  if (msg.op === 'clip') { clip(msg.data).then(reply, e => reply({ ok: false, data: String(e && e.message || e) })); return true; }
  relay(msg.op, msg.data).then(reply, e => reply({ ok: false, data: String(e && e.message || e) }));
  return true;
});
async function holstTab(open) {
  const base = await holstUrl();
  const tabs = await chrome.tabs.query({ url: base + '*' });
  if (tabs.length) return tabs[0].id;
  if (!open) return null;
  const t = await chrome.tabs.create({ url: base, active: false, pinned: true });
  await new Promise(res => { const to = setTimeout(res, 12000); readyWaiters.push(() => { clearTimeout(to); setTimeout(res, 1800); }); });
  return t.id;
}
async function relay(op, data, noOpen) {
  let id = await holstTab(!noOpen); if (!id) throw new Error('Холст закрыт');
  try { await ensureBridge(id); return await chrome.tabs.sendMessage(id, { to: 'holst', op, data }); }
  catch (e) { await new Promise(r => setTimeout(r, 1500)); id = await holstTab(!noOpen); if (!id) throw e; await ensureBridge(id); return chrome.tabs.sendMessage(id, { to: 'holst', op, data }); }
}
async function ensureBridge(tabId) {
  try { await chrome.scripting.executeScript({ target: { tabId }, files: ['bridge.js'] }); } catch (e) { /* already there or not allowed */ }
}
/* ---------- the queue: nothing is lost when Холст is closed or not answering ---------- */
async function clip(d) {
  try { const r = await relay('clip', d); if (r && r.ok) return r; throw new Error((r && r.data) || 'нет ответа'); }
  catch (e) { const q = (await chrome.storage.local.get('queue')).queue || []; q.push({ d, at: Date.now() }); await chrome.storage.local.set({ queue: q.slice(-200) }); badgeQ(q.length); return { ok: true, queued: true, data: { ok: true } }; }
}
async function flushQueue() {
  const q = (await chrome.storage.local.get('queue')).queue || []; if (!q.length) return;
  const id = await holstTab(false); if (!id) return;
  const left = [];
  for (const x of q) { try { const r = await relay('clip', x.d, true); if (!(r && r.ok)) left.push(x); } catch (e) { left.push(x); } }
  await chrome.storage.local.set({ queue: left }); badgeQ(left.length);
}
const badgeQ = n => { chrome.action.setBadgeBackgroundColor({ color: '#d97706' }); chrome.action.setBadgeText({ text: n ? String(n) : '' }); };
chrome.alarms && chrome.alarms.onAlarm.addListener(a => { if (a.name === 'queue') flushQueue(); });
/* ---------- open something in Холст and show the tab ---------- */
async function openIn(d) {
  const r = await relay(d.ai ? 'open-ai' : 'open', d); const id = await holstTab(false);
  if (id) { const t = await chrome.tabs.update(id, { active: true }); chrome.windows.update(t.windowId, { focused: true }).catch(() => {}); }
  return r;
}
/* ---------- quick save: the page, with the choice remembered for this site ---------- */
chrome.commands.onCommand.addListener(async cmd => {
  if (cmd !== 'quick-save') return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); if (!tab || !/^https?:/.test(tab.url || '')) return;
  const r = await quickSave(tab); mark(tab.id, r);
});
async function pageMeta(tabId) {
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: () => {
      const q = s => document.querySelector(s), m = n => ((q(`meta[property="${n}"]`) || q(`meta[name="${n}"]`) || {}).content || '').trim();
      const ico = q('link[rel~="icon"], link[rel="apple-touch-icon"]'); let fav = ''; try { fav = ico ? new URL(ico.getAttribute('href'), location.href).href : location.origin + '/favicon.ico'; } catch (e) { fav = ''; }
      return { title: m('og:title') || document.title, desc: m('og:description') || m('description'), img: m('og:image'), site: m('og:site_name') || location.hostname.replace(/^www\./, ''), fav, sel: String(getSelection() || '').trim() };
    } });
    return (r && r.result) || {};
  } catch (e) { return {}; }
}
async function quickSave(tab, extra) {
  const host = (() => { try { return new URL(tab.url).hostname; } catch (e) { return ''; } })(), st = await chrome.storage.local.get(['sites', 'last']), R = (st.sites && st.sites[host]) || st.last || {};
  const P = await pageMeta(tab.id), where = new Set(R.where || ['lo']);
  return clip(Object.assign({ v217: 1, title: P.title || tab.title, url: tab.url, site: host, text: (R.take || []).includes('desc') ? P.desc || '' : '', desc: P.desc || '', meta: { img: P.img, fav: P.fav, site: P.site, desc: (P.desc || '').slice(0, 400) }, where: { lo: where.has('lo') ? 1 : 0, board: where.has('board') ? 1 : 0, kb: where.has('kb') ? 1 : 0 }, ek: R.ek || 'resource', view: R.view || 'card', rel: [], ai: { on: 0 } }, extra || {}));
}
const mark = (tabId, r) => { const ok = r && r.ok; chrome.action.setBadgeBackgroundColor({ color: ok ? (r.queued ? '#d97706' : '#2fa36b') : '#e5484d', tabId }); chrome.action.setBadgeText({ text: ok ? (r.queued ? '…' : '✓') : '!', tabId }); setTimeout(() => chrome.action.setBadgeText({ text: '', tabId }), 2500); };
/* ---------- all tabs of the window ---------- */
async function tabsAll(d) {
  let q = 0;
  for (const t of (d.tabs || []).slice(0, 100)) { const r = await clip({ v217: 1, title: t.title || t.url, url: t.url, site: t.site, where: { lo: 1 }, ek: 'resource', rel: d.rel || [], tags: ['вкладки'], ai: { on: 0 } }); if (r.queued) q++; }
  return { ok: true, queued: q };
}
/* ---------- a snapshot of an area: the page lets you draw a rectangle ---------- */
async function areaStart(tabId) { await chrome.scripting.executeScript({ target: { tabId }, files: ['area.js'] }); return { ok: true }; }
async function areaDone(rect, tab) {
  const st = await chrome.storage.local.get('pending'), d = st.pending; await chrome.storage.local.remove('pending'); if (!d || !rect) return { ok: false };
  const url = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
  const bmp = await createImageBitmap(await (await fetch(url)).blob()), k = rect.dpr || 1;
  const w = Math.max(1, Math.round(rect.w * k)), h = Math.max(1, Math.round(rect.h * k)), c = new OffscreenCanvas(w, h);
  c.getContext('2d').drawImage(bmp, Math.round(rect.x * k), Math.round(rect.y * k), w, h, 0, 0, w, h);
  const blob = await c.convertToBlob({ type: 'image/jpeg', quality: 0.86 }), buf = new Uint8Array(await blob.arrayBuffer());
  let bin = ''; for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  d.image = 'data:image/jpeg;base64,' + btoa(bin);
  const r = await clip(d); mark(tab.id, r); return r;
}
/* ---------- right click ---------- */
function menus() {
  chrome.contextMenus.removeAll(() => {
    const C = (id, title, contexts, parentId) => chrome.contextMenus.create(Object.assign({ id, title, contexts }, parentId ? { parentId } : {}));
    C('holst', 'Холст', ['page', 'selection', 'link', 'image']);
    C('hl-notes', 'Выделенное → в текст элемента этой страницы', ['selection'], 'holst');
    C('hl-entity', 'Выделенное → отдельной заметкой, связанной со страницей', ['selection'], 'holst');
    C('hl-task', 'Выделенное → задачей к этой странице', ['selection'], 'holst');
    C('page-save', 'Сохранить страницу — сразу, как для этого сайта', ['page'], 'holst');
    C('link-save', 'Ссылку — в Холст материалом', ['link'], 'holst');
    C('img-board', 'Картинку — на доску', ['image'], 'holst');
    C('page-widget', 'Виджет задач на этом сайте', ['page'], 'holst');
  });
}
chrome.runtime.onInstalled.addListener(menus);
chrome.runtime.onStartup && chrome.runtime.onStartup.addListener(menus);
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const id = info.menuItemId, host = (() => { try { return new URL(tab.url).hostname; } catch (e) { return ''; } })();
  if (id === 'page-widget') { const r = (await chrome.storage.local.get('widgets')).widgets || {}; r['site:' + host] = Object.assign({}, r['site:' + host] || {}, { on: 1, mode: 'page', scope: 'site' }); await chrome.storage.local.set({ widgets: r }); chrome.tabs.sendMessage(tab.id, { op: 'widget-refresh' }).catch(() => {}); return; }
  if (/^hl-/.test(id)) {
    const text = String(info.selectionText || '').trim(); if (!text) return;
    let r; try { r = await relay('hl', { url: tab.url, title: tab.title, site: host, text, mode: id === 'hl-notes' ? 'notes' : id === 'hl-task' ? 'task' : 'entity' }); } catch (e) { r = { ok: false }; }
    mark(tab.id, r && r.ok ? { ok: true } : r);
    if (r && r.ok) { chrome.tabs.sendMessage(tab.id, { op: 'hl-mark', text }).catch(() => {}); const k = 'hl:' + key(tab.url), st = await chrome.storage.local.get(k); await chrome.storage.local.set({ [k]: (st[k] || []).concat({ t: text.slice(0, 2000), at: Date.now() }).slice(-300) }); }
    return;
  }
  if (id === 'page-save') { mark(tab.id, await quickSave(tab)); return; }
  if (id === 'link-save') { mark(tab.id, await clip({ v217: 1, title: info.selectionText || info.linkUrl, url: info.linkUrl, site: host, where: { lo: 1 }, ek: 'resource', rel: [], ai: { on: 0 } })); return; }
  if (id === 'img-board') {
    let image = ''; try { const b = await (await fetch(info.srcUrl)).blob(); const buf = new Uint8Array(await b.arrayBuffer()); let bin = ''; for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000)); image = 'data:' + (b.type || 'image/png') + ';base64,' + btoa(bin); } catch (e) { /* the link only */ }
    mark(tab.id, await clip({ v217: 1, title: tab.title, url: tab.url, noEmbed: 1, site: host, image, where: { board: 1 }, rel: [], ai: { on: 0 } }));
  }
});
const key = u => { try { const x = new URL(u); x.hash = ''; [...x.searchParams.keys()].filter(k => /^(utm_|fbclid|gclid|yclid)/.test(k)).forEach(k => x.searchParams.delete(k)); return x.href; } catch (e) { return String(u || ''); } };
/* ---------- after an install or an update: everything comes back ---------- */
chrome.runtime.onInstalled.addListener(async () => {
  chrome.alarms && chrome.alarms.create('queue', { periodInMinutes: 1 });
  const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] }).catch(() => []);
  for (const t of tabs) {
    if (/^https:\/\/podkindmitry\.github\.io\/holst\//.test(t.url || '')) { chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['bridge.js'] }).catch(() => {}); continue; }
    chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['widget.js', 'hl.js'] }).catch(() => {});
    if (/^https:\/\/www\.youtube\.com\//.test(t.url || '')) chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['yt.js'] }).catch(() => {});
  }
  setTimeout(restoreState, 4000);
});
/* the extension's settings and widgets live in Холст too: a new install gets them back */
const KEEP = ['widgets', 'last', 'sites', 'siteMem', 'holstUrl', 'ytPick'];
async function restoreState() {
  const st = await chrome.storage.local.get(KEEP.concat('restored217'));
  if (st.restored217 && st.widgets && Object.keys(st.widgets).length) return;
  let r; try { r = await relay('state-get', {}, true); } catch (e) { return; }
  const S = r && r.ok && r.data; if (!S) { chrome.storage.local.set({ restored217: 1 }); return; }
  const put = { restored217: 1 }; for (const k of KEEP) if (S[k] != null && (st[k] == null || (k === 'widgets' && !Object.keys(st[k] || {}).length))) put[k] = S[k];
  if (S.hl) for (const [k, v] of Object.entries(S.hl)) put[k] = v;
  await chrome.storage.local.set(put);
  const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] }).catch(() => []);
  for (const t of tabs) chrome.tabs.sendMessage(t.id, { op: 'widget-refresh' }).catch(() => {});
}
let saveT = 0;
chrome.storage.onChanged.addListener((ch, area) => {
  if (area !== 'local' || !Object.keys(ch).some(k => KEEP.includes(k) || k.startsWith('hl:'))) return;
  clearTimeout(saveT); saveT = setTimeout(async () => {
    const all = await chrome.storage.local.get(null), out = {}; for (const k of KEEP) if (all[k] != null) out[k] = all[k];
    out.hl = {}; for (const k of Object.keys(all)) if (k.startsWith('hl:')) out.hl[k] = all[k];
    out.v = chrome.runtime.getManifest().version; relay('state-set', out, true).catch(() => {});
  }, 1500);
});

/* v2.13: a request for the Холст page — only from the Холст tab, only to AI services and Google */
const XOK = [/^https:\/\/api\.anthropic\.com\//, /^https:\/\/[a-z0-9.-]+\.(openai|groq|cerebras|mistral|deepseek|x|together|cohere|perplexity)\.(com|ai|xyz)\//, /^https:\/\/(openrouter\.ai|api\.x\.ai|api\.deepseek\.com|integrate\.api\.nvidia\.com|router\.huggingface\.co|generativelanguage\.googleapis\.com|dashscope-intl\.aliyuncs\.com|api\.perplexity\.ai)\//];
async function xfetch(d, sender) {
  const base = await holstUrl(), from = (sender && sender.tab && sender.tab.url) || '';
  if (!from.startsWith(base) && !/^http:\/\/localhost/.test(from)) return { ok: false, err: 'запрос не из вкладки Холста' };
  if (!XOK.some(r => r.test(d.url))) return { ok: false, err: 'этот адрес расширение не пропускает' };
  const r = await fetch(d.url, { method: (d.init && d.init.method) || 'GET', headers: (d.init && d.init.headers) || {}, body: d.init && d.init.body });
  const headers = {}; r.headers.forEach((v, k) => { headers[k] = v; });
  return { ok: true, status: r.status, statusText: r.statusText, headers, body: await r.text() };
}

/* v2.14: pages for «Источники» — articles, Telegram channels, YouTube pages and transcripts.
   Only from the Холст tab; reading only (GET), except YouTube's own transcript request.
   v2.15: the same reading road brings boards from Miro and files from FigJam. */
async function kbfetch(d, sender) {
  const base = await holstUrl(), from = (sender && sender.tab && sender.tab.url) || '';
  if (!from.startsWith(base) && !/^http:\/\/localhost/.test(from)) return { ok: false, err: 'запрос не из вкладки Холста' };
  const u = String(d.url || ''), m = ((d.init && d.init.method) || 'GET').toUpperCase();
  if (!/^https:\/\//.test(u)) return { ok: false, err: 'только https' };
  if (m !== 'GET' && !/^https:\/\/www\.youtube\.com\/youtubei\/v1\/get_transcript/.test(u)) return { ok: false, err: 'расширение только читает страницы' };
  const r = await fetch(u, { method: m, headers: (d.init && d.init.headers) || {}, body: m === 'GET' ? undefined : d.init.body, credentials: /^https:\/\/api\.(miro|figma)\.com\//.test(u) ? 'omit' : 'include' });
  if (d.init && d.init.bin) {
    if (!r.ok) return { ok: true, status: r.status, body: '' };
    const buf = await r.arrayBuffer(); if (buf.byteLength > 12e6) return { ok: true, status: 413, body: '' };
    let bin = ''; const u8 = new Uint8Array(buf); for (let i = 0; i < u8.length; i += 0x8000) bin += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
    return { ok: true, status: r.status, body: 'data:' + (r.headers.get('content-type') || 'application/octet-stream').split(';')[0] + ';base64,' + btoa(bin) };
  }
  const body = await r.text();
  return { ok: true, status: r.status, body: body.length > 8e6 ? body.slice(0, 8e6) : body };
}
