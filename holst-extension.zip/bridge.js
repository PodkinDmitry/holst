/* Холст tab ⇄ extension: forwards requests to the page and returns its answers. */
(() => {
  /* v2.17: one live bridge per page. A copy left by the previous version of the extension is dead (its
     connection to the extension is gone) and does not answer the ping — then a new one starts. */
  const D = document.documentElement, was = D.dataset.holstBridgeAlive;
  document.dispatchEvent(new CustomEvent('holst-bridge-ping'));
  if (D.dataset.holstBridgeAlive !== was) return;
  document.addEventListener('holst-bridge-ping', () => { try { if (chrome.runtime.id) D.dataset.holstBridgeAlive = String(Math.random()); } catch (e) { /* this copy is dead */ } });
  window.__holstBridge = 1;
  const wait = new Map();
  window.addEventListener('message', e => {
    const m = e.data; if (e.source !== window || !m || m.__holst !== 'app' || !wait.has(m.id)) return;
    const f = wait.get(m.id); wait.delete(m.id); f(m);
  });
  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (!msg || msg.to !== 'holst') return;
    const id = 'x' + Math.random().toString(36).slice(2);
    const t = setTimeout(() => { if (wait.has(id)) { wait.delete(id); reply({ ok: false, data: 'Холст не ответил — обновите вкладку Холста' }); } }, 15000);
    wait.set(id, m => { clearTimeout(t); reply(m); });
    window.postMessage({ __holst: 'ext', id, op: msg.op, data: msg.data }, location.origin);
    return true;
  });
  chrome.runtime.sendMessage({ op: 'bridge-ready' }).catch(() => {});
  /* v2.13: the page asks the extension to make a request a site blocks for web pages (AI services, Claude routines) */
  const V = chrome.runtime.getManifest().version;
  try { document.documentElement.dataset.holstExt = V; } catch (e) { /* not yet */ }
  document.addEventListener('DOMContentLoaded', () => { document.documentElement.dataset.holstExt = V; });
  window.addEventListener('message', e => {
    const m = e.data; if (e.source !== window || !m || m.__holst !== 'app-req') return;
    try { if (!chrome.runtime.id) return; } catch (er) { return; }
    if (m.op === 'badge') { chrome.runtime.sendMessage({ to: 'bg', op: 'badge', data: { n: m.n } }).catch(() => {}); return; }
    if (m.op === 'ext-reload') { chrome.runtime.sendMessage({ to: 'bg', op: 'reload' }).catch(() => {}); return; }
    if (m.op !== 'fetch' && m.op !== 'kbfetch' && m.op !== 'whimgrab' && m.op !== 'ptget') return;
    chrome.runtime.sendMessage({ to: 'bg', op: m.op, data: { url: m.url, init: m.init } }).then(r => {
      window.postMessage(Object.assign({ __holst: 'ext-res', id: m.id }, r || { ok: false, err: 'нет ответа' }), location.origin);
    }).catch(err => window.postMessage({ __holst: 'ext-res', id: m.id, ok: false, err: String(err && err.message || err) }, location.origin));
  });
})();
