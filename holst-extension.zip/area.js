/* Холст: a snapshot of an area — draw a rectangle on the page; Esc cancels.
   v2.21: lead the mouse to the top or bottom edge — the page (or the block under the mouse) scrolls and the area
   grows beyond one screen; the snapshot is glued from screens. */
(() => {
  if (document.getElementById('holst-area')) return;
  const ov = document.createElement('div'); ov.id = 'holst-area';
  ov.style.cssText = 'position:fixed;inset:0;z-index:2147483647;cursor:crosshair;background:rgba(17,17,24,.28)';
  const box = document.createElement('div'); box.style.cssText = 'position:fixed;border:2px solid #7c3aed;background:rgba(124,58,237,.08);box-shadow:0 0 0 9999px rgba(17,17,24,.28);display:none;pointer-events:none';
  const tip = document.createElement('div'); tip.textContent = 'Выделите область для снимка в Холст · у края экрана страница прокрутится · Esc — отмена';
  tip.style.cssText = 'position:fixed;left:50%;top:14px;transform:translateX(-50%);padding:7px 14px;border-radius:999px;background:#1c1d21;color:#fff;font:600 13px system-ui,sans-serif;pointer-events:none;z-index:2147483647;white-space:nowrap';
  ov.append(box, tip); document.documentElement.appendChild(ov);
  let x0 = 0, y0 = 0, on = false, sc = null, cx = 0, cy = 0, raf = 0, moved = false;
  /* what scrolls under the mouse: a block inside the page, or the page */
  const scrollerAt = (x, y) => {
    ov.style.pointerEvents = 'none'; let el = document.elementFromPoint(x, y); ov.style.pointerEvents = '';
    for (; el && el !== document.body && el !== document.documentElement; el = el.parentElement) { const cs = getComputedStyle(el); if (/(auto|scroll|overlay)/.test(cs.overflowY) && el.scrollHeight > el.clientHeight + 20 && el.clientHeight > 120) return el; }
    return null;
  };
  const top0 = () => (sc ? sc.getBoundingClientRect().top - sc.scrollTop : -scrollY); /* client y of the scroll origin */
  const draw = () => { const t = top0(), y1 = cy - t, a = Math.min(y0, y1), b = Math.max(y0, y1), x = Math.min(x0, cx); Object.assign(box.style, { left: x + 'px', top: (a + t) + 'px', width: Math.abs(cx - x0) + 'px', height: (b - a) + 'px' }); };
  const auto = () => {
    if (!on) return; const edge = 46, dy = cy > innerHeight - edge ? 22 : cy < edge ? -22 : 0;
    if (dy) { if (sc) sc.scrollTop += dy; else scrollBy(0, dy); moved = true; draw(); }
    raf = requestAnimationFrame(auto);
  };
  const end = () => { cancelAnimationFrame(raf); ov.remove(); removeEventListener('keydown', key, true); };
  const key = e => { if (e.key === 'Escape') { e.preventDefault(); end(); chrome.runtime.sendMessage({ op: 'area-rect', rect: null }).catch(() => {}); } };
  addEventListener('keydown', key, true);
  ov.addEventListener('pointerdown', e => { e.preventDefault(); on = true; sc = scrollerAt(e.clientX, e.clientY); x0 = cx = e.clientX; cy = e.clientY; y0 = e.clientY - top0(); ov.style.background = 'transparent'; box.style.display = 'block'; draw(); ov.setPointerCapture(e.pointerId); raf = requestAnimationFrame(auto); });
  ov.addEventListener('pointermove', e => { if (!on) return; cx = e.clientX; cy = e.clientY; draw(); });
  ov.addEventListener('pointerup', e => {
    if (!on) return; on = false; cx = e.clientX; cy = e.clientY; const t = top0(), y1 = cy - t, a = Math.min(y0, y1), b = Math.max(y0, y1);
    const r = { x: Math.min(x0, cx), w: Math.abs(cx - x0), dpr: devicePixelRatio };
    document.querySelectorAll('[data-hshot221]').forEach(n => n.removeAttribute('data-hshot221'));
    if (moved || b - a > innerHeight - 10) { if (sc) sc.setAttribute('data-hshot221', '1'); Object.assign(r, { scroll: 1, el: !!sc, y0: Math.max(0, a), h: b - a }); }
    else Object.assign(r, { y: a + t, h: b - a });
    end(); if (r.w < 8 || r.h < 8) { chrome.runtime.sendMessage({ op: 'area-rect', rect: null }).catch(() => {}); return; }
    requestAnimationFrame(() => requestAnimationFrame(() => setTimeout(() => chrome.runtime.sendMessage({ op: 'area-rect', rect: r }).catch(() => {}), 60)));
  });
})();
