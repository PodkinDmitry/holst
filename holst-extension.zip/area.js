/* Холст: a snapshot of an area — draw a rectangle on the page; Esc cancels. */
(() => {
  if (document.getElementById('holst-area')) return;
  const ov = document.createElement('div'); ov.id = 'holst-area';
  ov.style.cssText = 'position:fixed;inset:0;z-index:2147483647;cursor:crosshair;background:rgba(17,17,24,.28)';
  const box = document.createElement('div'); box.style.cssText = 'position:fixed;border:2px solid #7c3aed;background:rgba(124,58,237,.08);box-shadow:0 0 0 9999px rgba(17,17,24,.28);display:none;pointer-events:none';
  const tip = document.createElement('div'); tip.textContent = 'Выделите область для снимка в Холст · Esc — отмена';
  tip.style.cssText = 'position:fixed;left:50%;top:14px;transform:translateX(-50%);padding:7px 14px;border-radius:999px;background:#1c1d21;color:#fff;font:600 13px system-ui,sans-serif;pointer-events:none;z-index:2147483647';
  ov.append(box, tip); document.documentElement.appendChild(ov);
  let x0 = 0, y0 = 0, on = false;
  const end = () => { ov.remove(); removeEventListener('keydown', key, true); };
  const key = e => { if (e.key === 'Escape') { e.preventDefault(); end(); chrome.runtime.sendMessage({ op: 'area-rect', rect: null }).catch(() => {}); } };
  addEventListener('keydown', key, true);
  ov.addEventListener('pointerdown', e => { e.preventDefault(); on = true; x0 = e.clientX; y0 = e.clientY; ov.style.background = 'transparent'; Object.assign(box.style, { display: 'block', left: x0 + 'px', top: y0 + 'px', width: '0px', height: '0px' }); ov.setPointerCapture(e.pointerId); });
  ov.addEventListener('pointermove', e => { if (!on) return; const x = Math.min(x0, e.clientX), y = Math.min(y0, e.clientY); Object.assign(box.style, { left: x + 'px', top: y + 'px', width: Math.abs(e.clientX - x0) + 'px', height: Math.abs(e.clientY - y0) + 'px' }); });
  ov.addEventListener('pointerup', e => {
    if (!on) return; on = false; const r = { x: Math.min(x0, e.clientX), y: Math.min(y0, e.clientY), w: Math.abs(e.clientX - x0), h: Math.abs(e.clientY - y0), dpr: devicePixelRatio };
    end(); if (r.w < 8 || r.h < 8) { chrome.runtime.sendMessage({ op: 'area-rect', rect: null }).catch(() => {}); return; }
    requestAnimationFrame(() => requestAnimationFrame(() => setTimeout(() => chrome.runtime.sendMessage({ op: 'area-rect', rect: r }).catch(() => {}), 60)));
  });
})();
