/* Холст: highlights stay on the page — what you sent to Холст from this page is marked
   when you come back (like Glasp or Readwise). Only for text sent with the right click. */
(() => {
  if (window.top !== window) return;
  const ME = (window.__holstHl = (window.__holstHl || 0) + 1);
  const alive = () => { try { return !!chrome.runtime.id && window.__holstHl === ME; } catch (e) { return false; } };
  const STY = 'background:rgba(255,216,77,.55);border-radius:2px;box-shadow:0 0 0 1px rgba(255,200,0,.25);color:inherit;cursor:help';
  const key = u => { try { const x = new URL(u); x.hash = ''; [...x.searchParams.keys()].filter(k => /^(utm_|fbclid|gclid|yclid)/.test(k)).forEach(k => x.searchParams.delete(k)); return x.href; } catch (e) { return String(u || ''); } };
  const wrapRange = r => { try { const m = document.createElement('mark'); m.className = 'holst-hl'; m.style.cssText = STY; m.title = 'Отправлено в Холст'; m.appendChild(r.extractContents()); r.insertNode(m); return true; } catch (e) { return false; } };
  /* find a text across nodes and mark its first occurrence */
  function markText(t) {
    t = String(t || '').replace(/\s+/g, ' ').trim(); if (t.length < 3) return false;
    const probe = t.slice(0, 160), w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, { acceptNode: n => (n.parentElement && !n.parentElement.closest('script,style,noscript,textarea,input,mark.holst-hl,[contenteditable]') ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT) });
    const nodes = [], starts = []; let all = '';
    for (let n = w.nextNode(); n; n = w.nextNode()) { starts.push(all.length); nodes.push(n); all += n.nodeValue.replace(/\s+/g, ' '); }
    const at = all.indexOf(probe); if (at < 0) return false;
    const endAt = at + Math.min(t.length, probe.length);
    const pos = p => { let i = starts.length - 1; while (i > 0 && starts[i] > p) i--; return [nodes[i], Math.min(nodes[i].nodeValue.length, p - starts[i])]; };
    const [sn, so] = pos(at), [en, eo] = pos(endAt);
    try { const r = document.createRange(); r.setStart(sn, so); r.setEnd(en, eo); return wrapRange(r); } catch (e) { return false; }
  }
  async function restore() {
    if (!alive()) return; const k = 'hl:' + key(location.href), st = await chrome.storage.local.get(k).catch(() => ({})), L = st[k] || [];
    for (const h of L) if (![...document.querySelectorAll('mark.holst-hl')].some(m => m.textContent.replace(/\s+/g, ' ').trim().startsWith(String(h.t).replace(/\s+/g, ' ').trim().slice(0, 40)))) markText(h.t);
  }
  chrome.runtime.onMessage.addListener(m => {
    if (!alive() || !m || m.op !== 'hl-mark') return;
    const s = getSelection(); if (s && s.rangeCount && String(s).trim()) { const r = s.getRangeAt(0); if (wrapRange(r)) { s.removeAllRanges(); return; } }
    markText(m.text);
  });
  if (document.readyState === 'complete') setTimeout(restore, 600); else addEventListener('load', () => setTimeout(restore, 600));
  let href = location.href; const t = setInterval(() => { if (!alive()) { clearInterval(t); return; } if (location.href !== href) { href = location.href; setTimeout(restore, 1200); } }, 1000);
})();
