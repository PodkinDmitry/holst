/* Холст — the clipper, v2.21.
   · Only what the destination needs: importance, due date, tags, the status of a video — with the task manager;
     tagging, forming, ranking, tasks from the page need the task manager (a press turns it on); marking, checking
     with sources and fact-checking — the board.
   · Presets: named sets of the buttons.
   · «Отмена» next to «Сохранить»; the cross is gone.
   · Claude: the chat by iterations, the last iteration, an open artifact as HTML.
   · The whole page: the block that scrolls inside the page is seen too. */
const NEED221 = { tag: 'lo', form: 'lo', rank: 'lo', tasks: 'lo' };
{ const f = document.querySelector('footer'), c = document.createElement('button'); c.id = 'cancel221'; c.className = 'btn ghost221'; c.textContent = 'Отмена'; c.title = 'Закрыть, ничего не сохраняя'; c.addEventListener('click', () => closeUI()); const row = document.createElement('div'); row.className = 'go221'; f.insertBefore(row, f.firstChild); row.append(c, $('#go')); }
{ const o = drawWhere; drawWhere = () => { o(); const lo = ST.where.has('lo'); $('#propsBlk').hidden = !lo; if (!lo) $('#ytBlk').hidden = true; }; }
{ const o = drawYt; drawYt = () => { o(); if (!ST.where.has('lo')) $('#ytBlk').hidden = true; }; }
{ const o = drawAi; drawAi = () => { o(); for (const b of document.querySelectorAll('#aiOpts .chip')) { const need = NEED221[b.dataset.k], off = !!need && !ST.where.has(need); b.classList.toggle('need221', off); if (off && !/^Для задачника/.test(b.title)) b.title = 'Для задачника — нажмите, и задачник включится. ' + (b.title || ''); } }; }
document.addEventListener('click', e => { const b = e.target.closest && e.target.closest('#aiOpts .chip'); if (!b) return; const need = NEED221[b.dataset.k]; if (need && !ST.where.has(need)) { ST.where.add(need); drawWhere(); drawEk(); } }, true);
{ const o = payload; payload = () => {
  const d = o();
  if (!ST.where.has('lo')) { d.imp = ''; d.tags = []; d.due = ''; d.st216 = ''; d.act216 = ''; d.ai.tag = d.ai.form = d.ai.rank = d.ai.tasks = 0; }
  if (!ST.where.has('board')) { d.ai.ann = d.ai.src = d.ai.fact = 0; }
  const C = ST.P && ST.P.claude; if (C && (ST.take.has('cchat') || ST.take.has('clast'))) { const turns = ST.take.has('cchat') ? C.turns : C.turns.slice(-1); d.claude221 = Object.assign({}, C, { turns: turns.map(t => Object.assign({}, t, { arts: (t.arts || []).map(a => ST.take.has('carts') ? a : Object.assign({}, a, { html: undefined })) })) }); if (!d.where.board && !d.where.lo) d.where.board = 1; }
  return d;
}; }
/* the whole page: the background glues the page or the block that scrolls */
fullShot = async () => { const r = await bg('shot221', { tabId: tab.id, windowId: tab.windowId }); if (r && r.ok) return r.data; throw new Error((r && r.data) || 'снимок не получился'); };
/* Claude */
{ const o = drawCard; drawCard = () => { o(); if (/(^|\.)claude\.ai$/.test(host) && ST.P && !ST.P.claudeAsked) { ST.P.claudeAsked = 1; bg('claude221', { tabId: tab.id }).then(r => { if (!(r && r.ok && r.data && r.data.n)) return; ST.P.claude = r.data; ST.take.add('cchat'); ST.take.delete('page'); if (!ST.where.has('board')) ST.where.add('board'); $('#title').value = r.data.title || $('#title').value; drawTake(); drawWhere(); drawAi(); }).catch(() => {}); } }; }
{ const o = drawTake; drawTake = () => { o(); const C = ST.P && ST.P.claude; if (!C) return; $('#siteBlk').hidden = false; $('#siteH').innerHTML = hi('bubble') + '<span>Для Claude</span>';
  const arts = C.turns.reduce((s, t) => s + (t.arts || []).length, 0), html = C.turns.some(t => (t.arts || []).some(a => a.html));
  const L = [['cchat', `Чат по итерациям · ${C.n}`, 'list', 'Каждая итерация — строкой: запрос, ответ (размышления свёрнуты сверху), файлы и артефакты'], ['clast', 'Последняя итерация', 'bubble', 'Только последний запрос и ответ']].concat(html ? [['carts', 'Открытый артефакт — живым HTML', 'frame', 'Артефакт на доске будет работать, даже личный']] : []);
  $('#takeSite').innerHTML = L.map(([k, l, ic, t]) => chip(k, l, ic, t, ST.take.has(k))).join('') + (arts ? `<p class="hint">Артефактов в чате: ${arts}. В задачник — сущностями: чат, итерации, артефакты.</p>` : ''); }; }
/* presets */
const PRES221 = { list: [], on: '' };
const presCur221 = () => ({ take: [...ST.take], shot: ST.shot, where: [...ST.where], ek: ST.ek, view: ST.view, place: ST.place, ai: [...ST.ai], kbm: ST.kbm, form: ST.form, fact: ST.fact, imp: ST.imp, tags: $('#tags').value, aiPick: $('#aiPick').value });
function presApply221(p) {
  ST.take = new Set(p.take || ['url']); if (ST.P && ST.P.claude && (p.take || []).some(k => /^c/.test(k)) === false) { /* a preset made elsewhere */ }
  ST.shot = p.shot || 'vis'; ST.where = new Set(p.where && p.where.length ? p.where : ['lo']); ST.ek = p.ek || 'task'; ST.view = p.view || 'card'; ST.place = p.place || 'free'; ST.ai = new Set(p.ai || []); ST.kbm = p.kbm || 'truth'; ST.form = p.form || 'tldr'; ST.fact = p.fact || 'sci'; ST.imp = p.imp || '';
  $('#tags').value = p.tags || ''; if (p.aiPick != null && [...$('#aiPick').options].some(o => o.value === p.aiPick)) $('#aiPick').value = p.aiPick;
  drawTake(); drawWhere(); drawEk(); drawImp(); drawAi(); drawYt(); propsSum(); goLabel(); PRES221.on = p.n; presDraw221();
}
function presDraw221() {
  let box = $('#pres221'); if (!box) { box = document.createElement('section'); box.id = 'pres221'; box.className = 'blk pres221'; $('#mainView').insertBefore(box, $('#mainView').firstChild); }
  box.innerHTML = `<div class="chips">${PRES221.list.map((p, i) => `<button class="chip${PRES221.on === p.n ? ' on' : ''}" data-pres221="${i}" title="Применить набор «${esc(p.n)}» · правый щелчок — удалить">${hi('list')}<span>${esc(p.n)}</span></button>`).join('')}<button class="chip add221" data-pres221="+" title="Запомнить, что сейчас нажато, под своим названием">${hi('plus')}<span>${PRES221.list.length ? 'Набор' : 'Сохранить набор кнопок'}</span></button></div>`;
}
document.addEventListener('click', e => { const b = e.target.closest && e.target.closest('[data-pres221]'); if (!b) return; e.stopPropagation(); const k = b.dataset.pres221;
  if (k === '+') { const n = (prompt('Название набора', ['Задачник', 'Доска', 'Источники'].filter(x => ST.where.has({ 'Задачник': 'lo', 'Доска': 'board', 'Источники': 'kb' }[x])).join(' + ') || 'Мой набор') || '').trim().slice(0, 40); if (!n) return; PRES221.list = PRES221.list.filter(p => p.n !== n).concat([Object.assign({ n }, presCur221())]); chrome.storage.local.set({ pres221: PRES221.list }); PRES221.on = n; presDraw221(); return; }
  presApply221(PRES221.list[+k]); }, true);
document.addEventListener('contextmenu', e => { const b = e.target.closest && e.target.closest('[data-pres221]'); if (!b || b.dataset.pres221 === '+') return; e.preventDefault(); const p = PRES221.list[+b.dataset.pres221]; if (p && confirm('Удалить набор «' + p.n + '»?')) { PRES221.list.splice(+b.dataset.pres221, 1); chrome.storage.local.set({ pres221: PRES221.list }); presDraw221(); } });
chrome.storage.local.get('pres221').then(r => { PRES221.list = r.pres221 || []; presDraw221(); });
