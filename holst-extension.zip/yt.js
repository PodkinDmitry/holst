/* Холст on YouTube (v2.26: one panel per place — the feed button only on feed pages and only feed settings, one panel of a video from the player, the right click and ⋮, the channel panel on its page; «просмотрено» by hand; «в моих плейлистах»; shelves of YouTube as entities; blocks sideways or in a grid with rows; properties of every source merged into yours; the feed fills up without jumps; one switch for all feed settings; Dark Reader. v2.25: tabs YouTube / Холст and by entity; properties with levels and rules for groups; importance and status without Холст; views, speed, subscribers, YouTube progress; a quick strip on pages; global presets and the front layer; AI categorisation with approval and tasks in words; the feed tops itself up. v2.24: system properties from the data of YouTube — type, length, recency, subscription, hashtags, badges, sections, keywords; recency filters and newest per channel; blocks in frames, editable, any conditions, no duplicates; all panels from the main one; panels twice wider with one standard of colours; player buttons that react; the PocketTube file kept for Холст. v2.23: the folders of PocketTube from its export file become options of the property «Папки» in your categories; ytmain.js in the main world tells which channel id stands behind which @handle, so folders follow channels known only by id. v2.22: your own categories of channels, videos and playlists — in ⋮, on the channel, playlist and video pages — that the feed filters, sorts and groups by; nothing floats at the bottom left any more. v2.21: one living copy after updates, ads and the previous video never get into the watched zones, sessions and rewatches, the settings of the feed in the masthead right of the voice search — shorts, videos in a row, watched hidden or dimmed, words, durations, sorting by the weight of Холст, blocks of content by filters, hidden channels for a time, presets; zones on every cover. v2.20: watched zones and moments on the timeline, a moment panel (note, task, question, the network about the moment, a frame to the object on a board, a loop), the feed sorted by the properties of Холст, marks on covers, «+» on a cover, a channel or a playlist into sources, properties by the network for a page. v2.18: the player button, «В Холст» in ⋮ and the list button open the one clipper panel. v2.17: a board card with cover, channel avatar, duration and chapters; the network list with status):
   · a quiet white button in the player bar — the video into sources (with a weight), into the
     task manager (status, action, why it caught you), to the network for a breakdown, with
     suggested properties to approve in Холст;
   · «просмотрено» by itself when a video known to Холст is watched to the end;
   · playlists, channels and feeds: a button to take all or selected videos at once;
   · ⋮ under any video in the feed: «В Холст» — without opening the video;
   · subscriptions: weights of channels as sources. */
(() => {
  if (window.top !== window || window.__holstYt) return; window.__holstYt = 1;
  /* v2.21: one living copy — after an update the old copy of this script stops and no longer draws an empty line */
  const GEN = String(Math.random()); document.documentElement.dataset.holstYt = GEN;
  const alive = () => { try { return document.documentElement.dataset.holstYt === GEN && !!(chrome.runtime && chrome.runtime.id); } catch (e) { return false; } };
  document.querySelectorAll('.holst-tl, #holst-yt-sort, #holst-yt-mast, #holst-feed, #holst-blocks, #holst-yt-list, #holst-yt-src').forEach(n => n.remove());
  { const st = document.createElement('style'); st.id = 'holst-yt-old'; st.textContent = '#holst-yt-sort,#holst-yt-list,#holst-yt-src{display:none!important}'; (document.head || document.documentElement).appendChild(st); }
  const bg = (op, data) => chrome.runtime.sendMessage({ to: 'bg', op, data }).catch(e => ({ ok: false, data: String(e && e.message || e) }));
  const esc = s => String(s || '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const vid = u => { const m = String(u || '').match(/(?:[?&]v=|youtu\.be\/|\/shorts\/)([\w-]{11})/); return m ? m[1] : ''; };
  const XSVG = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>';
  const ICON = '<svg viewBox="0 0 36 36" width="100%" height="100%"><path d="M11.5 10.5h13a2 2 0 0 1 2 2v8.5l-5.5 5.5h-9.5a2 2 0 0 1-2-2v-12a2 2 0 0 1 2-2z" fill="none" stroke="#fff" stroke-width="1.9" stroke-linejoin="round"/><path d="M26.5 21h-3.5a2 2 0 0 0-2 2v3.5" fill="none" stroke="#fff" stroke-width="1.9" stroke-linejoin="round"/><path d="M14 15h8M14 18.5h5" stroke="#fff" stroke-width="1.9" stroke-linecap="round"/></svg>';
  const STD224 = `.p{width:min(760px,calc(100vw - 24px))!important;left:auto!important;right:12px!important}
    select,option{color:#0f0f0f;background:#fff}button{color:#0f0f0f}.seg button{color:#0f0f0f;background:#fff}.seg button.on{background:#ffd84d;color:#3d2f00}
    .go{background:#0f0f0f;color:#fff}.ghost,.go.ghost{background:#fff;color:#0f0f0f;border:1px solid #c9c9c9}
    .sec{border:1px solid #e3e3e3!important;border-radius:12px;padding:10px 12px!important;background:#fafafa}.sec .row+.row{border-top:1px dashed #e6e6e6;padding-top:6px}
    .blk224{border:1px solid #e3e3e3;border-radius:10px;padding:8px;background:#fff;display:flex;flex-direction:column;gap:6px}.chip224{display:inline-flex;align-items:center;gap:4px;border:1px solid #d0d0d0;border-radius:999px;padding:1px 8px;font-size:11.5px;background:#fff;color:#0f0f0f;cursor:pointer}
    .panels224{display:flex;flex-wrap:wrap;gap:6px;padding:8px;border:1px solid #e3e3e3;border-radius:12px;background:#f6f6f6}
    .tabs225{border-bottom:1px solid #e3e3e3;margin:0 0 4px}.tabs225>.seg:first-child{display:none}.tabs225 .seg{gap:0!important;margin:0!important}.tabs225 .seg button{border:0!important;border-bottom:2px solid transparent!important;border-radius:0!important;background:none!important;padding:7px 12px!important;color:#606060!important;font-weight:500}.tabs225 .seg button.on{border-bottom-color:#065fd4!important;color:#065fd4!important;font-weight:700}
    .sec h5{font-size:12.5px!important;color:#0f0f0f!important;text-transform:none!important;letter-spacing:0!important;font-weight:700}.row>span{font-weight:500}.disc226{font-weight:600!important}
    .pw226{height:28px;border-radius:14px;border:1px solid #c9c9c9;background:#fff;color:#606060;padding:0 12px;cursor:pointer;font:600 12px Roboto,Arial}.pw226.on{background:#2fa36b;border-color:#2fa36b;color:#fff}
    :host([data-dark]) .p{background:#181a1b!important;color:#e8e6e3!important}:host([data-dark]) .sec,:host([data-dark]) .blk224,:host([data-dark]) .panels224{background:#1e2022!important;border-color:#3a3e41!important}:host([data-dark]) select,:host([data-dark]) option,:host([data-dark]) input{background:#1e2022!important;color:#e8e6e3!important;border-color:#3a3e41!important}:host([data-dark]) button,:host([data-dark]) .seg button,:host([data-dark]) .ghost,:host([data-dark]) .chip224{background:#232627!important;color:#e8e6e3!important;border-color:#3a3e41!important}:host([data-dark]) .seg button.on{background:#4a3c0f!important;border-color:#d8a90e!important;color:#fff3c4!important}:host([data-dark]) .go:not(.ghost){background:#e8e6e3!important;color:#181a1b!important}:host([data-dark]) .hint,:host([data-dark]) small,:host([data-dark]) .row>span{color:#a8a095!important}:host([data-dark]) .sec h5{color:#e8e6e3!important}:host([data-dark]) .tabs225{border-color:#3a3e41}:host([data-dark]) .tabs225 .seg button{background:none!important;color:#a8a095!important}:host([data-dark]) .tabs225 .seg button.on{color:#8ab4f8!important;border-bottom-color:#8ab4f8!important}:host([data-dark]) .pw226.on{background:#2fa36b!important;color:#fff!important}:host([data-dark]) .more{color:#8ab4f8!important}
    @media (prefers-color-scheme:dark){select,option{color:#f1f1f1;background:#212121}button{color:#f1f1f1}.seg button{color:#f1f1f1;background:#2a2a2a}.seg button.on{background:#ffd84d;color:#3d2f00}.go{background:#f1f1f1;color:#0f0f0f}.ghost,.go.ghost{background:#2a2a2a;color:#f1f1f1;border-color:#3f3f3f}.sec{border-color:#3a3a3a!important;background:#262626}.blk224,.panels224{background:#1f1f1f;border-color:#3a3a3a}.chip224{background:#2a2a2a;color:#f1f1f1;border-color:#444}}`;
  const STY = `:host{all:initial}*{box-sizing:border-box}.p{position:fixed;z-index:2147483646;width:360px;max-height:min(640px,calc(100vh - 80px));overflow:auto;background:#fff;color:#0f0f0f;border-radius:14px;box-shadow:0 18px 50px -12px rgba(0,0,0,.5);font:13px/1.4 Roboto,Arial,sans-serif;padding:12px 14px;display:flex;flex-direction:column;gap:8px}
    .h{display:flex;align-items:center;gap:8px}.h b{font-size:14.5px;flex:1}.x{border:0;background:none;cursor:pointer;color:inherit;line-height:0;padding:4px;border-radius:6px;display:inline-flex}.x:hover{background:#0000000f}
    .st{font-size:12px;color:#606060}.t{font-weight:600;font-size:13px}
    label{display:flex;flex-direction:column;gap:3px;font-size:12px;color:#606060}textarea,select,input[type=number]{border:1px solid #d9d9d9;border-radius:8px;padding:6px 8px;font:inherit;color:inherit;background:transparent}textarea{resize:vertical;min-height:52px}
    .ck{flex-direction:row;align-items:center;gap:7px;color:inherit;font-size:13px}
    .seg{display:flex;flex-wrap:wrap;gap:4px}.seg button{border:1px solid #d9d9d9;background:transparent;color:inherit;border-radius:999px;padding:3px 10px;font:500 12px Roboto,Arial,sans-serif;cursor:pointer}.seg button.on{background:#0f0f0f;color:#fff;border-color:#0f0f0f}
    .row{display:flex;align-items:center;gap:8px}.row>span{width:70px;color:#606060;font-size:12px;flex:none}input[type=range]{flex:1}
    .go{height:36px;border:0;border-radius:18px;background:#0f0f0f;color:#fff;font:600 13px Roboto,Arial,sans-serif;cursor:pointer}.go:disabled{opacity:.5}
    .l{display:flex;flex-direction:column;gap:2px;max-height:240px;overflow:auto;border:1px solid #e5e5e5;border-radius:10px;padding:4px}.l label{flex-direction:row;align-items:center;gap:8px;color:inherit;font-size:12.5px;padding:3px 4px}.l label span{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.l input[type=number]{width:62px;padding:3px 6px}
    .ok{color:#1a7f37;font-size:12px}.err{color:#c00;font-size:12px}
    @media (prefers-color-scheme:dark){.p{background:#212121;color:#f1f1f1}.st,label,.row>span{color:#aaa}textarea,select,input[type=number],.seg button,.l{border-color:#3f3f3f}.seg button.on,.go{background:#f1f1f1;color:#0f0f0f;border-color:#f1f1f1}.x:hover{background:#ffffff14}}${STD224}`;
  let host = null, root = null, INFO = null, AIS = [];
  function panel(html, at) {
    if (!host || !host.isConnected) { host = document.createElement('div'); host.id = 'holst-yt'; document.documentElement.appendChild(host); root = host.attachShadow({ mode: 'open' }); }
    root.innerHTML = `<style>${STY}</style><div class="p">${html}</div>`;
    const p = root.querySelector('.p'); const r = at || { right: 24, bottom: 90 };
    Object.assign(p.style, r.left != null ? { left: r.left + 'px' } : { right: r.right + 'px' }, r.top != null ? { top: r.top + 'px' } : { bottom: r.bottom + 'px' });
    if (r.bottom != null) p.style.maxHeight = Math.max(220, innerHeight - r.bottom - 12) + 'px';
    root.querySelector('.x').addEventListener('click', close);
    root.querySelectorAll('.seg').forEach(s => s.addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; const on = b.classList.contains('on'); s.querySelectorAll('button').forEach(x => x.classList.remove('on')); if (!on) b.classList.add('on'); }));
    return p;
  }
  const close = () => { if (host) { host.remove(); host = null; root = null; } };
  const segVal = sel => { const b = root.querySelector(sel + ' button.on'); return b ? b.dataset.v : ''; };
  let MAIN = '';
  async function aiList() { if (AIS.length) return AIS; const r = await bg('ping'); const A = r && r.ok && r.data && r.data.ai217; MAIN = A && A.main ? A.mainName : ''; AIS = A ? A.list : (r && r.ok && r.data && r.data.ais) || []; return AIS; }
  const OPTS = (I, many) => `
    <label>Зачем это мне<textarea data-f="intent" placeholder="Чем зацепило, что хочу из этого взять — нейросеть учтёт">${esc(I && I.intent)}</textarea></label>
    <div class="row"><span>Статус</span><div class="seg" data-s="st">${((I && I.sts) || ['новое', 'просмотрено', 'в работе', 'разобрано', 'архив']).map(v => `<button data-v="${esc(v)}" class="${I && I.st216 === v ? 'on' : ''}">${esc(v)}</button>`).join('')}</div></div>
    <div class="row"><span>Действие</span><div class="seg" data-s="act">${((I && I.acts) || ['посмотреть', 'законспектировать', 'применить', 'обсудить', 'отложить', 'удалить']).map(v => `<button data-v="${esc(v)}" class="${I && I.act216 === v ? 'on' : ''}">${esc(v)}</button>`).join('')}</div></div>
    <div class="row"><span>Вес</span><input type="range" min="0" max="100" step="5" value="${I && I.w216 !== '' && I.w216 != null ? I.w216 : 60}" data-f="w"><b data-f="wv">${I && I.w216 !== '' && I.w216 != null ? I.w216 : 60}</b></div>
    <label class="ck"><input type="checkbox" data-f="kb" ${I && I.kb ? 'checked' : 'checked'}> В источники — расшифровка в базу знаний с этим весом</label>
    <label class="ck"><input type="checkbox" data-f="task" ${I && I.task ? 'checked' : many ? '' : 'checked'}> В задачник — со статусом и действием</label>
    <label class="ck"><input type="checkbox" data-f="cap"> Нейросеть: разобрать, как быстрый ввод, — на согласование</label>
    <label class="ck"><input type="checkbox" data-f="board"> На доску — красивой карточкой: обложка, канал, длительность, главы</label>
    <label class="ck"><input type="checkbox" data-f="tag" checked> Нейросеть: предложить ярлыки и свойства — утвердите в задачнике</label>
    <details data-f="pp"><summary class="st">Какие свойства и как</summary><div class="l" style="max-height:none">${[['w216', 'Вес'], ['st216', 'Статус'], ['act216', 'Действие'], ['tags', 'Ярлыки'], ['rel', 'Связи'], ['form216', 'Форма'], ['trust216', 'Доверие']].map(([k, l]) => `<label><input type="checkbox" data-pp="${k}" checked><span>${l}</span></label>`).join('')}<label><input type="checkbox" data-f="acc"><span>Принять сразу, без согласования</span></label></div></details>
    <select data-f="pick"><option value="">Нейросеть: сначала бесплатные</option></select>`;
  function wireOpts(p) {
    const w = p.querySelector('[data-f="w"]'), wv = p.querySelector('[data-f="wv"]'); if (w) w.addEventListener('input', () => { wv.textContent = w.value; });
    aiList().then(L => { const s = p.querySelector('[data-f="pick"]'), add = (v, l, off) => { const o = document.createElement('option'); o.value = v; o.textContent = l; if (off) o.disabled = true; s.appendChild(o); return o; };
      add('__main', 'Личная платная основная' + (MAIN ? ' — ' + MAIN : ' — не подключена'), !MAIN); for (const a of L.filter(a => !a.st || a.st === 'ok')) add(a.p, a.l); for (const a of L.filter(a => a.st && a.st !== 'ok')) add(a.p, a.l, 1); add('__set', 'Подключить ещё нейросети…');
      s.addEventListener('change', () => { if (s.value === '__set') { s.value = ''; bg('open', { ai: 1 }); } });
      chrome.storage.local.get('ytPick').then(r => { if (r.ytPick && [...s.options].some(o => o.value === r.ytPick && !o.disabled)) s.value = r.ytPick; }); });
  }
  const optsOf = p => { const f = k => p.querySelector(`[data-f="${k}"]`); chrome.storage.local.set({ ytPick: f('pick').value }); const pp = [...p.querySelectorAll('[data-pp]:checked')].map(c => c.dataset.pp), tg = f('tag') && f('tag').checked; return { props220: tg ? pp : undefined, accept220: tg && f('acc') && f('acc').checked ? 1 : 0, tag220: tg, intent: f('intent').value.trim(), st: segVal('[data-s="st"]'), act: segVal('[data-s="act"]'), w: +f('w').value, kb: f('kb').checked, task: f('task').checked, cap: f('cap').checked, tag: false, board: f('board') ? f('board').checked : false, pick: f('pick').value === '__set' ? '' : f('pick').value }; };
  /* ---------- one video: the player button ---------- */
  /* v2.17: everything a beautiful card needs — cover, channel avatar, duration, views, date, chapters */
  const secOf = t => { const p = String(t || '').trim().split(':').map(Number); return p.some(isNaN) ? 0 : p.reduce((a, b) => a * 60 + b, 0); };
  const chaptersOf = text => { const ch = []; for (const line of String(text || '').split('\n')) { const m = line.match(/^\s*((?:\d{1,2}:)?\d{1,2}:\d{2})\s*[-–—:|]?\s*(.{2,90})$/); if (m) ch.push({ s: secOf(m[1]), t: m[2].trim() }); } return ch.length >= 2 && ch[0].s === 0 ? ch.slice(0, 60) : []; };
  const ldVideo = () => { for (const sc of document.querySelectorAll('script[type="application/ld+json"]')) { try { const j = JSON.parse(sc.textContent); for (const x of [].concat(j)) if ([].concat(x['@type'] || []).includes('VideoObject')) return x; } catch (e) { /* broken */ } } return {}; };
  const curVideo = () => {
    const id = vid(location.href); if (!id) return null;
    const t = document.querySelector('h1.ytd-watch-metadata yt-formatted-string, h1.ytd-watch-metadata, #title h1'), ch = document.querySelector('#owner #channel-name a, ytd-video-owner-renderer #channel-name a, ytd-channel-name a'), ds = document.querySelector('#description-inline-expander, ytd-text-inline-expander, #description');
    const av = document.querySelector('#owner #avatar img, ytd-video-owner-renderer #avatar img, ytd-video-owner-renderer img'), V = ldVideo(), v = document.querySelector('video.html5-main-video, video');
    const iso = String(V.duration || '').match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/), ist = [].concat(V.interactionStatistic || [])[0], desc = ds ? ds.innerText.trim().slice(0, 3000) : String(V.description || '');
    const dur = iso && (iso[1] || iso[2] || iso[3]) ? (+iso[1] || 0) * 3600 + (+iso[2] || 0) * 60 + (+iso[3] || 0) : v && isFinite(v.duration) ? Math.round(v.duration) : 0;
    return { id, title: (t && t.textContent.trim()) || document.title.replace(/ - YouTube$/, ''), channel: ch ? ch.textContent.trim() : '', desc, meta: { yt: 1, id, thumb: 'https://i.ytimg.com/vi/' + id + '/hqdefault.jpg', ch: ch ? ch.textContent.trim() : '', chUrl: ch ? ch.href : '', chAv: av ? av.currentSrc || av.src || '' : '', dur, views: +(V.interactionCount || (ist && ist.userInteractionCount) || 0), date: V.uploadDate || V.datePublished || '', chapters: chaptersOf(desc), desc: desc.slice(0, 600) } };
  };
  async function openOne(v, at) {
    if (!v) return; const p = panel(`<div class="h"><b>В Холст</b><button class="x" title="Закрыть" aria-label="Закрыть">${XSVG}</button></div><div class="t">${esc(v.title)}</div><div class="st" data-f="info">Спрашиваю Холст…</div>${OPTS(null, false)}<button class="go">Сохранить в Холст</button><div data-f="res"></div>`, at);
    wireOpts(p);
    const r = await bg('yt-info', { id: v.id }); INFO = r && r.ok ? r.data : null;
    const inf = p.querySelector('[data-f="info"]');
    if (!INFO) inf.innerHTML = '<span class="err">Холст не ответил — откройте Холст во вкладке</span>';
    else { inf.textContent = [INFO.task ? 'в задачнике' : '', INFO.kb ? 'в источниках, вес ' + INFO.kb.w : ''].filter(Boolean).join(' · ') || 'Ещё нет в Холсте';
      const set = (k, v2) => { const b = p.querySelector(`[data-s="${k}"] button[data-v="${CSS.escape(v2)}"]`); if (b) b.classList.add('on'); };
      if (INFO.st216) set('st', INFO.st216); if (INFO.act216) set('act', INFO.act216); if (INFO.intent) p.querySelector('[data-f="intent"]').value = INFO.intent;
      if (INFO.w216 !== '' && INFO.w216 != null) { p.querySelector('[data-f="w"]').value = INFO.w216; p.querySelector('[data-f="wv"]').textContent = INFO.w216; } }
    p.querySelector('.go').addEventListener('click', async () => {
      const b = p.querySelector('.go'), o = optsOf(p); b.disabled = true; b.textContent = 'Сохраняю…';
      const res = await bg('yt-add', Object.assign({ videos: [v] }, o));
      p.querySelector('[data-f="res"]').innerHTML = res && res.ok ? '<div class="ok">Готово. Свойства от нейросети — на согласование в задачнике.</div>' : `<div class="err">${esc((res && res.data) || 'Холст не ответил')}</div>`;
      b.disabled = false; b.textContent = 'Сохранить в Холст'; if (res && res.ok) setTimeout(close, 1400);
    });
  }
  /* v2.18: one panel for every way in — the same clipper as the button of the browser, in a frame on the page */
  let frameHost = null;
  async function openPanel(q) {
    closePanel(); close();
    const r = await bg('my-tab'); const id = r && r.ok && r.id; if (!id) { alert('Холст: расширение не ответило. Перезапустите его: chrome://extensions → «Холст» → ⟳'); return; }
    frameHost = document.createElement('div'); frameHost.id = 'holst-panel';
    frameHost.style.cssText = 'all:initial;position:fixed;z-index:2147483646;right:16px;top:72px;width:400px;height:min(600px,calc(100vh - 88px));border-radius:16px;overflow:hidden;box-shadow:0 24px 70px -18px rgba(0,0,0,.55);background:#fff;transition:opacity .12s';
    const f = document.createElement('iframe'); f.src = chrome.runtime.getURL('popup.html') + '?' + new URLSearchParams(Object.assign({ tab: id, embed: 1 }, q || {})).toString();
    f.style.cssText = 'border:0;width:100%;height:100%;display:block;color-scheme:normal'; f.allow = 'clipboard-write';
    frameHost.appendChild(f); document.documentElement.appendChild(frameHost);
  }
  function closePanel() { if (frameHost) { frameHost.remove(); frameHost = null; } }
  addEventListener('message', e => { if (!frameHost || !e.data || !e.data.holst218) return; const f = frameHost.querySelector('iframe'); if (e.source !== (f && f.contentWindow)) return; const a = e.data.holst218; if (a === 'close') closePanel(); else if (a === 'hide') frameHost.style.opacity = '0'; else if (a === 'show') frameHost.style.opacity = '1'; });
  function playerButton() {
    const bar = document.querySelector('.ytp-right-controls'); if (!bar || bar.querySelector('.holst-ytp')) return;
    const b = document.createElement('button'); b.className = 'ytp-button holst-ytp'; b.title = 'В Холст'; b.setAttribute('aria-label', 'В Холст'); b.innerHTML = ICON; b.style.opacity = '.85';
    tap224(b, () => { frameHost ? closePanel() : openPanel({}); });
    bar.insertBefore(b, bar.firstChild);
  }
  /* watched to the end: «просмотрено» for videos Холст knows */
  const WATCHED = new Set();
  document.addEventListener('timeupdate', async e => {
    const v = e.target; if (!(v instanceof HTMLVideoElement) || !v.duration || v.currentTime / v.duration < 0.9) return; const id = vid(location.href); if (!id || WATCHED.has(id)) return; WATCHED.add(id);
    const r = await bg('yt-info', { id }); if (r && r.ok && r.data && (r.data.task || r.data.kb) && r.data.st216 !== 'просмотрено') bg('yt-status', { id, st: 'просмотрено' });
  }, true);
  /* ---------- many videos: playlists, channels, feeds ---------- */
  const CARDS = 'ytd-playlist-video-renderer, ytd-rich-item-renderer, ytd-grid-video-renderer, ytd-video-renderer, ytd-compact-video-renderer, yt-lockup-view-model';
  const cardVideo = c => {
    const a = c.querySelector('a[href*="/watch?v="], a[href*="/shorts/"]'); const id = a && vid(a.href); if (!id) return null;
    const t = c.querySelector('#video-title, h3 a, h3, [id="video-title-link"]'), ch = c.querySelector('ytd-channel-name a, #channel-name a, .yt-content-metadata-view-model-wiz__metadata-text, .yt-content-metadata-view-model__metadata-text');
    const av = c.querySelector('#avatar-link img, #avatar img, yt-decorated-avatar-view-model img, .yt-spec-avatar-shape__image'), d = c.querySelector('ytd-thumbnail-overlay-time-status-renderer #text, badge-shape .badge-shape-wiz__text, .yt-badge-shape__text');
    const title = ((t && (t.getAttribute('title') || t.textContent)) || '').trim() || 'Видео ' + id, chn = ch ? ch.textContent.trim() : '';
    return { id, title, channel: chn, meta: { yt: 1, id, thumb: 'https://i.ytimg.com/vi/' + id + '/hqdefault.jpg', ch: chn, chAv: av ? av.currentSrc || av.src || '' : '', dur: d ? secOf(d.textContent) : 0 } };
  };
  const isList = () => /\/playlist\?|\/(@[^/]+|channel\/[^/]+|c\/[^/]+|user\/[^/]+)\/(videos|streams|shorts|featured)?\/?$|\/results\?|^\/$|\/feed\/(subscriptions|history|playlists)/.test(location.pathname + location.search);
  /* v2.22: nothing floats at the bottom left — «видео этой страницы» is in the panel of the masthead */
  async function listAll() { if (frameHost) { closePanel(); return; } const seen = new Set(), L = [...document.querySelectorAll(CARDS)].map(cardVideo).filter(v => v && !seen.has(v.id) && seen.add(v.id)); await chrome.storage.local.set({ many218: { videos: L, at: Date.now() } }); openPanel({ many: 1 }); }
  function listButton() { for (const id of ['holst-yt-list', 'holst-yt-sort', 'holst-yt-src']) { const b = document.getElementById(id); if (b) b.remove(); } }
  function openMany(only) {
    const seen = new Set(), L = (only ? [only] : [...document.querySelectorAll(CARDS)].map(cardVideo)).filter(v => v && !seen.has(v.id) && seen.add(v.id));
    const p = panel(`<div class="h"><b>В Холст: ${L.length} видео</b><button class="x" title="Закрыть" aria-label="Закрыть">${XSVG}</button></div>
      ${only ? '' : `<label class="ck"><input type="checkbox" data-f="all" checked> Все</label>`}
      <div class="l">${L.map((v, i) => `<label><input type="checkbox" data-i="${i}" checked><span title="${esc(v.title)}">${esc(v.title)}</span></label>`).join('') || '<div class="st">Видео на странице не нашлось — прокрутите список, чтобы они загрузились.</div>'}</div>
      ${OPTS(null, true)}<button class="go">Сохранить выбранные</button><div data-f="res"></div>`, { left: 16, bottom: 64 });
    wireOpts(p);
    const all = p.querySelector('[data-f="all"]'); if (all) all.addEventListener('change', () => p.querySelectorAll('[data-i]').forEach(c => { c.checked = all.checked; }));
    p.querySelector('.go').addEventListener('click', async () => {
      const pick = [...p.querySelectorAll('[data-i]:checked')].map(c => L[+c.dataset.i]); if (!pick.length) return;
      const b = p.querySelector('.go'), o = optsOf(p); b.disabled = true; b.textContent = 'Сохраняю ' + pick.length + '…';
      const res = await bg('yt-add', Object.assign({ videos: pick }, o));
      p.querySelector('[data-f="res"]').innerHTML = res && res.ok ? `<div class="ok">Готово: ${res.data.task ? 'задач ' + res.data.task + ' ' : ''}${res.data.kb ? 'в источники ' + res.data.kb + ' ' : ''}${res.data.cap ? 'на разбор ' + res.data.cap : ''}</div>` : `<div class="err">${esc((res && res.data) || 'Холст не ответил')}</div>`;
      b.disabled = false; b.textContent = 'Сохранить выбранные';
    });
  }
  /* ---------- ⋮ under a video: «В Холст» without opening it ---------- */
  let lastCard = null;
  document.addEventListener('click', e => { const t = e.target; if (!t || !t.closest) return; if (t.closest('#holst-yt-mi')) return; const c = t.closest(CARDS); if (c && t.closest('ytd-menu-renderer, button[aria-label], yt-icon-button, .yt-lockup-metadata-view-model-wiz__menu-button, button-view-model')) { lastCard = c; setTimeout(() => tick(), 150); setTimeout(() => tick(), 500); } }, true);
  function menuItem() {
    const dd = [...document.querySelectorAll('tp-yt-iron-dropdown, ytd-popup-container yt-sheet-view-model, yt-contextual-sheet-layout')].find(d => d.getClientRects().length && getComputedStyle(d).display !== 'none' && d.getAttribute('aria-hidden') !== 'true');
    if (!dd || !lastCard) return; const list = dd.querySelector('tp-yt-paper-listbox#items, #items, yt-list-view-model'); if (!list || list.querySelector('#holst-yt-mi')) return;
    const v = cardVideo(lastCard); if (!v) return;
    const it = document.createElement('div'); it.id = 'holst-yt-mi'; it.setAttribute('role', 'menuitem'); it.tabIndex = 0;
    it.style.cssText = 'display:flex;align-items:center;gap:14px;padding:0 16px;height:36px;cursor:pointer;font:400 14px Roboto,Arial,sans-serif;color:var(--yt-spec-text-primary,#0f0f0f)';
    it.innerHTML = `<span style="width:24px;height:24px;display:inline-block;filter:var(--holst-ico,invert(1))">${ICON}</span><span>В Холст</span>`;
    if (document.documentElement.hasAttribute('dark')) it.querySelector('span').style.filter = 'none';
    it.addEventListener('mouseenter', () => { it.style.background = 'var(--yt-spec-10-percent-layer,#0000000d)'; }); it.addEventListener('mouseleave', () => { it.style.background = ''; });
    it.addEventListener('click', e => { e.stopPropagation(); document.body.click(); setTimeout(() => openPanel({ vid: v.id, vt: v.title, vch: v.channel || '' }), 60); });
    list.insertBefore(it, list.firstChild);
  }
  /* ---------- subscriptions: weights of channels ---------- */
  function subsButton() {
    let b = document.getElementById('holst-yt-subs'); const show = /\/feed\/channels/.test(location.pathname);
    if (!show) { if (b) b.remove(); return; } if (b) return;
    b = document.createElement('button'); b.id = 'holst-yt-subs'; b.textContent = 'В Холст: веса каналов';
    b.style.cssText = 'position:fixed;left:16px;bottom:16px;z-index:2147483645;border:0;border-radius:18px;padding:9px 14px;background:#0f0f0f;color:#fff;font:600 13px Roboto,Arial,sans-serif;box-shadow:0 8px 24px -8px rgba(0,0,0,.5);cursor:pointer;opacity:.9';
    b.addEventListener('click', () => (host ? close() : openSubs())); document.documentElement.appendChild(b);
  }
  async function openSubs() {
    const seen = new Set(), L = [...document.querySelectorAll('ytd-channel-renderer')].map(c => { const a = c.querySelector('a#main-link, a[href^="/@"], a[href*="/channel/"]'), n = c.querySelector('#channel-title, #text'); return a ? { url: new URL(a.getAttribute('href'), location.origin).href.replace(/\/$/, ''), name: (n && n.textContent.trim()) || a.textContent.trim() } : null; }).filter(c => c && !seen.has(c.url) && seen.add(c.url));
    const k = await bg('yt-known'), known = (k && k.ok && k.data.ch) || [], comps = (k && k.ok && k.data.comps) || [], key = u => u.replace(/^https?:\/\/(www\.)?/, '').toLowerCase().replace(/\/$/, '');
    const p = panel(`<div class="h"><b>Каналы как источники: ${L.length}</b><button class="x" title="Закрыть" aria-label="Закрыть">${XSVG}</button></div>
      <div class="st">Вес — насколько доверять каналу в «Источниках» Холста (0–100). Отметьте, какие каналы взять в источники; уже взятые — с весом.</div>
      <div class="l" style="max-height:340px">${L.map((c, i) => { const kn = known.find(x => key(x.url) === key(c.url)); return `<label><input type="checkbox" data-i="${i}"${kn ? ' checked disabled' : ''}><span title="${esc(c.name)}">${esc(c.name)}</span><input type="number" min="0" max="100" step="5" data-w="${i}" value="${kn ? kn.w : 60}"></label>`; }).join('') || '<div class="st">Каналы не нашлись — прокрутите список подписок.</div>'}</div>
      ${comps.length ? `<label>Компетенция для отмеченных<select data-f="comp"><option value="">Определит Холст</option>${comps.map(c => `<option value="${esc(c.k)}">${esc(c.l)}</option>`).join('')}</select></label>` : ''}
      <button class="go">Сохранить веса и источники</button><div data-f="res"></div>`, { left: 16, bottom: 64 });
    p.querySelector('.go').addEventListener('click', async () => {
      const comp = (p.querySelector('[data-f="comp"]') || {}).value || '';
      const list = L.map((c, i) => ({ url: c.url, name: c.name, w: +p.querySelector(`[data-w="${i}"]`).value, kb: p.querySelector(`[data-i="${i}"]`).checked, comp })).filter(c => c.kb || known.some(x => key(x.url) === key(c.url)));
      const res = await bg('yt-channels', { list });
      p.querySelector('[data-f="res"]').innerHTML = res && res.ok ? `<div class="ok">Обновлено весов: ${res.data.n}, новых источников: ${res.data.add}</div>` : `<div class="err">${esc((res && res.data) || 'Холст не ответил')}</div>`;
    });
  }

  /* ---------- v2.20: the timeline — watched zones and moments ---------- */
  const fmt = t => { t = Math.max(0, Math.floor(t || 0)); const h = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60), x = t % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0'); };
  const mainVideo = () => document.querySelector('#movie_player video.html5-main-video') || document.querySelector('video.html5-main-video') || document.querySelector('#movie_player video');
  const zMergeL = (a, b) => { const L = (a || []).concat(b || []).map(z => [+z[0], +z[1]]).filter(z => z[1] > z[0]).sort((p, q) => p[0] - q[0]), out = []; for (const z of L) { const l = out[out.length - 1]; if (l && z[0] <= l[1] + 2) l[1] = Math.max(l[1], z[1]); else out.push(z.slice()); } return out; };
  const zLocal = v => { const z = []; try { for (let i = 0; i < v.played.length; i++) z.push([Math.floor(v.played.start(i)), Math.ceil(v.played.end(i))]); } catch (e) { /* no ranges */ } return z; };
  let YW = { id: '', d: 0, z: [], z0: [], mom: [], ab: null, sent: 0, t0: 0, sess: '' };
  const adOn = () => !!document.querySelector('#movie_player.ad-showing, #movie_player.ad-interrupting, .ad-showing');
  const zSum = Z => Z.reduce((s, z) => s + Math.max(0, z[1] - z[0]), 0);
  const zOver = (A, B) => { let s = 0; for (const a of A) for (const b of B) s += Math.max(0, Math.min(a[1], b[1]) - Math.max(a[0], b[0])); return s; };
  function hToast(t) { let d = document.getElementById('holst-toast'); if (!d) { d = document.createElement('div'); d.id = 'holst-toast'; d.style.cssText = 'position:fixed;left:50%;bottom:90px;transform:translateX(-50%);z-index:2147483646;background:#0f0f0f;color:#fff;padding:8px 14px;border-radius:18px;font:500 13px Roboto,Arial,sans-serif;box-shadow:0 8px 24px -8px rgba(0,0,0,.5);transition:opacity .2s'; document.documentElement.appendChild(d); } d.textContent = t; d.style.opacity = '1'; clearTimeout(d._t); d._t = setTimeout(() => { d.style.opacity = '0'; }, 2600); }
  async function ytLoad(id) {
    YW = { id, d: 0, z: [], z0: [], mom: [], ab: null, sent: 0, t0: Date.now(), sess: id + ':' + Date.now().toString(36) }; const k = 'yw:' + id, st = await chrome.storage.local.get(k).catch(() => ({})), o = st[k]; if (YW.id !== id) return; if (o) { YW.d = o.d || 0; YW.z = o.z || []; YW.z0 = (o.z || []).map(z => z.slice()); }
    const r = await bg('yt-moments', { id }); if (YW.id !== id) return; if (r && r.ok && r.data) { YW.mom = r.data.list || []; if (r.data.w && r.data.w.z) YW.z = zMergeL(YW.z, r.data.w.z); } drawTl();
  }
  function drawTl() {
    const v = mainVideo(), bar = document.querySelector('#movie_player .ytp-progress-bar-container'); if (!v || !bar || !YW.id) return;
    let tl = bar.querySelector('.holst-tl'); if (!tl) { tl = document.createElement('div'); tl.className = 'holst-tl'; tl.style.cssText = 'position:absolute;left:0;right:0;bottom:calc(100% + 2px);height:3px;pointer-events:none;z-index:45';
      tl.addEventListener('click', e => { const b = e.target.closest('[data-hm]'); if (!b) return; e.stopPropagation(); const m = YW.mom[+b.dataset.hm], w = mainVideo(); if (m && w) w.currentTime = m.s; }, true); bar.appendChild(tl); }
    const d = isFinite(v.duration) && v.duration ? v.duration : YW.d; if (!d) return; const Z = zMergeL(YW.z, zLocal(v));
    tl.innerHTML = Z.map(z => `<i style="position:absolute;top:0;height:3px;left:${(z[0] / d * 100).toFixed(3)}%;width:${((z[1] - z[0]) / d * 100).toFixed(3)}%;background:#2fa36b;border-radius:2px"></i>`).join('')
      + (YW.ab && YW.ab.b != null ? `<i style="position:absolute;top:-2px;height:7px;left:${(YW.ab.a / d * 100).toFixed(3)}%;width:${((YW.ab.b - YW.ab.a) / d * 100).toFixed(3)}%;border:1px solid #ffd84d;border-radius:3px"></i>` : '')
      + YW.mom.map((m, i) => `<b data-hm="${i}" title="${esc(fmt(m.s) + ' — ' + m.t)}" style="position:absolute;bottom:5px;left:${Math.min(100, m.s / d * 100).toFixed(3)}%;width:9px;height:9px;margin-left:-4.5px;border-radius:50%;background:${m.ai ? '#a855f7' : '#ffd84d'};border:1px solid rgba(0,0,0,.5);pointer-events:auto;cursor:pointer"></b>`).join('');
  }
  async function sendWatch(force) {
    const v = mainVideo(), id = vid(location.href); if (!alive() || !v || !id || id !== YW.id || !isFinite(v.duration) || !v.duration) return;
    /* not an ad, not the previous video still in the player, not the first seconds after a jump */
    if (adOn() || (YW.srcOld && v.currentSrc === YW.srcOld) || (YW.d && Math.abs(v.duration - YW.d) > 3)) return;
    const zl = zLocal(v), z = zMergeL(YW.z, zl); if (!force && Date.now() - YW.sent < 15000) return; YW.sent = Date.now(); YW.z = z; YW.d = v.duration;
    const r = await bg('yt-watch', { id, d: Math.round(v.duration), z, sess: YW.sess, ws: Math.round(zSum(zl)), rws: Math.round(zOver(zl, YW.z0)) }); if (r && r.ok && r.data && r.data.z) YW.z = zMergeL(YW.z, r.data.z); drawTl();
  }
  const iv221 = setInterval(() => { if (!alive()) { clearInterval(iv221); return; } const id = vid(location.href); if (!id || !/\/watch|\/live\//.test(location.pathname)) return; if (id !== YW.id) { const prev = YW.id, pv = mainVideo(); ytLoad(id); if (prev && pv) YW.srcOld = pv.currentSrc; return; } const v = mainVideo(); if (v && !v.paused) { sendWatch(false); drawTl(); } if (YW.ab && YW.ab.b != null && v && v.currentTime > YW.ab.b) v.currentTime = YW.ab.a; }, 2500);
  document.addEventListener('pause', e => { if (alive() && e.target instanceof HTMLVideoElement) sendWatch(true); }, true);
  document.addEventListener('ended', e => { if (e.target instanceof HTMLVideoElement) sendWatch(true); }, true);
  addEventListener('beforeunload', () => sendWatch(true));
  /* the moment: a button next to the time, Alt+N */
  const MOM = '<svg viewBox="0 0 24 24" width="100%" height="100%" fill="none" stroke="#fff" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M7 4h10a1 1 0 0 1 1 1v15l-6-4-6 4V5a1 1 0 0 1 1-1z"/><path d="M12 8v5M9.5 10.5h5"/></svg>';
  function momentBtn() {
    const bar = document.querySelector('#movie_player .ytp-left-controls'); if (!bar || bar.querySelector('.holst-mom')) return;
    const b = document.createElement('button'); b.className = 'ytp-button holst-mom'; b.title = 'Момент в Холст: заметка, задача, вопрос, кадр (Alt+N)'; b.setAttribute('aria-label', 'Момент в Холст'); b.innerHTML = `<span style="display:inline-block;width:24px;height:24px;margin:12px">${MOM}</span>`; b.style.opacity = '.85';
    b.addEventListener('click', e => { e.stopPropagation(); host ? close() : openMoment(); }); bar.appendChild(b);
  }
  function openMoment() {
    const v = mainVideo(), id = vid(location.href); if (!v || !id) return; const t = Math.floor(v.currentTime), cv = curVideo();
    const p = panel(`<div class="h"><b>Момент ${fmt(t)}</b><button class="x" title="Закрыть" aria-label="Закрыть">${XSVG}</button></div>
      <div class="seg" data-s="k"><button data-v="note" class="on">Заметка</button><button data-v="task">Задача</button><button data-v="q">Вопрос</button></div>
      <textarea data-f="t" placeholder="Что здесь важно — или вопрос нейросети"></textarea>
      <button class="go" data-a="save">Сохранить момент</button>
      <div class="row" style="flex-wrap:wrap"><button class="go" style="background:#7b61ff;flex:1" data-a="ask">Спросить нейросеть</button><button class="go" style="background:#2fa36b;flex:1" data-a="frame">Кадр к объекту</button></div>
      <div class="seg"><button data-a="ab">${YW.ab ? (YW.ab.b == null ? 'Конец повтора здесь' : 'Убрать повтор') : 'Повтор: начало здесь'}</button><button data-a="next">К следующему моменту</button></div>
      <div data-f="res" class="st">Ваши моменты — жёлтые точки на таймлайне, моменты нейросети — фиолетовые.</div>`, { left: 16, bottom: 90 });
    const res = p.querySelector('[data-f="res"]'), txt = () => p.querySelector('[data-f="t"]').value.trim();
    setTimeout(() => p.querySelector('[data-f="t"]').focus(), 30);
    p.querySelector('[data-f="t"]').addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) p.querySelector('[data-a="save"]').click(); });
    p.addEventListener('click', async e => { const b = e.target.closest('[data-a]'); if (!b) return; const a = b.dataset.a;
      if (a === 'save') { const x = txt(); if (!x) { res.textContent = 'Напишите, что здесь важно'; return; } b.disabled = true; const r = await bg('yt-moment', { id, s: t, text: x, kind: segVal('[data-s="k"]') || 'note', title: cv && cv.title }); b.disabled = false; if (r && r.ok) { YW.mom.push({ s: t, t: x, ai: false }); drawTl(); res.innerHTML = '<span class="ok">' + (r.queued ? 'Холст закрыт — момент в очереди' : 'Сохранено в задачник') + '</span>'; setTimeout(close, 900); } else res.innerHTML = '<span class="err">' + esc((r && (r.data && r.data.err || r.data)) || 'не получилось') + '</span>'; }
      else if (a === 'ask') { const q = txt() || 'Что здесь главное?'; b.disabled = true; res.textContent = 'Нейросеть читает расшифровку вокруг момента…'; const r = await bg('yt-ask', { id, s: t, q, title: cv && cv.title }); b.disabled = false; if (r && r.ok && r.data && r.data.text) { res.innerHTML = '<div style="white-space:pre-wrap;color:inherit">' + esc(r.data.text) + '</div><div class="ok">Ответ сохранён заметкой на этот момент</div>'; YW.mom.push({ s: t, t: q, ai: true }); drawTl(); } else res.innerHTML = '<span class="err">' + esc((r && r.data && (r.data.err || r.data.message)) || (r && r.data) || 'нейросеть не ответила') + '</span>'; }
      else if (a === 'frame') { let img = '', iw = 16, ih = 9; try { const c = document.createElement('canvas'); iw = c.width = v.videoWidth; ih = c.height = v.videoHeight; c.getContext('2d').drawImage(v, 0, 0); img = c.toDataURL('image/jpeg', 0.85); } catch (er) { res.innerHTML = '<span class="err">Кадр не снялся — видео защищено</span>'; return; } b.disabled = true; res.textContent = 'Ищу объект этого видео на досках…'; const r = await bg('yt-attach', { id, s: t, image: img, iw, ih, text: txt(), title: cv && cv.title }); b.disabled = false; res.innerHTML = r && r.ok && r.data && r.data.ok ? `<span class="ok">Кадр — к объекту на доске «${esc(r.data.where)}»</span>` : `<span class="err">${esc((r && r.data && r.data.err) || 'не получилось')}. Сохраните видео на доску — кнопкой Холста в плеере.</span>`; }
      else if (a === 'ab') { if (!YW.ab) YW.ab = { a: t, b: null }; else if (YW.ab.b == null && t > YW.ab.a) YW.ab.b = t; else YW.ab = null; drawTl(); close(); hToast(!YW.ab ? 'Повтор убран' : YW.ab.b == null ? 'Начало повтора: ' + fmt(t) + '. Нажмите ещё раз в конце' : 'Повтор ' + fmt(YW.ab.a) + '–' + fmt(YW.ab.b)); }
      else if (a === 'next') { const n = YW.mom.filter(m => m.s > t + 1).sort((x, y) => x.s - y.s)[0]; if (n) { v.currentTime = n.s; close(); } else res.textContent = 'Дальше моментов нет'; }
    });
  }
  addEventListener('keydown', e => { if (!e.altKey || e.ctrlKey || e.metaKey || /input|textarea/i.test((e.target && e.target.tagName) || '') || (e.target && e.target.isContentEditable)) return; const k = e.code;
    if (k === 'KeyN' && vid(location.href)) { e.preventDefault(); e.stopPropagation(); host ? close() : openMoment(); }
    if (k === 'KeyS' && vid(location.href)) { e.preventDefault(); e.stopPropagation(); const v = curVideo(); if (v) bg('yt-add', { videos: [v], kb: true, task: true, w: 60, intent: '', st: '', act: '', tag: false }).then(r => hToast(r && r.ok ? (r.queued ? 'В очереди — уйдёт в Холст сам' : 'Сохранено в Холст') : 'Холст не ответил')); } }, true);
  /* ---------- the feed: sorted by Холст, marks on covers, «+» on a cover ---------- */
  let SYS = { v: {}, ch: {} }, YWALL = {};
  let YWZ = {}, BLK = {}, FEED = null, FEEDP = [];
  async function sysLoad() { const all = await chrome.storage.local.get(null).catch(() => ({})); SYS = all.sys220 || { v: {}, ch: {} }; YWALL = {}; YWZ = {}; for (const k of Object.keys(all)) if (k.startsWith('yw:')) { const o = all[k]; YWALL[k.slice(3)] = o.d ? Math.min(100, Math.round(o.z.reduce((s, z) => s + z[1] - z[0], 0) / o.d * 100)) : 0; YWZ[k.slice(3)] = o; }
    BLK = Object.assign({}, SYS.blk || {}, all.yb221 || {}); for (const [k, b] of Object.entries(BLK)) if (b.until && b.until < Date.now()) delete BLK[k];
    const old = all.ytSort220; FEED = Object.assign(feedDef221(), old ? { by: old.by || '', seen: old.hide ? 'hide' : 'show', only: old.only || '' } : {}, SYS.feed || {}, all.feed221 || {}); FEEDP = all.feedp221 || []; }
  chrome.storage.onChanged.addListener((ch, area) => { if (!alive()) return; if (area === 'local' && Object.keys(ch).some(k => k === 'sys220' || k.startsWith('yw:') || k === 'yb221' || k === 'feed221' || k === 'feedp221')) sysLoad().then(() => { marks(true); applyFeed221(true); }); });
  sysLoad();
  const seenOf = id => Math.max(YWALL[id] || 0, (SYS.v[id] || {}).seen || 0);
  const chKey = c => { const a = c.querySelector('a[href^="/@"], a[href*="/channel/"]'); return a ? ('youtube.com' + new URL(a.getAttribute('href'), location.origin).pathname).toLowerCase().replace(/\/$/, '') : ''; };
  const isFeed = () => /^\/$|^\/feed\/subscriptions|^\/results|\/(videos|streams)\/?$|^\/playlist/.test(location.pathname);
  const ST_ORD = { 'в работе': 0, 'новое': 1, 'просмотрено': 2, 'разобрано': 3, 'архив': 4 };
  function marks(force) {
    for (const c of document.querySelectorAll(CARDS)) {
      const v = cardVideo(c); if (!v) continue; const P0 = SYS.v[v.id], P = P0 && P0.in ? P0 : null, seen = seenOf(v.id), sig = (P ? 'p' + (P.w || '') + (P.imp || '') + (P.st || '') : '') + '|' + seen;
      const th = c.querySelector('ytd-thumbnail, yt-thumbnail-view-model, a#thumbnail, .yt-lockup-view-model-wiz__content-image, .yt-lockup-view-model__content-image'); if (!th) continue;
      if (!th.dataset.holstPos) { th.dataset.holstPos = '1'; if (getComputedStyle(th).position === 'static') th.style.position = 'relative'; }
      if (!th.querySelector('.holst-add')) { const a = document.createElement('button'); a.className = 'holst-add'; a.title = 'В Холст — сразу, с весом 60'; a.textContent = '+'; a.style.cssText = 'position:absolute;right:6px;top:6px;z-index:5;width:26px;height:26px;border-radius:50%;border:0;background:rgba(15,15,15,.85);color:#fff;font:700 17px/26px Roboto,Arial;cursor:pointer;opacity:0;transition:opacity .12s';
        a.addEventListener('click', async e => { e.preventDefault(); e.stopPropagation(); const vv = cardVideo(c); if (!vv) return; a.textContent = '…'; const r = await bg('yt-add', { videos: [vv], kb: true, task: true, w: 60, intent: '', st: '', act: '', tag: false }); a.textContent = r && r.ok ? '✓' : '!'; a.title = r && r.ok ? (r.queued ? 'В очереди — уйдёт сам' : 'В Холсте') : 'Холст не ответил'; }, true);
        th.addEventListener('mouseenter', () => { a.style.opacity = '1'; const h = th.querySelector('.holst-hide'); if (h) h.style.opacity = '1'; }); th.addEventListener('mouseleave', () => { if (a.textContent === '+') a.style.opacity = '0'; const h = th.querySelector('.holst-hide'); if (h) h.style.opacity = '0'; }); th.appendChild(a);
        const hb = document.createElement('button'); hb.className = 'holst-hide'; hb.title = 'Скрыть канал в ленте: навсегда или на время'; hb.innerHTML = EYEOFF; hb.style.cssText = 'position:absolute;right:36px;top:6px;z-index:5;width:26px;height:26px;border-radius:50%;border:0;background:rgba(15,15,15,.85);color:#fff;cursor:pointer;opacity:0;transition:opacity .12s;display:grid;place-items:center;padding:0';
        hb.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); hideMenu221(c, hb); }, true); th.appendChild(hb); }
      const yck = [...ycCats(v.id, chKey(c))]; const sig2 = sig + '|' + yck.join(',');
      if (!force && th.dataset.holstB === sig2) continue; th.dataset.holstB = sig2;
      let m = th.querySelector('.holst-b'); if (!P && !seen && !yck.length) { if (m) m.remove(); continue; }
      if (!m) { m = document.createElement('div'); m.className = 'holst-b'; m.style.cssText = 'position:absolute;left:0;right:0;top:0;bottom:0;pointer-events:none;z-index:4'; th.appendChild(m); }
      m.innerHTML = (P ? `<span style="position:absolute;left:6px;top:6px;background:#ffd84d;color:#3d2f00;border-radius:9px;padding:1px 7px;font:700 11px/18px Roboto,Arial">Холст${P.imp ? ' ★' + P.imp : P.w != null ? ' ' + P.w : ''}</span>` : '') + (seen ? `<i style="position:absolute;left:0;right:0;bottom:0;height:4px;background:rgba(0,0,0,.35)">${((YWZ[v.id] && YWZ[v.id].d) ? YWZ[v.id].z.map(z => `<b style="position:absolute;top:0;bottom:0;left:${(z[0] / YWZ[v.id].d * 100).toFixed(2)}%;width:${((z[1] - z[0]) / YWZ[v.id].d * 100).toFixed(2)}%;background:#2fa36b"></b>`).join('') : `<b style="position:absolute;top:0;bottom:0;left:0;width:${seen}%;background:#2fa36b"></b>`)}</i>` : '') + (yck.length ? `<span style="position:absolute;left:6px;bottom:10px;display:flex;flex-wrap:wrap;gap:3px;max-width:70%">${yck.slice(0, 4).map(k => { const x = ycOpt(k); return x ? `<b style="background:${x.O.c};color:#111;border-radius:7px;padding:0 6px;font:600 10.5px/16px Roboto,Arial">${esc(x.O.n)}</b>` : ''; }).join('')}</span>` : '') + (P0 && P0.rw ? `<span style="position:absolute;right:6px;bottom:8px;background:rgba(15,15,15,.85);color:#fff;border-radius:9px;padding:0 6px;font:600 10.5px/16px Roboto,Arial" title="Пересмотров">↻ ${P0.rw}</span>` : '');
    }
  }
  /* ---------- v2.21: the feed — settings in the masthead, filters by Холст, blocks of content, hidden channels, presets ---------- */
  const EYEOFF = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3l18 18"/><path d="M10.6 5.1A10 10 0 0 1 12 5c5 0 9 4.5 10 7-.4 1-1.2 2.3-2.4 3.5M6.3 6.3C4.3 7.6 2.8 9.6 2 12c1 2.5 5 7 10 7 1.7 0 3.2-.5 4.6-1.2"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>';
  function feedDef221() { return { preset: '', shorts: 1, per: 0, seen: 'show', seenMin: 90, by: '', only: '', mute: '', durMin: 0, durMax: 0, blocks: [], marks: 1 }; }
  const FP0 = [
    { n: 'Как есть', s: {} },
    { n: 'Чистая лента', s: { shorts: 0, seen: 'hide', seenMin: 90, per: 4 } },
    { n: 'Учёба', s: { shorts: 0, seen: 'dim', by: 'wt', blocks: [{ n: 'Важное из Холста', f: [['imp', '>=', 7]] }, { n: 'Начатые', f: [['seen', '>=', 5], ['seen', '<', 85]] }] } },
    { n: 'Длинное', s: { shorts: 0, durMin: 20, seen: 'dim' } }
  ];
  const FLD = { imp: ['Важность', 1, 11], w: ['Вес', 0, 100], wt: ['Итоговый вес', 0, 100], wv: ['Интерес из просмотра', 0, 100], seen: ['Досмотрено, %', 0, 100], rw: ['Пересмотров', 0, 50], tv: ['Просмотров в истории', 0, 99], dur: ['Длительность, мин', 0, 600], age: ['Возраст, дней', 0, 3650], ch: ['Вес канала', 0, 100], in: ['В Холсте: 1 или 0', 0, 1] };
  const ageOf = c => { const t = (c.innerText || '').toLowerCase(), m = t.match(/(\d+)\s*(сек|мин|час|дн|день|дня|нед|мес|год|лет|second|minute|hour|day|week|month|year)/); if (!m) return null; const u = m[2]; return +m[1] * (/сек|second|мин|minute|час|hour/.test(u) ? 0 : /дн|день|дня|day/.test(u) ? 1 : /нед|week/.test(u) ? 7 : /мес|month/.test(u) ? 30 : 365); };
  const factsOf0 = c => { const v = cardVideo(c); if (!v) return null; const P = SYS.v[v.id] || {}; return { v, id: v.id, imp: +P.imp || 0, w: P.w != null ? +P.w : null, wt: P.wt != null ? +P.wt : null, wv: P.wv != null ? +P.wv : null, seen: seenOf(v.id), rw: +P.rw || 0, tv: +P.tv || 0, dur: v.meta.dur ? v.meta.dur / 60 : null, age: ageOf(c), ch: SYS.ch[chKey(c)] != null ? +SYS.ch[chKey(c)] : null, in: P.in ? 1 : 0, st: P.st || '', cat: ycCats(v.id, chKey(c)) }; };
  const pass = (X, f) => f.every(([k, op, val]) => { if (op === 'has') return !!(X.cat && X.cat.has(val)); if (op === 'sys') return !!(X.sys && X.sys.has(val)); if (op === 'nsys') return !(X.sys && X.sys.has(val)); const x = X[k]; if (x == null) return false; return op === '>=' ? x >= val : op === '<=' ? x <= val : op === '<' ? x < val : op === '>' ? x > val : x == val; });

  const SUBS224 = new Set(), BL224 = new Set(), SEEN224 = new Set(); let SUBT224 = 0;
  chrome.storage.local.get('subs224').then(r => { (r.subs224 || []).forEach(x => SUBS224.add(x)); }).catch(() => {});
  const SYSN224 = { kind: ['Тип', { video: 'видео', shorts: 'шортс', live: 'в эфире', premiere: 'премьера', stream: 'запись эфира', playlist: 'плейлист', mix: 'микс' }], len: ['Длина', { s: 'до 4 мин', m: '4–20 мин', l: '20–60 мин', xl: 'больше часа' }], age: ['Новизна', { d: 'сегодня', 3: 'до 3 дней', w: 'до недели', m: 'до месяца', o: 'старше месяца' }], sub: ['Подписка', { 1: 'есть', 0: 'нет' }], tag: ['Хештег', {}], badge: ['Значок', {}], sec: ['Раздел ленты', {}], kw: ['Ключевое слово', {}] };
  const sysLabel224 = v => { const [g, ...r] = String(v).split(':'), x = r.join(':'), G = SYSN224[g]; return G ? G[0] + ': ' + (G[1][x] || x) : v; };
  function sys224(c, X) {
    const S2 = new Set(), txt = (c.innerText || '').toLowerCase();
    const tt = X.v.title || ((c.querySelector('#video-title, a#video-title-link, h3 a, .yt-lockup-metadata-view-model-wiz__title, .yt-lockup-metadata-view-model__title, yt-formatted-string#video-title') || {}).textContent || '').trim();
    if (!X.v.title && tt) X.v.title = tt;
    let kind = 'video';
    if (c.querySelector('a[href*="/shorts/"]')) kind = 'shorts';
    else if (/в эфире|live now|смотрят сейчас|watching now/.test(txt)) kind = 'live';
    else if (/премьера|premiere|запланировано|scheduled|ожидается/.test(txt)) kind = 'premiere';
    else if (/трансляция закончилась|streamed|был в эфире|трансляция прошла/.test(txt)) kind = 'stream';
    else if (c.matches('ytd-playlist-renderer, ytd-radio-renderer') || c.querySelector('yt-collection-thumbnail-view-model, ytd-playlist-thumbnail') || /(^|\s)(микс|mix)(\s|$)|плейлист|playlist/.test(txt)) kind = /(^|\s)(микс|mix)(\s|$)/.test(txt) ? 'mix' : 'playlist';
    S2.add('kind:' + kind);
    if (X.dur != null) S2.add('len:' + (X.dur < 4 ? 's' : X.dur < 20 ? 'm' : X.dur < 60 ? 'l' : 'xl'));
    if (X.age != null) S2.add('age:' + (X.age < 1 ? 'd' : X.age <= 3 ? '3' : X.age <= 7 ? 'w' : X.age <= 30 ? 'm' : 'o'));
    const k = chKey(c), onSubs = /\/feed\/subscriptions/.test(location.pathname); if (onSubs && k && !SUBS224.has(k)) { SUBS224.add(k); clearTimeout(SUBT224); SUBT224 = setTimeout(() => chrome.storage.local.set({ subs224: [...SUBS224].slice(-5000) }), 3000); }
    const ptP = YC.props.find(q => q.src === 'pockettube'), sub = onSubs || SUBS224.has(k) || !!(ptP && YC.ch && YC.ch[k] && (YC.ch[k][ptP.id] || []).length);
    S2.add('sub:' + (sub ? 1 : 0));
    for (const m of (tt.match(/#[\p{L}\d_]+/gu) || [])) S2.add('tag:' + m.toLowerCase());
    for (const b of c.querySelectorAll('ytd-badge-supported-renderer .badge, badge-shape, .badge-shape-wiz__text')) { const t = (b.textContent || '').trim().toLowerCase(); if (t && t.length < 20 && !/^\d/.test(t)) S2.add('badge:' + t); }
    const chip = document.querySelector('yt-chip-cloud-chip-renderer[selected] #text, yt-chip-cloud-chip-renderer.iron-selected #text, yt-chip-cloud-chip-renderer[aria-selected="true"] #text'); if (chip && chip.textContent.trim()) S2.add('sec:' + chip.textContent.trim().toLowerCase());
    const kw = String((FEED && FEED.kw224) || '').toLowerCase().split(',').map(x => x.trim()).filter(Boolean), tl = tt.toLowerCase(); for (const w of kw) if (tl.includes(w)) S2.add('kw:' + w);
    X.sys = S2; S2.forEach(v => SEEN224.add(v));
  }
  const factsOf = c => { const X = factsOf0(c); if (!X) return null; try { sys224(c, X); } catch (e) { X.sys = new Set(); } return X; };
  function sysHide224(X, F) {
    const on = F.sysOn || [], off = F.sysOff || [], has = v => !!(X.sys && X.sys.has(v));
    if (on.length) { const G = {}; for (const v of on) (G[v.split(':')[0]] = G[v.split(':')[0]] || []).push(v); for (const g in G) if (!G[g].some(has)) return true; }
    if (off.some(has)) return true;
    const a = +F.age224 || 0; if (a > 0 && (X.age == null || X.age > a)) return true; if (a < 0 && (X.age == null || X.age <= -a)) return true;
    return F.dedupe !== 0 && BL224.has(X.id);
  }
  const tap224 = (b, fn) => { let t = 0; const run = e => { e.stopPropagation(); e.preventDefault(); if (Date.now() - t < 450) return; t = Date.now(); fn(e); }; b.addEventListener('pointerup', run, true); b.addEventListener('click', run, true); ['pointerdown', 'mousedown'].forEach(k => b.addEventListener(k, e => e.stopPropagation(), true)); };
  const bfLabel224 = ([k, op, v]) => (op === 'has' ? ycLabel(v) : op === 'sys' ? sysLabel224(v) : op === 'nsys' ? 'не ' + sysLabel224(v) : (FLD[k] || [k])[0] + ' ' + op + ' ' + v);
  function feedCss() {
    let st = document.getElementById('holst-feed-css'); if (!st) { st = document.createElement('style'); st.id = 'holst-feed-css'; document.documentElement.appendChild(st); }
    const F = FEED || feedDef221();
    const css = '[data-holst-hide]{display:none!important}[data-holst-dim]{opacity:.38;transition:opacity .15s}[data-holst-dim]:hover{opacity:1}'
      + (F.shorts ? '' : 'ytd-rich-shelf-renderer[is-shorts],ytd-reel-shelf-renderer,ytd-rich-section-renderer:has(ytd-rich-shelf-renderer[is-shorts]),ytd-guide-entry-renderer:has(a[title="Shorts"]),ytd-mini-guide-entry-renderer[aria-label="Shorts"],ytd-rich-item-renderer:has(a[href*="/shorts/"]),ytd-video-renderer:has(a[href*="/shorts/"]),grid-shelf-view-model:has(a[href*="/shorts/"]){display:none!important}')
      + (F.marks === 0 ? '.holst-b{display:none!important}' : '');
    if (st.textContent !== css) st.textContent = css;
    for (const x of document.querySelectorAll('ytd-rich-grid-renderer')) { if (F.per) x.style.setProperty('--ytd-rich-grid-items-per-row', String(F.per)); else x.style.removeProperty('--ytd-rich-grid-items-per-row'); }
  }
  function applyFeed221(force) {
    if (!FEED) return; feedCss();
    if (!isFeed()) { const bl = document.getElementById('holst-blocks'); if (bl) bl.remove(); return; }
    const F = FEED, mute = String(F.mute || '').toLowerCase().split(',').map(s => s.trim()).filter(Boolean);
    const cards = [...document.querySelectorAll('ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer, ytd-playlist-video-renderer')];
    const by = new Map(), facts = new Map();
    for (const c of cards) {
      if (c.closest('#holst-blocks')) continue; const X = factsOf(c); if (!X) continue; facts.set(c, X);
      const t = (X.v.title || '').toLowerCase();
      const hide = !!BLK[chKey(c)] || (F.seen === 'hide' && X.seen >= F.seenMin) || (F.only === 'in' && !X.in) || (F.only === 'new' && (X.in || X.seen >= 20)) || mute.some(w => t.includes(w)) || (F.durMin && X.dur != null && X.dur < F.durMin) || (F.durMax && X.dur != null && X.dur > F.durMax) || (F.cat && !(X.cat && X.cat.has(F.cat))) || (F.catNo && X.cat && X.cat.has(F.catNo)) || sysHide224(X, F);
      if (hide) c.setAttribute('data-holst-hide', '1'); else c.removeAttribute('data-holst-hide');
      if (!hide && F.seen === 'dim' && X.seen >= F.seenMin) c.setAttribute('data-holst-dim', '1'); else c.removeAttribute('data-holst-dim');
      const p = c.parentElement; if (!by.has(p)) by.set(p, []); by.get(p).push(c);
    }
    if (+F.perCh224 > 0) { const G = new Map(); for (const [c, X] of facts) { if (c.hasAttribute('data-holst-hide')) continue; const k = chKey(c); if (!G.has(k)) G.set(k, []); G.get(k).push([c, X]); } for (const L of G.values()) L.sort((a, b) => (a[1].age == null ? 1e9 : a[1].age) - (b[1].age == null ? 1e9 : b[1].age)).slice(+F.perCh224).forEach(([c]) => c.setAttribute('data-holst-hide', '1')); }
    const ycSortKey = String(F.by || '').startsWith('cat:') ? (() => { const P = YC.props.find(q => q.id === F.by.slice(4)); return x => { if (!P || !x.cat) return -999; const i = P.opts.findIndex(o => x.cat.has(P.id + ':' + o.id)); return i < 0 ? -999 : -i; }; })() : null;
    const key = ycSortKey || { w: x => (x.w != null ? x.w : -1), wt: x => (x.wt != null ? x.wt : x.w != null ? x.w : -1), imp: x => x.imp || -1, rw: x => x.rw, seen: x => -x.seen, ch: x => (x.ch != null ? x.ch : -1), in: x => x.in, views: x => (x.views != null ? x.views : -1), vel: x => (x.vel != null ? x.vel : -1), ytp: x => x.ytp || 0, new: x => (x.age != null ? -x.age : -1e9), old: x => (x.age != null ? x.age : -1), st: x => -(x.st in ST_ORD ? ST_ORD[x.st] : 9) }[F.by];
    for (const [par, L] of by) { const flex = /flex|grid/.test(getComputedStyle(par).display); const K = L.map((c, i) => ({ c, i, k: key ? key(facts.get(c)) : 0 })); const S2 = key ? K.slice().sort((a, b) => (b.k - a.k) || a.i - b.i) : K; if (flex) S2.forEach((x, n) => { x.c.style.order = key ? String(n) : ''; }); }
    blocks221(facts, force);
  }
  /* blocks of content: by your filters, from the feed and from Холст */
  function blocks221(facts, force) {
    const list = FEED.blocks || []; let box = document.getElementById('holst-blocks');
    if (!list.length) { if (box) box.remove(); return; }
    const host = document.querySelector('ytd-rich-grid-renderer, ytd-section-list-renderer'); if (!host || !host.parentElement) return;
    if (!box) { box = document.createElement('div'); box.id = 'holst-blocks'; box.style.cssText = 'margin:12px 0 4px;display:flex;flex-direction:column;gap:14px;font:14px Roboto,Arial,sans-serif;color:var(--yt-spec-text-primary,#0f0f0f)'; }
    if (box.nextElementSibling !== host) host.parentElement.insertBefore(box, host);
    const all = [...facts.values()];
    const used224 = new Set();
    const out = list.map(b => { const L = []; for (const X of all) if (!L.some(x => x.id === X.id) && !used224.has(X.id) && pass(X, b.f || [])) L.push({ id: X.id, t: X.v.title || '', ch: X.v.channel || '', X });
      for (const [id, P] of Object.entries(SYS.v || {})) { if (L.length >= lim226(b) || !P.t || L.some(x => x.id === id)) continue; const X = { cat: ycCats(id, ''), imp: +P.imp || 0, w: P.w != null ? +P.w : null, wt: P.wt != null ? +P.wt : null, wv: P.wv != null ? +P.wv : null, seen: Math.max(YWALL[id] || 0, P.seen || 0), rw: +P.rw || 0, tv: +P.tv || 0, dur: null, age: null, ch: null, in: P.in ? 1 : 0 }; if (!used224.has(id) && pass(X, b.f || [])) L.push({ id, t: P.t, ch: P.chn || '', X }); }
      const L2 = L.slice(0, lim226(b)); L2.forEach(x => used224.add(x.id)); return [b, L2]; });
    BL224.clear(); used224.forEach(id => BL224.add(id));
    const sig = JSON.stringify(out.map(([b, L]) => [b.n, L.map(x => x.id)])); if (!force && box.dataset.sig === sig) return; box.dataset.sig = sig;
    box.innerHTML = out.map(([b, L]) => `<section style="border:2px solid ${esc(b.c || '#d9d9d9')};border-radius:14px;padding:10px 12px;--w224:${b.size === 's' ? 170 : b.size === 'l' ? 270 : 210}px"><div style="display:flex;align-items:baseline;gap:8px;margin:0 0 6px;flex-wrap:wrap"><b style="font-size:16px">${esc(b.n)}</b><span style="color:#606060;font-size:12px">Холст · ${L.length}${(b.f || []).length ? ' · ' + esc((b.f || []).map(bfLabel224).join(' и ')) : ''}</span></div>${L.length ? `<div style="${bl226(b)}">${L.map(x => `<a class="holst-bi" href="/watch?v=${esc(x.id)}" style="flex:none;width:var(--w224,210px);color:inherit;text-decoration:none"><span style="position:relative;display:block;border-radius:10px;overflow:hidden;aspect-ratio:16/9;background:#0002"><img src="https://i.ytimg.com/vi/${esc(x.id)}/mqdefault.jpg" alt="" style="width:100%;height:100%;object-fit:cover">${x.X.seen ? `<i style="position:absolute;left:0;bottom:0;height:4px;width:${x.X.seen}%;background:#2fa36b"></i>` : ''}${x.X.imp ? `<span style="position:absolute;left:6px;top:6px;background:#ffd84d;color:#3d2f00;border-radius:9px;padding:0 6px;font:700 11px/18px Roboto,Arial">★${x.X.imp}</span>` : ''}</span><span style="display:block;font-weight:500;font-size:13px;line-height:1.3;margin-top:5px;max-height:2.6em;overflow:hidden">${esc(x.t || 'Видео')}</span><span style="color:#606060;font-size:12px;display:block">${esc(x.ch || x.X.v && x.X.v.channel || '')}</span><span style="color:#606060;font-size:11.5px;display:block">${esc(x.X.meta || (x.X.views != null ? fmt225(x.X.views) + ' просмотров' : ''))}</span></a>`).join('')}</div>` : '<div style="color:#606060;font-size:12.5px">Пока ничего не подходит под этот блок.</div>'}</section>`).join('');
  }
  /* the button in the masthead — right of the voice search */
  const HSVG = '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6h10M4 12h16M4 18h7"/><circle cx="17" cy="6" r="2"/><circle cx="14" cy="18" r="2"/></svg>';
  function mast221() {
    let b = document.getElementById('holst-yt-mast'); const anchor = document.querySelector('#voice-search-button');
    if (!b) { b = document.createElement('button'); b.id = 'holst-yt-mast'; b.title = 'Холст: настройки ленты'; b.setAttribute('aria-label', 'Холст: настройки ленты'); b.innerHTML = HSVG;
      b.style.cssText = 'width:40px;height:40px;border-radius:50%;border:0;background:transparent;color:var(--yt-spec-text-primary,#0f0f0f);cursor:pointer;display:inline-grid;place-items:center;margin-left:8px;flex:none;padding:0';
      b.addEventListener('click', e => { e.stopPropagation(); feedPanel221(); }); }
    if (anchor) { if (b.previousElementSibling !== anchor) anchor.after(b); }
    else if (!b.isConnected) { b.style.cssText += ';position:fixed;right:16px;top:12px;z-index:2147483645;background:#0f0f0f;color:#fff'; document.documentElement.appendChild(b); }
  }
  const FSTY = `:host{all:initial}*{box-sizing:border-box}.p{position:fixed;z-index:2147483646;width:390px;max-height:min(680px,calc(100vh - 80px));overflow:auto;background:#fff;color:#0f0f0f;border-radius:14px;box-shadow:0 18px 50px -12px rgba(0,0,0,.45);font:13px/1.4 Roboto,Arial,sans-serif;padding:12px 14px;display:flex;flex-direction:column;gap:10px}
    .h{display:flex;align-items:center;gap:8px}.h b{flex:1;font-size:14.5px}.x{border:0;background:none;cursor:pointer;color:inherit;padding:4px;border-radius:6px;line-height:0}.x:hover{background:#0000000f}
    .row{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.row>span{width:96px;color:#606060;font-size:12px;flex:none}
    .seg{display:flex;flex-wrap:wrap;gap:4px}.seg button{border:1px solid #d9d9d9;background:transparent;color:inherit;border-radius:999px;padding:3px 10px;font:500 12px Roboto,Arial,sans-serif;cursor:pointer}.seg button.on{background:#ffd84d;color:#3d2f00;border-color:#e6bf2e}
    select,input{border:1px solid #d9d9d9;border-radius:8px;padding:5px 8px;font:inherit;color:inherit;background:transparent}input[type=number]{width:70px}
    .more{border:0;background:none;color:#065fd4;font:500 12.5px Roboto,Arial;cursor:pointer;padding:0;text-align:left}
    .sec{border-top:1px solid #e5e5e5;padding-top:8px;display:flex;flex-direction:column;gap:8px}.sec h5{margin:0;font-size:12px;color:#606060;text-transform:uppercase;letter-spacing:.03em}
    .bl{display:flex;flex-direction:column;gap:4px}.bl div{display:flex;align-items:center;gap:6px;font-size:12.5px}.bl div span{flex:1}.bl small{color:#606060}
    .go{height:32px;border:0;border-radius:16px;background:#0f0f0f;color:#fff;font:600 12.5px Roboto,Arial;cursor:pointer;padding:0 14px}.ghost{background:transparent;color:inherit;border:1px solid #d9d9d9}
    .hint{color:#606060;font-size:11.5px;margin:0}
    @media (prefers-color-scheme:dark){.p{background:#212121;color:#f1f1f1}.row>span,.sec h5,.bl small,.hint{color:#aaa}select,input,.seg button,.ghost{border-color:#3f3f3f}.sec{border-color:#3f3f3f}.go{background:#f1f1f1;color:#0f0f0f}}${STD224}`;
  const FOPEN = { more: false };
  function pageActs() {
    const L = []; if (isList() && !/\/feed\/channels/.test(location.pathname)) L.push(['list', 'Видео этой страницы — в Холст']);
    if (chHere()) L.push(['src', 'Канал — в источники'], ['cpage', 'Категории канала']); else if (plHere()) L.push(['src', 'Плейлист — в источники'], ['cpage', 'Категории плейлиста']); else if (vid(location.href)) L.push(['cpage', 'Категории видео']);
    return L.length ? `<div class="row pa">${L.map(([a, l]) => `<button class="go ghost" data-a="${a}">${l}</button>`).join('')}</div>` : '';
  }
  function catSec() {
    const F = FEED || {}, cur = F.cat ? '+' + F.cat : F.catNo ? '-' + F.catNo : '';
    const opts = YC.props.flatMap(P => P.opts.map(O => [P.id + ':' + O.id, P.n + ' — ' + O.n]));
    return `<div class="row"><span>Свойства</span>${opts.length ? `<select data-a="ycf"><option value="">все видео</option>${opts.map(([k, l]) => `<option value="+${k}"${cur === '+' + k ? ' selected' : ''}>только ${esc(l)}</option>`).join('')}${opts.map(([k, l]) => `<option value="-${k}"${cur === '-' + k ? ' selected' : ''}>кроме ${esc(l)}</option>`).join('')}</select>` : '<small style="color:#606060">своих ещё нет</small>'}<button class="go ghost" data-a="cmanage" title="Свои свойства и опции: создать, переименовать, удалить">Свойства</button></div>`;
  }
  function feedSave221() { chrome.storage.local.set({ feed221: FEED }); bg('feed-save', FEED); applyFeed221(true); }
  function feedPanel221(keep) {
    let host = document.getElementById('holst-feed');
    if (host && !keep) { host.remove(); return; }
    if (!host) { host = document.createElement('div'); host.id = 'holst-feed'; document.documentElement.appendChild(host); host.attachShadow({ mode: 'open' }); host.shadowRoot.addEventListener('click', e => feedClick221(e, host), true); host.shadowRoot.addEventListener('change', e => feedChange221(e), true); }
    if (!FEED) FEED = feedDef221(); const F = FEED, b = document.getElementById('holst-yt-mast'), r = b ? b.getBoundingClientRect() : { right: innerWidth - 16, bottom: 56 };
    const seg = (k, L) => `<div class="seg" data-k="${k}">${L.map(([v, l]) => `<button class="${String(F[k]) === String(v) ? 'on' : ''}" data-v="${v}">${l}</button>`).join('')}</div>`;
    const pres = FP0.concat(FEEDP), blk = Object.entries(BLK);
    host.shadowRoot.innerHTML = `<style>${FSTY}</style><div class="p" style="left:${Math.max(8, Math.min(innerWidth - 398, r.right - 390))}px;top:${r.bottom + 6}px">
      <div class="h"><b>Лента · Холст</b><button class="x" data-a="x" title="Закрыть">${XSVG}</button></div>
      <div class="panels224"><button class="go ghost" data-a="p224main">Панель «В Холст»</button><button class="go ghost" data-a="cmanage">Категории и PocketTube</button><button class="go ghost" data-a="p224subs">Каналы подписок</button>${chHere() || plHere() ? '<button class="go ghost" data-a="src">В источники</button>' : ''}${isList() ? '<button class="go ghost" data-a="list">Видео страницы — в Холст</button>' : ''}</div>
      ${pageActs()}
      <div class="row"><span>Пресет</span><select data-a="preset"><option value="">—</option>${pres.map(p => `<option${F.preset === p.n ? ' selected' : ''}>${esc(p.n)}</option>`).join('')}</select></div>
      <div class="row"><span>Шортсы</span>${seg('shorts', [[1, 'показывать'], [0, 'скрыть']])}</div>
      <div class="row"><span>В ряду</span>${seg('per', [[0, 'авто'], [3, '3'], [4, '4'], [5, '5'], [6, '6']])}</div>
      <div class="row"><span>Новизна</span>${seg('age224', [[0, 'всё'], [1, 'сегодня'], [3, '3 дня'], [7, 'неделя'], [30, 'месяц'], [-30, 'старше месяца']])}</div>
      <div class="row"><span>Новое у каналов</span><select data-k="perCh224">${[[0, 'все ролики'], [1, '1 последний'], [2, '2 последних'], [3, '3 последних'], [5, '5 последних']].map(([v, l]) => `<option value="${v}"${+F.perCh224 === v ? ' selected' : ''}>${l}</option>`).join('')}</select><small class="hint">у каждого канала</small></div>
      <div class="row"><span>Досмотренное</span>${seg('seen', [['show', 'показывать'], ['dim', 'затемнять'], ['hide', 'скрыть']])}</div>
      <div class="row"><span>Сортировка</span><select data-k="by">${[['', 'порядок YouTube'], ['new', 'сначала новые'], ['old', 'сначала старые'], ['views', 'больше просмотров'], ['vel', 'быстрее набирает просмотры'], ['ytp', 'досмотрено по YouTube'], ['wt', 'итоговый вес Холста'], ['w', 'вес'], ['imp', 'важность'], ['st', 'статус'], ['rw', 'пересмотры'], ['seen', 'меньше просмотрено'], ['ch', 'вес канала'], ['in', 'сначала из Холста']].concat(YC.props.map(P => ['cat:' + P.id, 'по категории «' + P.n + '»'])).map(([k, l]) => `<option value="${k}"${F.by === k ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select></div>
      ${catSec()}
      <button class="more" data-a="more">${FOPEN.more ? 'Свернуть' : 'Ещё: блоки контента, фильтры, скрытые каналы, свои пресеты'}</button>
      ${FOPEN.more ? `<div class="sec"><h5>Фильтры</h5>
        <div class="row"><span>Досмотрено от</span><select data-k="seenMin">${[50, 70, 90].map(v => `<option${+F.seenMin === v ? ' selected' : ''}>${v}</option>`).join('')}</select>%</div>
        <div class="row"><span>Длительность</span>от <input type="number" min="0" data-k="durMin" value="${F.durMin || ''}"> до <input type="number" min="0" data-k="durMax" value="${F.durMax || ''}"> мин</div>
        <div class="row"><span>Показывать</span>${seg('only', [['', 'всё'], ['in', 'только из Холста'], ['new', 'только новое']])}</div>
        <div class="row"><span>Слова-исключения</span><input data-k="mute" placeholder="через запятую" value="${esc(F.mute || '')}" style="flex:1"></div>
        <div class="row"><span>Метки Холста</span>${seg('marks', [[1, 'на обложках'], [0, 'без меток']])}</div></div>
      <div class="sec"><h5>Системные свойства — из данных YouTube</h5>
        ${['kind', 'len', 'sub'].map(g => `<div class="row"><span>${SYSN224[g][0]}</span><div class="seg">${Object.entries(SYSN224[g][1]).map(([k, l]) => `<button class="${(F.sysOn || []).includes(g + ':' + k) ? 'on' : ''}" data-sys224="${g}:${k}">${l}</button>`).join('')}</div></div>`).join('')}
        <div class="row"><span>Ещё</span><select data-a="sysadd224"><option value="">только с…</option>${[...SEEN224].filter(v => /^(tag|badge|sec|kw):/.test(v)).sort().map(v => `<option value="${esc(v)}">${esc(sysLabel224(v))}</option>`).join('')}</select><select data-a="sysoff224"><option value="">скрыть…</option>${[...SEEN224].sort().map(v => `<option value="${esc(v)}">${esc(sysLabel224(v))}</option>`).join('')}</select></div>
        <div class="row">${(F.sysOn || []).map(v => `<button class="chip224" data-syson224="${esc(v)}" title="Убрать">только ${esc(sysLabel224(v))} ✕</button>`).join('')}${(F.sysOff || []).map(v => `<button class="chip224" data-sysx224="${esc(v)}" title="Убрать">без ${esc(sysLabel224(v))} ✕</button>`).join('')}</div>
        <div class="row"><span>Ключевые слова</span><input data-k="kw224" placeholder="через запятую: становятся свойствами" value="${esc(F.kw224 || '')}" style="flex:1"></div>
        <div class="row"><span>Без дублей</span>${seg('dedupe', [[1, 'видео из блоков не повторять в ленте'], [0, 'повторять']])}</div></div>
      <div class="sec"><h5>Блоки контента сверху ленты</h5><div class="bl">${(F.blocks || []).map((x, i) => `<div class="blk224" style="border-color:${esc(x.c || '#e3e3e3')}"><div><span><b>${esc(x.n)}</b></span><small>${esc((x.f || []).map(bfLabel224).join(' и ') || 'без условий')}</small><button class="go ghost" data-bedit="${i}">Изменить</button><button class="x" data-bdel="${i}" title="Убрать">${XSVG}</button></div></div>`).join('') || '<small>Блоков нет — сделайте свой: из ленты и из Холста по фильтру.</small>'}</div>${bedHTML224()}
      <div class="sec"><h5>Скрытые каналы</h5><div class="bl">${blk.map(([k, v]) => `<div><span>${esc(v.n || k)}</span><small>${v.until ? 'до ' + new Date(v.until).toLocaleDateString('ru-RU') : 'навсегда'}</small><button class="go ghost" data-unb="${esc(k)}">Вернуть</button></div>`).join('') || '<small>Никого — «скрыть канал» на обложке.</small>'}</div></div>
      <div class="sec"><h5>Свои пресеты</h5><div class="row"><button class="go" data-a="psave">Сохранить как пресет</button>${FEEDP.length ? `<select data-a="pdel"><option value="">Удалить пресет…</option>${FEEDP.map((p, i) => `<option value="${i}">${esc(p.n)}</option>`).join('')}</select>` : ''}</div><p class="hint">Всё учитывает данные Холста: важность, вес, итоговый вес с пересмотрами, статус, досмотренность, историю из Takeout, вес канала.</p></div>` : ''}
    </div>`;
  }

  /* the editor of a block: any block, any number of conditions, all optional */
  function bedHTML224() {
    const B = FOPEN.bed || { i: -1, n: '', c: '#d9d9d9', size: 'm', f: [] };
    const opts = Object.entries(FLD).map(([k, [l]]) => [k, l]).concat(YC.props.flatMap(P => P.opts.map(O => ['cat=' + P.id + ':' + O.id, 'Категория: ' + P.n + ' — ' + O.n]))).concat(Object.entries(SYSN224).flatMap(([g, [gl, M]]) => Object.entries(M).map(([k, l]) => ['sys=' + g + ':' + k, gl + ': ' + l]))).concat([...SEEN224].filter(v => /^(tag|badge|sec|kw):/.test(v)).map(v => ['sys=' + v, sysLabel224(v)]));
    const key = ([k, op, v]) => (op === 'has' ? 'cat=' + v : op === 'sys' || op === 'nsys' ? 'sys=' + v : k);
    const row = (c, i) => { const k = key(c), num = !/^(cat|sys)=/.test(k); return `<div class="row"><select data-bf="${i}:k"><option value="">— условие —</option>${opts.map(([v, l]) => `<option value="${esc(v)}"${v === k ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select>${num ? `<select data-bf="${i}:op">${['>=', '<=', '=', '>', '<'].map(o => `<option${o === c[1] ? ' selected' : ''}>${esc(o)}</option>`).join('')}</select><input type="number" data-bf="${i}:v" value="${esc(c[2] != null ? c[2] : '')}">` : `<select data-bf="${i}:op"><option value="sys"${c[1] !== 'nsys' ? ' selected' : ''}>есть</option><option value="nsys"${c[1] === 'nsys' ? ' selected' : ''}>нет</option></select>`}<button class="x" data-bcdel="${i}" title="Убрать условие">${XSVG}</button></div>`; };
    return `<div class="blk224"><b>${B.i >= 0 ? 'Изменить блок' : 'Новый блок'}</b>
      <div class="row"><input data-be="n" placeholder="Название блока" value="${esc(B.n)}" style="flex:1"><select data-be="c">${['#d9d9d9'].concat(YCOL).map(c => `<option value="${c}"${c === B.c ? ' selected' : ''} style="background:${c}">${c === '#d9d9d9' ? 'серая рамка' : c}</option>`).join('')}</select><select data-be="size">${[['s', 'мелкие'], ['m', 'средние'], ['l', 'крупные']].map(([v, l]) => `<option value="${v}"${v === B.size ? ' selected' : ''}>${l} карточки</option>`).join('')}</select></div>
      ${bv226(B)}${B.f.map(row).join('')}
      <div class="row"><button class="go ghost" data-a="bcond224">+ условие</button><button class="go" data-a="bsave224">${B.i >= 0 ? 'Сохранить блок' : 'Добавить блок'}</button>${B.i >= 0 ? '<button class="go ghost" data-a="bnew224">Новый</button>' : ''}<small class="hint">Все условия — по желанию; без условий блок покажет всё по порядку.</small></div></div>`;
  }
  function bedRead224(R) {
    const B = FOPEN.bed = FOPEN.bed || { i: -1, n: '', c: '#d9d9d9', size: 'm', f: [] };
    for (const el of R.querySelectorAll('[data-be]')) B[el.dataset.be] = el.value;
    B.f = B.f.map((c, i) => { const k = (R.querySelector(`[data-bf="${i}:k"]`) || {}).value || '', op = (R.querySelector(`[data-bf="${i}:op"]`) || {}).value || '>=', v = (R.querySelector(`[data-bf="${i}:v"]`) || {}).value;
      if (k.startsWith('cat=')) return ['cat', 'has', k.slice(4)]; if (k.startsWith('sys=')) return ['sys', op === 'nsys' ? 'nsys' : 'sys', k.slice(4)]; return [k, op, v === '' || v == null ? '' : +v]; });
    return B;
  }
  function feedClick221(e, host) {
    const R = host.shadowRoot, F = FEED, t = e.target.closest('button'); if (!t) return; e.stopPropagation(); const s = t.closest('.seg[data-k]');
    if (s) { const k = s.dataset.k, v = t.dataset.v; F[k] = /^\d+$/.test(v) ? +v : v; F.preset = ''; feedSave221(); feedPanel221(true); return; }
    const a = t.dataset.a;
    if (a === 'x') { host.remove(); return; }
    if (a === 'more') { FOPEN.more = !FOPEN.more; feedPanel221(true); return; }
    if (a === 'badd') { const k = R.querySelector('[data-a="bk"]').value; if (k.startsWith('cat=')) { const key = k.slice(4), n = R.querySelector('[data-a="bn"]').value.trim() || ycLabel(key); F.blocks = (F.blocks || []).concat([{ n, f: [['cat', 'has', key]] }]); feedSave221(); feedPanel221(true); return; } const n = R.querySelector('[data-a="bn"]').value.trim() || (FLD[k] || [''])[0]; F.blocks = (F.blocks || []).concat([{ n, f: [[k, R.querySelector('[data-a="bo"]').value, +R.querySelector('[data-a="bv"]').value]] }]); feedSave221(); feedPanel221(true); return; }
    if (a === 'p224main') { host.remove(); openPanel({}); return; }
    if (a === 'p224subs') { host.remove(); openSubs(); return; }
    if (t.dataset.sys224) { const v = t.dataset.sys224, L = F.sysOn || []; F.sysOn = L.includes(v) ? L.filter(x => x !== v) : L.concat(v); F.preset = ''; feedSave221(); feedPanel221(true); return; }
    if (t.dataset.syson224) { F.sysOn = (F.sysOn || []).filter(x => x !== t.dataset.syson224); feedSave221(); feedPanel221(true); return; }
    if (t.dataset.sysx224) { F.sysOff = (F.sysOff || []).filter(x => x !== t.dataset.sysx224); feedSave221(); feedPanel221(true); return; }
    if (t.dataset.bedit) { const b = F.blocks[+t.dataset.bedit]; FOPEN.more = true; FOPEN.bed = { i: +t.dataset.bedit, n: b.n, c: b.c || '#d9d9d9', size: b.size || 'm', view: b.view || 'scroll', rows: b.rows || 1, f: (b.f || []).map(x => x.slice()) }; feedPanel221(true); return; }
    if (a === 'bnew224') { FOPEN.bed = null; feedPanel221(true); return; }
    if (a === 'bcond224') { const B = bedRead224(R); B.f.push(['', '>=', '']); feedPanel221(true); return; }
    if (t.dataset.bcdel) { const B = bedRead224(R); B.f.splice(+t.dataset.bcdel, 1); feedPanel221(true); return; }
    if (a === 'bsave224') { const B = bedRead224(R), f = B.f.filter(c => c[0] && (c[1] === 'has' || c[1] === 'sys' || c[1] === 'nsys' || c[2] !== '')); const blk = { n: (B.n || '').trim() || (f.length ? f.map(bfLabel224).join(' и ') : 'Блок'), c: B.c, size: B.size, view: B.view || 'scroll', rows: Math.max(1, Math.min(6, +B.rows || 1)), f }; F.blocks = (F.blocks || []).slice(); if (B.i >= 0 && F.blocks[B.i]) F.blocks[B.i] = blk; else F.blocks.push(blk); FOPEN.bed = null; feedSave221(); feedPanel221(true); return; }
    if (a === 'list') { host.remove(); listAll(); return; }
    if (a === 'src') { host.remove(); srcAdd(); return; }
    if (a === 'cpage') { host.remove(); const ch = chHere(), pl = plHere(), id = vid(location.href); if (pl) ycPanel({ kind: 'pl', id: pl, n: document.title.replace(/ - YouTube$/, '') }); else if (ch) ycPanel({ kind: 'ch', id: ch, n: document.title.replace(/ - YouTube$/, '') }); else if (id) { const b = document.querySelector('.holst-ytc'); if (b) b.click(); } return; }
    if (a === 'cmanage') { host.remove(); ycPanel({ kind: 'none', id: '', n: 'настройка свойств' }); return; }
    if (t.dataset.bdel) { F.blocks.splice(+t.dataset.bdel, 1); feedSave221(); feedPanel221(true); return; }
    if (t.dataset.unb) { bg('yt-block', { ch: t.dataset.unb, off: 1 }).then(() => sysLoad()).then(() => { applyFeed221(true); feedPanel221(true); }); return; }
    if (a === 'psave') { const n = (prompt('Название пресета ленты', 'Мой пресет') || '').trim().slice(0, 40); if (!n) return; FEEDP = FEEDP.filter(p => p.n !== n).concat([{ n, s: Object.assign({}, F, { preset: '' }) }]); F.preset = n; chrome.storage.local.set({ feedp221: FEEDP }); feedSave221(); feedPanel221(true); }
  }
  function feedChange221(e) {
    const t = e.target, F = FEED; e.stopPropagation();
    if (t.dataset.a === 'preset') { const p = FP0.concat(FEEDP).find(x => x.n === t.value); FEED = Object.assign(feedDef221(), p ? p.s : {}, { preset: t.value }); feedSave221(); feedPanel221(true); return; }
    if (t.dataset.a === 'pdel' && t.value !== '') { FEEDP.splice(+t.value, 1); chrome.storage.local.set({ feedp221: FEEDP }); feedPanel221(true); return; }
    if (t.dataset.a === 'sysadd224' && t.value) { F.sysOn = [...new Set((F.sysOn || []).concat(t.value))]; feedSave221(); feedPanel221(true); return; }
    if (t.dataset.a === 'sysoff224' && t.value) { F.sysOff = [...new Set((F.sysOff || []).concat(t.value))]; feedSave221(); feedPanel221(true); return; }
    if (t.dataset.be || t.dataset.bf) { if (t.dataset.bf && t.dataset.bf.endsWith(':k')) { const R2 = t.getRootNode(); bedRead224(R2); feedPanel221(true); } return; }
    if (t.dataset.k === 'perCh224') { F.perCh224 = +t.value || 0; F.preset = ''; feedSave221(); return; }
    if (t.dataset.a === 'ycf') { F.cat = t.value.startsWith('+') ? t.value.slice(1) : ''; F.catNo = t.value.startsWith('-') ? t.value.slice(1) : ''; F.preset = ''; feedSave221(); return; }
    const k = t.dataset.k; if (!k) return; F[k] = t.type === 'number' || k === 'seenMin' ? (+t.value || 0) : t.value; F.preset = ''; feedSave221();
  }
  document.addEventListener('click', e => { const h = document.getElementById('holst-feed'); if (h && !e.composedPath().includes(h) && !(e.target.closest && e.target.closest('#holst-yt-mast'))) h.remove(); }, true);
  /* hiding a channel: forever, a week, a month */
  function hideMenu221(c, btn) {
    const ch = chKey(c), v = cardVideo(c); if (!ch) { hToast('Канал не распознан'); return; }
    let m = document.getElementById('holst-hide-m'); if (m) m.remove(); m = document.createElement('div'); m.id = 'holst-hide-m'; const r = btn.getBoundingClientRect();
    m.style.cssText = `position:fixed;left:${Math.min(innerWidth - 230, r.left)}px;top:${r.bottom + 4}px;z-index:2147483647;background:#fff;color:#0f0f0f;border-radius:10px;box-shadow:0 12px 32px -8px rgba(0,0,0,.4);padding:6px;display:flex;flex-direction:column;min-width:220px;font:13px Roboto,Arial,sans-serif`;
    m.innerHTML = `<div style="padding:4px 8px;color:#606060;font-size:12px">Скрыть «${esc((v && v.channel) || 'канал')}» в ленте</div>` + [[0, 'Навсегда'], [7, 'На неделю'], [30, 'На месяц'], [90, 'На три месяца']].map(([d, l]) => `<button data-d="${d}" style="border:0;background:none;text-align:left;padding:7px 8px;border-radius:6px;cursor:pointer;font:inherit;color:inherit">${l}</button>`).join('');
    m.addEventListener('click', async e => { const b = e.target.closest('[data-d]'); if (!b) return; e.stopPropagation(); const d = +b.dataset.d, l = b.textContent; m.remove(); await bg('yt-block', { ch, n: (v && v.channel) || ch, until: d ? Date.now() + d * 864e5 : 0, url: 'https://www.' + ch }); await sysLoad(); applyFeed221(true); hToast(d ? 'Канал скрыт ' + l.toLowerCase() : 'Канал скрыт навсегда — вернуть: настройки ленты рядом с поиском'); }, true);
    document.documentElement.appendChild(m); setTimeout(() => document.addEventListener('click', function off(ev) { if (!m.contains(ev.target)) { m.remove(); document.removeEventListener('click', off, true); } }, true), 0);
  }
  /* a channel or a playlist into sources — with the plan of the analysis in Холст */
  const chHere = () => { const m = location.pathname.match(/^\/(@[^/]+|channel\/[^/]+|c\/[^/]+|user\/[^/]+)/); return m ? ('youtube.com/' + m[1]).toLowerCase() : ''; };
  const plHere = () => (/^\/playlist/.test(location.pathname) && (location.search.match(/[?&]list=([\w-]+)/) || [])[1]) || '';
  async function srcAdd() { const ch = chHere(), url = ch ? location.origin + location.pathname.match(/^\/(@[^/]+|channel\/[^/]+|c\/[^/]+|user\/[^/]+)/)[0] : location.href; const r = await bg('kb-add', { url }); hToast(r && r.ok ? 'План разбора — в Холсте' : 'Холст не ответил'); }
  /* the channel page: two quiet buttons next to «Подписаться» — categories and sources */
  function srcButton() {
    const old = document.getElementById('holst-yt-src'); if (old) old.remove();
    const ch = chHere(); let w = document.getElementById('holst-yt-chb');
    if (!ch) { if (w) w.remove(); return; }
    const anchor = document.querySelector('ytd-page-header-renderer yt-flexible-actions-view-model, #page-header yt-flexible-actions-view-model, ytd-c4-tabbed-header-renderer #buttons, #channel-header #buttons, ytd-page-header-renderer #subscribe-button, #inner-header-container #buttons');
    if (w && w.dataset.ch === ch && w.isConnected && (!anchor || anchor.contains(w) || w.parentElement === anchor.parentElement)) return; if (w) w.remove();
    w = document.createElement('span'); w.id = 'holst-yt-chb'; w.dataset.ch = ch; w.style.cssText = 'display:inline-flex;gap:8px;align-items:center;margin-left:8px;vertical-align:middle';
    const btn = (t, tip) => `<button title="${tip}" style="height:36px;border:0;border-radius:18px;padding:0 14px;background:var(--yt-spec-badge-chip-background,#0000000d);color:var(--yt-spec-text-primary,#0f0f0f);font:500 14px Roboto,Arial,sans-serif;cursor:pointer;display:inline-flex;align-items:center;gap:6px">${t}</button>`;
    w.innerHTML = btn(TAGSVG + 'Категории', 'Категории Холста для всего канала') + btn('В источники', 'Канал — в источники Холста: план разбора до запуска нейросети');
    w.children[0].addEventListener('click', e => { e.stopPropagation(); const n = (document.querySelector('ytd-page-header-renderer h1, #channel-name #text, yt-dynamic-text-view-model h1') || {}).textContent || ch; ycPanel({ kind: 'ch', id: ch, n: n.trim() }, w.children[0]); });
    w.children[1].addEventListener('click', e => { e.stopPropagation(); srcAdd(); });
    if (anchor) anchor.appendChild(w); else { w.style.cssText += ';position:fixed;right:16px;top:64px;z-index:2147483645'; document.documentElement.appendChild(w); }
  }
  /* ---------- v2.22: your own categories of channels, videos and playlists — they live in the extension ---------- */
  const TAGSVG = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 12.2V4.5a1 1 0 0 1 1-1h7.7l8.3 8.3a1.5 1.5 0 0 1 0 2.1l-6.1 6.1a1.5 1.5 0 0 1-2.1 0z"/><circle cx="8" cy="8" r="1.5"/></svg>';
  const YCOL = ['#ffd84d', '#7b61ff', '#2fa36b', '#3355ff', '#e5484d', '#f76b15', '#0b8fa8', '#d6409f', '#8a90a0'];
  let YC = { props: [], v: {}, ch: {}, pl: {} }; let YCL225 = 0;
  const ycFix = x => Object.assign({ props: [], v: {}, ch: {}, pl: {} }, x || {});
  chrome.storage.local.get('ycat222').then(r => { YC = ycFix(r.ycat222); YCL225 = 1; marks(true); applyFeed221(true); }).catch(() => {});
  chrome.storage.onChanged.addListener((c, area) => { if (!alive()) return; if (area === 'local' && c.ycat222) { YC = ycFix(c.ycat222.newValue); marks(true); applyFeed221(true); } });
  const ycSave = () => chrome.storage.local.set({ ycat222: YC });
  const ycId = () => Math.random().toString(36).slice(2, 8);
  const ycOf = (kind, id) => (YC[kind] && YC[kind][id]) || {};
  /* v2.23: channel id (UC…) ↔ @handle — the page tells us (ytmain.js, main world); imported folders know ids only */
  let YM = {}, ymT = 0;
  const ymKey = h => ('youtube.com' + new URL(h, 'https://www.youtube.com').pathname).toLowerCase().replace(/\/$/, '');
  const ycChKey = uc => YM[uc] || ('youtube.com/channel/' + uc).toLowerCase();
  const ycMerge = (to, from) => { for (const [pp, L] of Object.entries(from || {})) { const T = to[pp] = to[pp] || []; for (const o of L) if (!T.includes(o)) T.push(o); } return to; };
  function ymApply(pairs) {
    let ch = 0, moved = 0;
    for (const [uc, h] of pairs) { let k; try { k = ymKey(h); } catch (e) { continue; } if (YM[uc] !== k) { YM[uc] = k; ch++; } const ck = ('youtube.com/channel/' + uc).toLowerCase(); if (YC.ch && YC.ch[ck]) { YC.ch[k] = ycMerge(YC.ch[k] || {}, YC.ch[ck]); delete YC.ch[ck]; moved++; } }
    if (ch && !ymT) ymT = setTimeout(() => { ymT = 0; chrome.storage.local.set({ ycmap223: YM }).catch(() => {}); }, 1500);
    if (moved) { ycSave(); marks(true); applyFeed221(true); }
  }
  chrome.storage.local.get('ycmap223').then(r => { YM = r.ycmap223 || {}; }).catch(() => {});
  window.addEventListener('message', e => { if (e.source !== window || !e.data || !Array.isArray(e.data.__holstYtMap) || !alive()) return; ymApply(e.data.__holstYtMap); });
  /* v2.23: folders of PocketTube → the property «Папки» with an option per folder; channels keep their folders */
  function ycImportPT(J) {
    const names = Object.keys(J || {}).filter(k => !/^ysc_/.test(k) && Array.isArray(J[k])); if (!names.length) return null;
    try { chrome.storage.local.set({ pt224: { at: Date.now(), json: JSON.stringify(J) } }); } catch (e) { /* only a copy for Холст */ }
    const meta = J.ysc_meta || {}, pos = k => (meta[k] && meta[k].position != null ? +meta[k].position : 999);
    names.sort((a, b) => pos(a) - pos(b));
    let P = YC.props.find(p => p.src === 'pockettube') || YC.props.find(p => p.n === 'Папки');
    if (!P) { P = { id: ycId(), n: 'Папки', multi: 1, opts: [], src: 'pockettube' }; YC.props.unshift(P); }
    YC.ch = YC.ch || {}; let links = 0; const all = new Set();
    for (const name of names) {
      const label = String((J.ysc_collection && J.ysc_collection[name]) || name).slice(0, 40);
      let O = P.opts.find(o => o.n.toLowerCase() === label.toLowerCase());
      if (!O) { O = { id: ycId(), n: label, c: YCOL[P.opts.length % YCOL.length] }; P.opts.push(O); }
      for (const uc of J[name]) { if (!/^UC[\w-]{22}$/.test(uc)) continue; all.add(uc); const k = ycChKey(uc), m = YC.ch[k] = YC.ch[k] || {}, L = m[P.id] = m[P.id] || []; if (!L.includes(O.id)) { L.push(O.id); links++; } }
    }
    ycSave(); marks(true); applyFeed221(true); try { window.postMessage({ __holstYtMapAsk: 1 }, location.origin); } catch (e) {}
    return { folders: names.length, channels: all.size, links, known: [...all].filter(uc => YM[uc]).length };
  }
  window.__holstYcImport = ycImportPT;
  /* what a video carries: its own and its channel's (and the playlist's, on the playlist page) */
  function ycCats(vidId, chk) { const out = new Set(); for (const src of [ycOf('v', vidId), chk ? ycOf('ch', chk) : {}, plHere() ? ycOf('pl', plHere()) : {}]) for (const [pp, L] of Object.entries(src)) for (const o of L || []) out.add(pp + ':' + o); return out; }
  const ycOpt = key => { const [pp, o] = String(key).split(':'); const P = YC.props.find(x => x.id === pp); const O = P && P.opts.find(x => x.id === o); return P && O ? { P, O } : null; };
  const ycLabel = key => { const x = ycOpt(key); return x ? x.P.n + ': ' + x.O.n : key; };
  function ycPanel(T, anchor) {
    let w = T.kind === 'v' && T.ch && T.ch.key ? (T.w || 'v') : T.kind;
    const draw = () => {
      const kind = w === 'ch' && T.ch ? 'ch' : T.kind, id = kind === 'ch' && T.ch ? T.ch.key : T.id, cur = ycOf(kind, id), chCur = T.ch && T.ch.key ? ycOf('ch', T.ch.key) : {};
      const r = anchor && anchor.getBoundingClientRect ? anchor.getBoundingClientRect() : null;
      const p = panel(`<div class="h"><b>${TAGSVG} Категории Холста</b><button class="x" title="Закрыть">${XSVG}</button></div>
        <div class="st">${esc(T.kind === 'v' ? 'Видео «' + (T.n || '') + '»' : T.kind === 'ch' ? 'Канал «' + (T.n || '') + '»' : T.kind === 'pl' ? 'Плейлист «' + (T.n || '') + '»' : 'Свои свойства и опции — для каналов, видео и плейлистов')}</div>
        ${T.kind === 'v' && T.ch && T.ch.key ? `<div class="yw"><button data-yw="v" class="${w === 'v' ? 'on' : ''}">Это видео</button><button data-yw="ch" class="${w === 'ch' ? 'on' : ''}">Весь канал «${esc(T.ch.n || '')}»</button></div>` : ''}
        ${YC.props.length ? YC.props.map(P => `<div class="yp"><div class="yt">${esc(P.n)} <small>${P.multi ? 'несколько' : 'одно'}</small><button class="yx" data-ypd="${P.id}" title="Удалить свойство">${XSVG}</button></div><div class="yo">${P.opts.map(O => { const on = (cur[P.id] || []).includes(O.id), inh = !on && kind === 'v' && (chCur[P.id] || []).includes(O.id); return `<button data-yo="${P.id}:${O.id}" class="${on ? 'on' : ''}${inh ? ' inh' : ''}" style="--c:${O.c}" title="${inh ? 'Есть у всего канала' : ''}">${esc(O.n)}</button>`; }).join('')}<input data-yno="${P.id}" placeholder="+ опция" size="8"></div></div>`).join('') : '<div class="st">Своих свойств пока нет. Придумайте любое: тема, уровень, настроение, «для учеников», «на потом» — и опции выбора.</div>'}
        <div class="row ynew"><input data-ynp placeholder="Новое свойство, например «Тема»"><label class="ck"><input type="checkbox" data-ynm checked>несколько</label><button class="go" data-ynpb>+</button></div>
        <div class="row ypt"><button class="go ghost" data-ypt title="Файл экспорта PocketTube (youtube_subscription_manager….json): каждая папка станет опцией свойства «Папки», каналы — со своими папками">Папки из PocketTube</button><input type="file" accept=".json,application/json" data-yptf hidden></div>
        <div class="st">Категории живут в расширении. Лента умеет фильтровать, сортировать и собирать блоки по ним — кнопка Холста рядом с голосовым поиском.</div>`, r ? { left: Math.max(8, Math.min(innerWidth - 372, r.left)), top: Math.min(innerHeight - 260, r.bottom + 6) } : null);
      const st = p.getRootNode().querySelector('style'); if (st && !st.textContent.includes('.yo')) st.textContent += `.yw{display:flex;gap:4px}.yw button,.yo button{border:1px solid #d9d9d9;background:transparent;color:inherit;border-radius:999px;padding:3px 10px;font:500 12px Roboto,Arial,sans-serif;cursor:pointer}.yw button.on{background:#0f0f0f;color:#fff;border-color:#0f0f0f}.yp{display:flex;flex-direction:column;gap:5px;padding:6px 0;border-top:1px solid #e5e5e5}.yt{display:flex;align-items:center;gap:6px;font-weight:600}.yt small{color:#606060;font-weight:400}.yx{margin-left:auto;border:0;background:none;cursor:pointer;color:#909090;line-height:0;padding:2px}.yo{display:flex;flex-wrap:wrap;gap:4px;align-items:center}.yo button{border-color:var(--c)}.yo button.on{background:var(--c);color:#111;border-color:var(--c)}.yo button.inh{background:color-mix(in srgb,var(--c) 30%,transparent)}.yo input,.ynew input[data-ynp]{border:1px dashed #c9c9c9;border-radius:999px;padding:3px 9px;font:12px Roboto,Arial;background:transparent;color:inherit}.ynew input[data-ynp]{flex:1;border-radius:8px}.ynew .go{height:30px;width:36px;padding:0}@media (prefers-color-scheme:dark){.yw button,.yp{border-color:#3f3f3f}.yw button.on{background:#f1f1f1;color:#0f0f0f}}`;
      const R = p.getRootNode();
      R.querySelectorAll('[data-yw]').forEach(b => b.addEventListener('click', e => { e.stopPropagation(); w = b.dataset.yw; draw(); }));
      R.querySelectorAll('[data-yo]').forEach(b => b.addEventListener('click', e => { e.stopPropagation(); if (T.kind === 'none') return; const [pp, o] = b.dataset.yo.split(':'), P = YC.props.find(x => x.id === pp); if (!P) return; YC[kind] = YC[kind] || {}; const m = YC[kind][id] = YC[kind][id] || {}; const L = m[pp] || []; m[pp] = L.includes(o) ? L.filter(x => x !== o) : P.multi ? L.concat(o) : [o]; if (!m[pp].length) delete m[pp]; if (!Object.keys(m).length) delete YC[kind][id]; ycSave(); marks(true); applyFeed221(true); draw(); }));
      R.querySelectorAll('[data-yno]').forEach(inp => inp.addEventListener('keydown', e => { if (e.key !== 'Enter') return; e.stopPropagation(); const n = inp.value.trim().slice(0, 40); if (!n) return; const P = YC.props.find(x => x.id === inp.dataset.yno); if (!P) return; P.opts.push({ id: ycId(), n, c: YCOL[P.opts.length % YCOL.length] }); ycSave(); draw(); }));
      R.querySelectorAll('[data-ypd]').forEach(b => b.addEventListener('click', e => { e.stopPropagation(); const P = YC.props.find(x => x.id === b.dataset.ypd); if (!P || !confirm('Удалить свойство «' + P.n + '» и его метки у всех видео и каналов?')) return; YC.props = YC.props.filter(x => x !== P); for (const k of ['v', 'ch', 'pl']) for (const m of Object.values(YC[k] || {})) delete m[P.id]; ycSave(); draw(); }));
      const add = () => { const inp = R.querySelector('[data-ynp]'), n = inp.value.trim().slice(0, 40); if (!n) return; YC.props.push({ id: ycId(), n, multi: R.querySelector('[data-ynm]').checked ? 1 : 0, opts: [] }); ycSave(); draw(); setTimeout(() => { const L = p.getRootNode().querySelectorAll('[data-yno]'); if (L.length) L[L.length - 1].focus(); }, 30); };
      R.querySelector('[data-ynpb]').addEventListener('click', e => { e.stopPropagation(); add(); });
      { const f = R.querySelector('[data-yptf]'); R.querySelector('[data-ypt]').addEventListener('click', e => { e.stopPropagation(); f.click(); }); f.addEventListener('change', async () => { const file = f.files && f.files[0]; if (!file) return; let J; try { J = JSON.parse(await file.text()); } catch (e) { hToast('Это не файл PocketTube'); return; } const r = ycImportPT(J); if (!r) { hToast('В файле нет папок PocketTube'); return; } hToast('PocketTube: ' + r.folders + ' папок, ' + r.channels + ' каналов — в свойстве «Папки»'); draw(); }); }
      R.querySelector('[data-ynp]').addEventListener('keydown', e => { if (e.key === 'Enter') { e.stopPropagation(); add(); } });
    };
    draw();
  }
  /* the watch page: a button next to the button of Холст in the player */
  function catButton() {
    const bar = document.querySelector('.ytp-right-controls'); if (!bar || bar.querySelector('.holst-ytc') || !vid(location.href)) return;
    const b = document.createElement('button'); b.className = 'ytp-button holst-ytc'; b.title = 'Категории Холста: это видео или весь канал'; b.setAttribute('aria-label', b.title);
    b.innerHTML = `<span style="display:grid;place-items:center;width:100%;height:100%;color:#fff">${TAGSVG.replace('width="18" height="18"', 'width="22" height="22"')}</span>`; b.style.opacity = '.85';
    tap224(b, e => { const v = curVideo ? curVideo() : null, chA = document.querySelector('ytd-video-owner-renderer a[href^="/@"], ytd-video-owner-renderer a[href*="/channel/"]'), chk = chA ? ('youtube.com' + new URL(chA.getAttribute('href'), location.origin).pathname).toLowerCase().replace(/\/$/, '') : ''; ycPanel({ kind: 'v', id: vid(location.href), n: (v && v.title) || document.title.replace(/ - YouTube$/, ''), ch: chk ? { key: chk, n: (chA.textContent || '').trim() } : null }, b); });
    const h = bar.querySelector('.holst-ytp'); if (h) h.after(b); else bar.insertBefore(b, bar.firstChild);
  }
  /* the playlist page: categories of the whole playlist */
  function plButton() {
    const pl = plHere(); let b = document.getElementById('holst-yt-plc'); if (!pl) { if (b) b.remove(); return; } if (b && b.dataset.pl === pl && b.isConnected) return; if (b) b.remove();
    const anchor = document.querySelector('ytd-playlist-header-renderer .metadata-action-bar, ytd-playlist-header-renderer #top-level-buttons-computed, yt-page-header-view-model yt-flexible-actions-view-model'); if (!anchor) return;
    b = document.createElement('button'); b.id = 'holst-yt-plc'; b.dataset.pl = pl; b.title = 'Категории Холста для всего плейлиста'; b.innerHTML = TAGSVG + '<span>Категории</span>';
    b.style.cssText = 'height:36px;border:0;border-radius:18px;padding:0 14px;margin-left:8px;background:var(--yt-spec-badge-chip-background,#0000000d);color:var(--yt-spec-text-primary,#0f0f0f);font:500 14px Roboto,Arial,sans-serif;cursor:pointer;display:inline-flex;align-items:center;gap:6px';
    b.addEventListener('click', e => { e.stopPropagation(); ycPanel({ kind: 'pl', id: pl, n: (document.querySelector('ytd-playlist-header-renderer #title, yt-page-header-view-model h1') || {}).textContent || pl }, b); });
    anchor.appendChild(b);
  }
  /* ⋮ under a video: «Категории Холста» next to «В Холст» */
  function catMenuItem() {
    const dd = [...document.querySelectorAll('tp-yt-iron-dropdown, ytd-popup-container yt-sheet-view-model, yt-contextual-sheet-layout')].find(d => d.getClientRects().length && getComputedStyle(d).display !== 'none' && d.getAttribute('aria-hidden') !== 'true');
    if (!dd || !lastCard) return; const list = dd.querySelector('tp-yt-paper-listbox#items, #items, yt-list-view-model'); if (!list || list.querySelector('#holst-yt-mc')) return;
    const v = cardVideo(lastCard); if (!v) return; const chk = chKey(lastCard), card = lastCard;
    const it = document.createElement('div'); it.id = 'holst-yt-mc'; it.setAttribute('role', 'menuitem'); it.tabIndex = 0;
    it.style.cssText = 'display:flex;align-items:center;gap:14px;padding:0 16px;height:36px;cursor:pointer;font:400 14px Roboto,Arial,sans-serif;color:var(--yt-spec-text-primary,#0f0f0f)';
    it.innerHTML = `<span style="width:24px;height:24px;display:grid;place-items:center">${TAGSVG}</span><span>Категории Холста</span>`;
    it.addEventListener('mouseenter', () => { it.style.background = 'var(--yt-spec-10-percent-layer,#0000000d)'; }); it.addEventListener('mouseleave', () => { it.style.background = ''; });
    it.addEventListener('click', e => { e.stopPropagation(); document.body.click(); const th = card.querySelector('ytd-thumbnail, yt-thumbnail-view-model, a#thumbnail') || card; setTimeout(() => ycPanel({ kind: 'v', id: v.id, n: v.title, ch: chk ? { key: chk, n: v.channel } : null }, th), 60); });
    const mi = list.querySelector('#holst-yt-mi'); if (mi) mi.after(it); else list.insertBefore(it, list.firstChild);
  }
  /* =========================================================
     v2.25: the YouTube tool, the next step.
     · One place for all functions: tabs of the panel — level 1 «YouTube» / «Холст»,
       level 2 the entity: лента, эта страница (видео, канал, плейлист), свойства, ИИ, пресеты.
     · Categories became properties: levels (parent and child options), rules for groups
       (playlists, words in titles, channels), core properties of your own — importance and
       status without adding anything to Холст; numbers from YouTube — views, speed of views,
       subscribers, YouTube's own watched progress.
     · A quick strip of properties right on the pages of a video, a channel, a playlist; a tag
       on every playlist tile of a channel.
     · Global presets of the feed with everything; any parameter or preset onto the front
       layer next to the button by the search.
     · AI: smart categorisation of the feed — proposals apart from your marks, accepted one by
       one or all at once; a task in words for YouTube.
     · The feed tops itself up: while filters hide too much, it asks YouTube for more.
     ========================================================= */
  const CORE225 = [{ id: 'imp225', n: 'Важность', src: 'core225', multi: false, opts: Array.from({ length: 10 }, (_, i) => ({ id: 'i' + (i + 1), n: String(i + 1), c: i >= 7 ? '#e5484d' : i >= 4 ? '#ffd84d' : '#8a90a0' })) },
    { id: 'st225', n: 'Статус', src: 'core225', multi: false, opts: [['later', 'Посмотреть позже', '#3355ff'], ['now', 'Смотрю', '#f76b15'], ['done', 'Просмотрено', '#2fa36b'], ['re', 'Пересмотреть', '#7b61ff'], ['skip', 'Не интересно', '#8a90a0']].map(([id, n, c]) => ({ id, n, c })) }];
  let S225 = { ai: { base: 'https://api.openai.com/v1', key: '', model: 'gpt-4o-mini' }, pins: [], quick: { v: [], ch: [], pl: [] }, prop: {} };
  chrome.storage.local.get('s225').then(r => { if (r.s225) S225 = Object.assign(S225, r.s225); pins225(); }).catch(() => {});
  const s225Save = () => chrome.storage.local.set({ s225: S225 });
  function core225() { if (!YCL225) return; let ch = 0; for (const P of CORE225) if (!YC.props.some(x => x.id === P.id)) { YC.props.unshift(JSON.parse(JSON.stringify(P))); ch = 1; } YC.rules225 = YC.rules225 || []; YC.ai225 = YC.ai225 || {}; if (ch) ycSave(); }
  const num225 = t => { const m = String(t || '').replace(/ /g, ' ').match(/([\d.,]+)\s*(тыс|млн|млрд|k|m|b)?/i); if (!m) return null; let n = parseFloat(m[1].replace(/\s/g, '').replace(',', '.')); const u = (m[2] || '').toLowerCase(); if (/тыс|k/.test(u)) n *= 1e3; else if (/млн|m/.test(u)) n *= 1e6; else if (/млрд|b/.test(u)) n *= 1e9; return isFinite(n) ? Math.round(n) : null; };
  const fmt225 = n => (n == null ? '' : n >= 1e6 ? (n / 1e6).toFixed(n >= 1e7 ? 0 : 1).replace('.', ',') + ' млн' : n >= 1e3 ? Math.round(n / 1e3) + ' тыс.' : String(n));
  const parents225 = key => { const out = []; let x = ycOpt(key), n = 0; while (x && x.O.par && n++ < 6) { const k = x.P.id + ':' + x.O.par; out.push(k); x = ycOpt(k); } return out; };
  Object.assign(FLD, { views: ['Просмотров', 0, 1e10], vel: ['Просмотров в день', 0, 1e9], ytp: ['Досмотрено по YouTube, %', 0, 100], subs: ['Подписчиков канала', 0, 1e10] });
  { const o = sys224; sys224 = (c, X) => { o(c, X); try { extra225(c, X); } catch (e) { /* the base facts stay */ } }; }
  function extra225(c, X) {
    const lines = (c.innerText || '').split('\n').map(s => s.trim()).filter(Boolean);
    const isNum = s => /^\d{1,2}:\d{2}(:\d{2})?$/.test(s), isMeta = s => /просмотр|views|назад|ago|подписчик|subscriber|•/i.test(s);
    if (!X.v.title) { const t = (c.querySelector('h3 [title], a#video-title-link, a#video-title, h3 a') || {}); X.v.title = (t.getAttribute && t.getAttribute('title')) || (t.textContent || '').trim() || lines.find(s => s.length > 8 && !isNum(s) && !isMeta(s)) || ''; }
    if (!X.v.channel) { const a = c.querySelector('ytd-channel-name a, a[href^="/@"]:not([href*="/shorts"]), .yt-content-metadata-view-model a'); X.v.channel = a ? a.textContent.trim() : (lines[lines.indexOf(X.v.title) + 1] || ''); if (isMeta(X.v.channel)) X.v.channel = ''; }
    const ml = lines.find(s => /просмотр|views/i.test(s)) || ''; X.views = num225((ml.match(/([\d.,\s]+\s*(тыс|млн|млрд|k|m|b)?\.?)\s*(просмотр|views)/i) || [])[1]);
    X.vel = X.views != null && X.age != null ? Math.round(X.views / Math.max(1, X.age)) : null; X.meta = ml;
    const pr = c.querySelector('ytd-thumbnail-overlay-resume-playback-renderer #progress, .ytThumbnailOverlayProgressBarHostWatchedProgressBarSegment, [class*="ProgressBarSegment"]'); X.ytp = pr ? (parseFloat(pr.style.width) || 0) : 0; if (X.ytp) X.sys && X.sys.add('ytw:' + (X.ytp >= 90 ? 'all' : 'part'));
    const sl = lines.find(s => /подписчик|subscriber/i.test(s)); X.subs = sl ? num225(sl) : null;
    if (!X.cat) X.cat = new Set();
    const tl = String(X.v.title || '').toLowerCase(), href = (c.querySelector('a[href*="list="]') || {}).href || '', pl = (href.match(/[?&]list=([\w-]+)/) || [])[1] || plHere();
    for (const R of YC.rules225 || []) if ((R.kind === 'kw' && R.v && tl.includes(R.v.toLowerCase())) || (R.kind === 'pl' && R.v && R.v === pl) || (R.kind === 'ch' && R.v && R.v === chKey(c))) for (const k of R.cats || []) X.cat.add(k);
    if (pl) for (const [pp, L] of Object.entries(YC.pl && YC.pl[pl] || {})) for (const o of L || []) X.cat.add(pp + ':' + o);
    for (const k of [...X.cat]) parents225(k).forEach(p => X.cat.add(p));
    const im = [...X.cat].find(k => k.startsWith('imp225:')); if (im) X.imp = Math.max(X.imp || 0, +im.split(':i')[1] || 0);
    X.ai = (YC.ai225 || {})[X.id] || null;
  }
  /* ---------- AI ---------- */
  const AIP225 = [['OpenAI', 'https://api.openai.com/v1', 'gpt-4o-mini'], ['OpenRouter', 'https://openrouter.ai/api/v1', 'openai/gpt-4o-mini'], ['Groq', 'https://api.groq.com/openai/v1', 'llama-3.3-70b-versatile'], ['Gemini', 'https://generativelanguage.googleapis.com/v1beta/openai', 'gemini-2.0-flash'], ['DeepSeek', 'https://api.deepseek.com/v1', 'deepseek-chat']];
  async function ai225(sys, user) { if (!S225.ai.key) throw new Error('Нужен ключ нейросети: вкладка «ИИ»'); const r = await bg('ai225', { cfg: S225.ai, sys, user }); if (!r || !r.ok) throw new Error((r && (r.err || r.data)) || 'нейросеть не ответила'); return r.text || ''; }
  const json225 = t => { try { return JSON.parse(String(t).replace(/^[^{[]*/, '').replace(/[^}\]]*$/, '')); } catch (e) { return null; } };
  const visible225 = () => [...document.querySelectorAll('ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer, ytd-playlist-video-renderer')].filter(c => !c.closest('#holst-blocks') && !c.hasAttribute('data-holst-hide')).map(c => factsOf(c)).filter(Boolean).slice(0, 60);
  async function aiCat225(box) {
    core225(); const L = visible225(), props = YC.props.filter(P => P.src !== 'core225' || P.id === 'st225');
    if (!L.length) { box.textContent = 'В ленте не видно роликов.'; return; } if (!props.length) { box.textContent = 'Сначала сделайте свойства и опции во вкладке «Свойства».'; return; }
    box.textContent = 'Нейросеть раскладывает ' + L.length + ' роликов…';
    const sys = 'Ты раскладываешь ролики YouTube по свойствам человека. Используй ТОЛЬКО данные id свойств и опций. Ответ — только JSON: {"items":[{"id":"id видео","set":["propId:optId"],"why":"кратко"}]}. Ставь только уверенные варианты; если не подходит ничего — пропусти ролик.';
    const user = 'Свойства:\n' + props.map(P => `${P.id} «${P.n}»: ` + P.opts.map(O => `${O.id}=«${O.n}»`).join(', ')).join('\n') + '\n\nРолики:\n' + L.map(X => `${X.id} | ${X.v.title} | ${X.v.channel || ''}`).join('\n');
    const j = json225(await ai225(sys, user)) || {}; let n = 0;
    for (const it of j.items || []) { if (!it || !it.id || !Array.isArray(it.set)) continue; const ok = it.set.filter(k => ycOpt(k)); if (!ok.length) continue; YC.ai225[it.id] = { set: ok, why: String(it.why || '').slice(0, 140), t: (L.find(x => x.id === it.id) || { v: {} }).v.title || '' }; n++; }
    ycSave(); box.textContent = n ? `Предложений: ${n} — ниже, до согласования отдельно от ваших отметок.` : 'Нейросеть ничего уверенно не предложила.';
  }
  function aiAccept225(id) { const P = YC.ai225[id]; if (!P) return; YC.v[id] = YC.v[id] || {}; for (const k of P.set) { const [pp, o] = k.split(':'), x = ycOpt(k), cur = YC.v[id][pp] || []; YC.v[id][pp] = x && x.P.multi === false ? [o] : [...new Set(cur.concat(o))]; } delete YC.ai225[id]; }
  async function aiTask225(text, box) {
    core225(); box.textContent = 'Думаю, как это сделать…';
    const sys = 'Ты помощник в ленте YouTube внутри расширения Холст. Переведи задачу человека в действия. Ответ — только JSON: {"say":"что сделаешь, 1 фраза","feed":{"mute":"слова через запятую или пусто","sysOn":["kind:video|kind:shorts|kind:live|len:s|len:m|len:l|len:xl|age:d|age:3|age:w|age:m|sub:1|sub:0"],"sysOff":[],"age224":0,"by":"|new|old|views|vel|wt|imp","shorts":1},"blocks":[{"n":"название","f":[["sys","sys","kind:video"]]}],"mark":[{"word":"слово в названии","set":["propId:optId"]}]}. Поля, которые не нужны, не пиши. Свойства человека:\n' + YC.props.map(P => `${P.id} «${P.n}»: ` + P.opts.map(O => `${O.id}=«${O.n}»`).join(', ')).join('\n');
    const j = json225(await ai225(sys, text)); if (!j) { box.textContent = 'Не понял задачу — переформулируйте.'; return; }
    FOPEN.plan225 = j; box.innerHTML = `<b>План:</b> ${esc(j.say || '')}<br><small>${esc(JSON.stringify({ feed: j.feed, blocks: (j.blocks || []).map(b => b.n), mark: (j.mark || []).map(m => m.word) }))}</small><br><button class="go" data-a="plan225">Выполнить</button>`;
  }
  function planRun225() {
    const j = FOPEN.plan225, F = FEED; if (!j) return;
    if (j.feed) for (const [k, v] of Object.entries(j.feed)) if (['mute', 'sysOn', 'sysOff', 'age224', 'by', 'shorts', 'seen', 'only'].includes(k)) F[k] = v;
    if (Array.isArray(j.blocks)) F.blocks = (F.blocks || []).concat(j.blocks.filter(b => b && b.n).map(b => ({ n: String(b.n).slice(0, 40), f: Array.isArray(b.f) ? b.f : [], c: '#7b61ff', size: 'm' })));
    for (const m of j.mark || []) if (m && m.word && Array.isArray(m.set)) YC.rules225.push({ id: 'r' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), kind: 'kw', v: String(m.word), cats: m.set.filter(k => ycOpt(k)) });
    FOPEN.plan225 = null; ycSave(); feedSave221();
  }
  /* ---------- the front layer: pinned parameters and presets ---------- */
  const SEGS225 = { shorts: ['Шортсы', [[1, 'да'], [0, 'нет']]], seen: ['Досмотренное', [['show', 'видно'], ['dim', 'тускло'], ['hide', 'скрыто']]], age224: ['Новизна', [[0, 'всё'], [1, 'сегодня'], [3, '3 дня'], [7, 'неделя'], [30, 'месяц'], [-30, 'старое']]], per: ['В ряду', [[0, 'авто'], [3, '3'], [4, '4'], [5, '5'], [6, '6']]], by: ['Сортировка', [['', 'YouTube'], ['new', 'новые'], ['views', 'просмотры'], ['vel', 'скорость'], ['wt', 'вес'], ['imp', 'важность']]], only: ['Показывать', [['', 'всё'], ['in', 'из Холста'], ['new', 'новое']]], dedupe: ['Без дублей', [[1, 'да'], [0, 'нет']]] };
  function pins225() {
    if (!isFeed() && !document.getElementById('holst-yt-mast')) return; const m = document.getElementById('holst-yt-mast'); let bar = document.getElementById('holst-pins225');
    if (!m || !S225.pins.length) { if (bar) bar.remove(); return; }
    if (!bar) { bar = document.createElement('div'); bar.id = 'holst-pins225'; bar.style.cssText = 'display:inline-flex;gap:6px;align-items:center;margin-left:6px;flex:none;font:500 12px Roboto,Arial,sans-serif'; bar.addEventListener('click', pinClick225, true); }
    if (bar.previousElementSibling !== m) m.after(bar);
    const F = FEED || feedDef221(), chip = (on, a, l, t) => `<button data-p225="${esc(a)}"${on ? ' data-on="1"' : ''} title="${esc(t || l)}" style="height:30px;border-radius:15px;border:1px solid ${on ? '#e6bf2e' : '#ccc'};background:${on ? '#ffd84d' : '#fff'};color:#0f0f0f;padding:0 10px;cursor:pointer;white-space:nowrap;font:inherit">${esc(l)}</button>`;
    const h = S225.pins.map(p => { const [k, ...r] = p.split(':'), v = r.join(':');
      if (k === 'preset') return chip(F.preset === v, p, v, 'Пресет ленты: ' + v);
      if (k === 'seg' && SEGS225[v]) { const [n, L] = SEGS225[v], cur = L.find(x => String(x[0]) === String(F[v])) || L[0]; return chip(String(F[v] || '') !== String(L[0][0]), p, n + ': ' + cur[1], n + ' — щелчок: следующее значение'); }
      if (k === 'sys') return chip((F.sysOn || []).includes(v), p, sysLabel224(v));
      if (k === 'cat') return chip(F.cat === v, p, ycLabel(v), 'Только: ' + ycLabel(v));
      return ''; }).join('');
    if (bar.dataset.h !== h) { bar.dataset.h = h; bar.innerHTML = h; }
  }
  function pinClick225(e) {
    const b = e.target.closest('[data-p225]'); if (!b) return; e.stopPropagation(); e.preventDefault(); if (!FEED) FEED = feedDef221(); const F = FEED, [k, ...r] = b.dataset.p225.split(':'), v = r.join(':');
    if (k === 'preset') { const p = FP0.concat(FEEDP).find(x => x.n === v); FEED = Object.assign(feedDef221(), p ? p.s : {}, { preset: v }); }
    else if (k === 'seg') { const L = SEGS225[v][1], i = L.findIndex(x => String(x[0]) === String(F[v])); F[v] = L[(i + 1) % L.length][0]; F.preset = ''; }
    else if (k === 'sys') { const L = F.sysOn || []; F.sysOn = L.includes(v) ? L.filter(x => x !== v) : L.concat(v); F.preset = ''; }
    else if (k === 'cat') { F.cat = F.cat === v ? '' : v; F.catNo = ''; F.preset = ''; }
    feedSave221(); pins225(); FILL225.n = 0;
  }
  /* ---------- the feed tops itself up ---------- */
  const FILL225 = { n: 0, t: 0, sig: '' };
  function fill225() {
    if (!FEED || !feedPage226() || FEED.off226 || FEED.fill225 === 0 || Date.now() - FILL225.t < 600) return; const sig = JSON.stringify([FEED.sysOn, FEED.sysOff, FEED.age224, FEED.cat, FEED.catNo, FEED.seen, FEED.only, FEED.mute, FEED.durMin, FEED.durMax, location.pathname]); if (sig !== FILL225.sig) { FILL225.sig = sig; FILL225.n = 0; }
    const all = [...document.querySelectorAll('ytd-rich-item-renderer, ytd-video-renderer')].filter(c => !c.closest('#holst-blocks')), vis = all.filter(c => !c.hasAttribute('data-holst-hide')).length, hid = all.length - vis;
    if (!hid || vis >= (+FEED.fill225 || 24) || FILL225.n >= 30) return; const cont = document.querySelector('ytd-continuation-item-renderer, ytd-rich-grid-renderer #contents > ytd-continuation-item-renderer'); if (!cont) return;
    FILL225.t = Date.now(); FILL225.n++; if (FILL225.n % 3) { const old = cont.getAttribute('style') || ''; cont.style.cssText = 'position:fixed!important;left:0;top:0;width:40px;height:40px;opacity:0;pointer-events:none;z-index:-1'; setTimeout(() => { cont.setAttribute('style', old); }, 420); } else { const y = scrollY; cont.scrollIntoView({ block: 'end' }); requestAnimationFrame(() => setTimeout(() => window.scrollTo(0, y), 40)); }
  }
  /* ---------- a quick strip of properties on the page; a tag on playlist tiles ---------- */
  function ent225() { const v = vid(location.href); if (/\/watch/.test(location.pathname) && v) return { kind: 'v', id: v, n: document.title.replace(/ - YouTube$/, '') }; if (plHere()) return { kind: 'pl', id: plHere(), n: document.title.replace(/ - YouTube$/, '') }; if (chHere()) return { kind: 'ch', id: chHere(), n: document.title.replace(/ - YouTube$/, '') }; return null; }
  function quickProps225(kind) { core225(); const L = S225.quick[kind] || []; return (L.length ? L.map(id => YC.props.find(P => P.id === id)).filter(Boolean) : YC.props.slice(0, 4)); }
  function quickHTML225(E) {
    const cur = ycOf(E.kind, E.id);
    return quickProps225(E.kind).map(P => `<span style="display:inline-flex;align-items:center;gap:4px;flex-wrap:wrap"><b style="font-size:11.5px;color:#606060;margin-right:2px">${esc(P.n)}</b>${P.opts.map(O => { const on = (cur[P.id] || []).includes(O.id); return `<button data-q225="${esc(P.id + ':' + O.id)}"${on ? ' data-on="1"' : ''} style="height:24px;border-radius:12px;border:1px solid ${on ? (O.c || '#e6bf2e') : '#d0d0d0'};background:${on ? (O.c || '#ffd84d') + '33' : '#fff'};color:#0f0f0f;padding:0 8px;cursor:pointer;font:500 11.5px Roboto,Arial">${O.par ? '↳ ' : ''}${esc(O.n)}</button>`; }).join('')}</span>`).join('<span style="width:10px"></span>');
  }
  function quickToggle225(E, key) { const [pp, o] = key.split(':'), x = ycOpt(key); if (!x) return; const map = YC[E.kind] = YC[E.kind] || {}, rec = map[E.id] = map[E.id] || {}, cur = rec[pp] || []; rec[pp] = cur.includes(o) ? cur.filter(y => y !== o) : (x.P.multi === false ? [o] : cur.concat(o)); ycSave(); }
  function quick225() {
    const E = ent225(); let el = document.getElementById('holst-quick225'); if (!E || S225.qoff) { if (el) el.remove(); return; }
    const anchor = E.kind === 'v' ? document.querySelector('ytd-watch-metadata #title, #above-the-fold #title') : document.querySelector('yt-page-header-view-model, #page-header, ytd-playlist-header-renderer, #channel-header-container');
    if (!anchor) return;
    if (!el) { el = document.createElement('div'); el.id = 'holst-quick225'; el.style.cssText = 'display:flex;flex-wrap:wrap;gap:6px 8px;align-items:center;margin:8px 0;padding:6px 8px;border:1px solid #e3e3e3;border-radius:12px;background:#fafafa;font:13px Roboto,Arial,sans-serif;color:#0f0f0f'; el.addEventListener('click', ev => { const b = ev.target.closest('[data-q225]'); if (b) { ev.stopPropagation(); quickToggle225(ent225(), b.dataset.q225); el.dataset.h = ''; quick225(); } else if (ev.target.closest('[data-q225set]')) { ev.stopPropagation(); FOPEN.tab225 = 'props'; feedPanel221(true); } }); }
    if (E.kind === 'v' ? anchor.nextElementSibling !== el : el.parentElement !== anchor.parentElement) anchor.after(el);
    const h = `<b style="font-size:12px">Холст</b>${quickHTML225(E)}<button data-q225set="1" title="Какие свойства здесь — в панели «Свойства»" style="border:0;background:none;color:#065fd4;cursor:pointer;font:500 12px Roboto">настроить</button>`;
    if (el.dataset.h !== h) { el.dataset.h = h; el.innerHTML = h; }
  }
  function plTiles225() {
    if (!chHere()) return;
    for (const t of document.querySelectorAll('ytd-grid-playlist-renderer, yt-lockup-view-model, ytd-playlist-renderer')) {
      if (t.querySelector('.holst-plt225')) continue; const a = t.querySelector('a[href*="list="]'); if (!a) continue; const id = (a.href.match(/[?&]list=([\w-]+)/) || [])[1]; if (!id) continue;
      const b = document.createElement('button'); b.className = 'holst-plt225'; b.title = 'Свойства Холста для всего плейлиста'; b.innerHTML = TAGSVG; b.style.cssText = 'position:absolute;left:6px;top:6px;z-index:3;width:28px;height:28px;border-radius:50%;border:0;background:#000a;color:#fff;cursor:pointer;display:grid;place-items:center';
      tap224(b, () => ycPanel({ kind: 'pl', id, n: (t.querySelector('h3, #video-title, [title]') || {}).textContent || 'Плейлист' }, b)); t.style.position = t.style.position || 'relative'; t.appendChild(b);
    }
  }
  /* ---------- the panel: tabs by «YouTube / Холст» and by the entity ---------- */
  const TABS225 = [['yt', 'feed', 'Лента'], ['yt', 'ent', 'Эта страница'], ['yt', 'props', 'Свойства'], ['yt', 'ai', 'ИИ'], ['yt', 'presets', 'Пресеты и передний слой'], ['hl', 'holst', 'Холст']];
  { const o = feedPanel221; feedPanel221 = keep => {
    o(keep); const host = document.getElementById('holst-feed'); if (!host) return; const R = host.shadowRoot, p = R.querySelector('.p'); if (!p || p.querySelector('.tabs225')) return; core225();
    const t = FOPEN.tab225 || 'feed', lv = (TABS225.find(x => x[1] === t) || TABS225[0])[0];
    const bar = document.createElement('div'); bar.className = 'tabs225';
    bar.innerHTML = `<div class="seg" style="gap:6px"><button class="${lv === 'yt' ? 'on' : ''}" data-t225="feed">YouTube</button><button class="${lv === 'hl' ? 'on' : ''}" data-t225="holst">Холст</button></div>${lv === 'yt' ? `<div class="seg" style="margin-top:6px">${TABS225.filter(x => x[0] === 'yt').map(([, k, l]) => `<button class="${k === t ? 'on' : ''}" data-t225="${k}">${l}</button>`).join('')}</div>` : ''}`;
    p.querySelector('.h').after(bar);
    if (t === 'feed') return;
    for (const el of [...p.children]) if (!el.classList.contains('h') && !el.classList.contains('tabs225')) el.style.display = 'none';
    const box = document.createElement('div'); box.className = 'sec'; box.innerHTML = tab225(t); p.appendChild(box);
  }; }
  function tab225(t) {
    const F = FEED || feedDef221();
    if (t === 'ent') { const E = ent225(); if (!E) return '<h5>Эта страница</h5><p class="hint">Откройте видео, канал или плейлист — здесь появятся его свойства.</p>';
      const kn = { v: 'Видео', ch: 'Канал', pl: 'Плейлист' }[E.kind];
      return `<h5>${kn}: ${esc(E.n.slice(0, 70))}</h5><div class="row" style="gap:8px">${quickHTML225(E)}</div>
        <div class="row"><button class="go ghost" data-a="p224main">В Холст…</button>${E.kind !== 'v' ? '<button class="go ghost" data-a="src">В источники</button>' : ''}<button class="go ghost" data-a="cpage">Все свойства ${kn.toLowerCase()}а</button></div>
        <p class="hint">Важность и статус живут здесь, в YouTube: в Холст и в источники — отдельно, когда нужно.</p>`; }
    if (t === 'props') { const kinds = [['v', 'видео'], ['ch', 'канала'], ['pl', 'плейлиста']];
      return `<h5>Свойства</h5>${YC.props.map(P => `<div class="blk224"><div class="row"><b>${esc(P.n)}</b><small class="hint">${P.src === 'core225' ? 'основное' : P.src === 'pockettube' ? 'из PocketTube' : 'своё'} · ${P.multi === false ? 'одно значение' : 'несколько'}</small></div><div class="row">${P.opts.map(O => `<span class="chip224" style="border-color:${O.c || '#d0d0d0'}">${O.par ? '↳ ' : ''}${esc(O.n)}${P.src !== 'core225' ? `<select data-par225="${esc(P.id + ':' + O.id)}" title="Родитель — уровень выше" style="border:0;padding:0;font-size:11px;max-width:90px"><option value="">уровень 1</option>${P.opts.filter(x => x.id !== O.id).map(x => `<option value="${esc(x.id)}"${O.par === x.id ? ' selected' : ''}>внутри «${esc(x.n)}»</option>`).join('')}</select>` : ''}</span>`).join('')}<input data-addopt225="${esc(P.id)}" placeholder="+ опция" style="width:110px"></div></div>`).join('')}
        <div class="row"><input data-a="newprop225" placeholder="Новое свойство: название" style="flex:1"><button class="go ghost" data-a="addprop225">Создать</button><button class="go ghost" data-a="cmanage">Цвета и прочее</button></div>
        <h5>Быстрая полоса на страницах</h5>${kinds.map(([k, l]) => `<div class="row"><span>Для ${l}</span>${YC.props.map(P => `<label style="display:inline-flex;gap:3px;align-items:center;font-size:12px"><input type="checkbox" data-quick225="${k}:${esc(P.id)}"${(S225.quick[k] || []).includes(P.id) ? ' checked' : ''}>${esc(P.n)}</label>`).join(' ')}</div>`).join('')}<p class="hint">Ничего не отмечено — первые четыре свойства. Полоса стоит под названием видео, в шапке канала и плейлиста.</p>
        <h5>Правила для групп роликов</h5>${(YC.rules225 || []).map((R, i) => `<div class="row"><span>${R.kind === 'kw' ? 'в названии «' + esc(R.v) + '»' : R.kind === 'pl' ? 'плейлист ' + esc(R.v) : 'канал ' + esc(R.v)}</span><small>→ ${esc((R.cats || []).map(ycLabel).join(', '))}</small><button class="x" data-rdel225="${i}">${XSVG}</button></div>`).join('') || '<p class="hint">Например: всё со словом «гитара» в названии — «Тема: музыка»; весь плейлист — «Курс».</p>'}
        <div class="row"><select data-a="rk225"><option value="kw">слово в названии</option><option value="pl">плейлист (id из адреса)</option><option value="ch">канал (youtube.com/@…)</option></select><input data-a="rv225" placeholder="слово или id" value="${esc(plHere() || '')}"><select data-a="rc225">${YC.props.flatMap(P => P.opts.map(O => `<option value="${esc(P.id + ':' + O.id)}">${esc(P.n + ' — ' + O.n)}</option>`)).join('')}</select><button class="go ghost" data-a="radd225">Добавить правило</button></div>
        <h5>Системные свойства — из данных YouTube</h5><p class="hint">${Object.values(SYSN224).map(x => x[0]).join(', ')}, просмотры, просмотров в день, подписчики, досмотрено по YouTube — в фильтрах, сортировке и условиях блоков (вкладка «Лента» → «Ещё»).</p>`; }
    if (t === 'ai') { const P = Object.entries(YC.ai225 || {});
      return `<h5>Нейросеть</h5><div class="row"><span>Сервис</span><select data-a="aip225">${AIP225.map(([n, b, m]) => `<option value="${b}|${m}"${S225.ai.base === b ? ' selected' : ''}>${n}</option>`).join('')}</select><input data-ai225="model" value="${esc(S225.ai.model)}" style="width:170px" title="Модель"></div>
        <div class="row"><span>Ключ</span><input data-ai225="key" type="password" value="${esc(S225.ai.key)}" placeholder="ключ API — хранится только в расширении" style="flex:1"></div>
        <h5>Умная категоризация ленты</h5><div class="row"><button class="go" data-a="aicat225">Разложить видимые ролики по свойствам</button></div><div class="hint" id="aibox225"></div>
        ${P.length ? `<div class="row"><b>Предложения ИИ · ${P.length}</b><button class="go ghost" data-a="aiall225">Принять все</button><button class="go ghost" data-a="ainone225">Отклонить все</button></div>${P.map(([id, x]) => `<div class="blk224"><div class="row"><span><b>${esc((x.t || id).slice(0, 70))}</b></span><small>${esc(x.set.map(ycLabel).join(', '))}${x.why ? ' — ' + esc(x.why) : ''}</small><button class="go ghost" data-aiok225="${esc(id)}">Принять</button><button class="x" data-aino225="${esc(id)}">${XSVG}</button></div></div>`).join('')}` : ''}
        <h5>Задача для YouTube</h5><div class="row"><input data-a="task225" placeholder="например: скрой шортсы и крипту, сделай блок длинных видео про музыку, отметь гитарные ролики" style="flex:1"><button class="go" data-a="taskgo225">Спланировать</button></div><div class="hint" id="taskbox225"></div>`; }
    if (t === 'presets') { const pres = FP0.concat(FEEDP), pin = (k, l) => `<label style="display:inline-flex;gap:4px;align-items:center;font-size:12px"><input type="checkbox" data-pin225="${esc(k)}"${S225.pins.includes(k) ? ' checked' : ''}>${esc(l)}</label>`;
      return `<h5>Глобальные пресеты ленты</h5><p class="hint">Пресет хранит всё: фильтры, системные свойства, сортировку, блоки, новизну, ключевые слова.</p>${pres.map(p => `<div class="row"><span>${esc(p.n)}</span><button class="go ghost" data-pset225="${esc(p.n)}">Включить</button>${pin('preset:' + p.n, 'на передний слой')}</div>`).join('')}
        <div class="row"><input data-a="pname225" placeholder="Название нового пресета" style="flex:1"><button class="go" data-a="psave225">Сохранить текущее</button></div>
        <h5>Передний слой — рядом с кнопкой у поиска</h5><div class="row">${Object.entries(SEGS225).map(([k, [l]]) => pin('seg:' + k, l)).join(' ')}</div><div class="row">${Object.entries(SYSN224).filter(([g]) => ['kind', 'len', 'sub', 'age'].includes(g)).flatMap(([g, [, M]]) => Object.keys(M).map(k => pin('sys:' + g + ':' + k, sysLabel224(g + ':' + k)))).join(' ')}</div><div class="row">${YC.props.flatMap(P => P.opts.map(O => pin('cat:' + P.id + ':' + O.id, P.n + ': ' + O.n))).slice(0, 40).join(' ')}</div>`; }
    if (t === 'holst') return `<h5>Холст</h5><div class="row"><button class="go ghost" data-a="p224main">Панель «В Холст»: видео, задача, разбор</button>${isList() ? '<button class="go ghost" data-a="list">Видео этой страницы — в Холст</button>' : ''}${chHere() || plHere() ? '<button class="go ghost" data-a="src">В источники Холста</button>' : ''}<button class="go ghost" data-a="p224subs">Каналы подписок</button></div><p class="hint">Здесь — то, что уходит в Холст. Свойства и лента живут во вкладке «YouTube».</p>`;
    return '';
  }
  { const o = feedClick221; feedClick221 = async (e, host) => {
    const t = e.target.closest('button'), R = host.shadowRoot; if (!t) return o(e, host); const d = t.dataset, a = d.a;
    if (d.t225) { e.stopPropagation(); FOPEN.tab225 = d.t225; feedPanel221(true); return; }
    if (d.q225) { e.stopPropagation(); quickToggle225(ent225(), d.q225); feedPanel221(true); quick225(); return; }
    if (d.pset225) { e.stopPropagation(); const p = FP0.concat(FEEDP).find(x => x.n === d.pset225); FEED = Object.assign(feedDef221(), p ? p.s : {}, { preset: d.pset225 }); feedSave221(); feedPanel221(true); pins225(); return; }
    if (d.rdel225) { e.stopPropagation(); YC.rules225.splice(+d.rdel225, 1); ycSave(); feedPanel221(true); return; }
    if (d.aiok225) { e.stopPropagation(); aiAccept225(d.aiok225); ycSave(); applyFeed221(true); feedPanel221(true); return; }
    if (d.aino225) { e.stopPropagation(); delete YC.ai225[d.aino225]; ycSave(); feedPanel221(true); return; }
    if (a === 'aiall225' || a === 'ainone225') { e.stopPropagation(); for (const id of Object.keys(YC.ai225 || {})) { if (a === 'aiall225') aiAccept225(id); else delete YC.ai225[id]; } ycSave(); applyFeed221(true); feedPanel221(true); return; }
    if (a === 'aicat225') { e.stopPropagation(); const box = R.getElementById('aibox225'); try { await aiCat225(box); feedPanel221(true); } catch (er) { box.textContent = String(er.message || er); } return; }
    if (a === 'taskgo225') { e.stopPropagation(); const box = R.getElementById('taskbox225'), q = (R.querySelector('[data-a=task225]') || {}).value || ''; if (!q.trim()) return; try { await aiTask225(q, box); } catch (er) { box.textContent = String(er.message || er); } return; }
    if (a === 'plan225') { e.stopPropagation(); planRun225(); feedPanel221(true); return; }
    if (a === 'psave225') { e.stopPropagation(); const n = ((R.querySelector('[data-a=pname225]') || {}).value || '').trim().slice(0, 40); if (!n) return; FEEDP = FEEDP.filter(p => p.n !== n).concat([{ n, s: JSON.parse(JSON.stringify(Object.assign({}, FEED, { preset: '' }))) }]); FEED.preset = n; chrome.storage.local.set({ feedp221: FEEDP }); feedSave221(); feedPanel221(true); return; }
    if (a === 'addprop225') { e.stopPropagation(); const n = ((R.querySelector('[data-a=newprop225]') || {}).value || '').trim().slice(0, 40); if (!n) return; YC.props.push({ id: 'p' + Date.now().toString(36), n, opts: [], multi: true }); ycSave(); feedPanel221(true); return; }
    if (a === 'radd225') { e.stopPropagation(); const k = R.querySelector('[data-a=rk225]').value, v = R.querySelector('[data-a=rv225]').value.trim(), c = R.querySelector('[data-a=rc225]').value; if (!v || !c) return; YC.rules225.push({ id: 'r' + Date.now().toString(36), kind: k, v: k === 'ch' ? v.toLowerCase().replace(/^https?:\/\/(www\.)?/, '').replace(/\/$/, '') : v, cats: [c] }); ycSave(); applyFeed221(true); feedPanel221(true); return; }
    return o(e, host);
  }; }
  { const o = feedChange221; feedChange221 = e => {
    const t = e.target, d = t.dataset;
    if (d.par225) { e.stopPropagation(); const x = ycOpt(d.par225); if (x) { x.O.par = t.value || undefined; ycSave(); feedPanel221(true); } return; }
    if (d.addopt225 && t.value.trim()) { e.stopPropagation(); const P = YC.props.find(x => x.id === d.addopt225); if (P) { P.opts.push({ id: 'o' + Date.now().toString(36), n: t.value.trim().slice(0, 40), c: YCOL[P.opts.length % YCOL.length] }); ycSave(); feedPanel221(true); } return; }
    if (d.quick225) { e.stopPropagation(); const [k, id] = d.quick225.split(':'), L = S225.quick[k] || []; S225.quick[k] = t.checked ? L.concat(id) : L.filter(x => x !== id); s225Save(); quick225(); return; }
    if (d.pin225) { e.stopPropagation(); S225.pins = t.checked ? [...new Set(S225.pins.concat(d.pin225))] : S225.pins.filter(x => x !== d.pin225); s225Save(); pins225(); return; }
    if (d.ai225) { e.stopPropagation(); S225.ai[d.ai225] = t.value.trim(); s225Save(); return; }
    if (d.a === 'aip225') { e.stopPropagation(); const [b, m] = t.value.split('|'); S225.ai.base = b; S225.ai.model = m; s225Save(); feedPanel221(true); return; }
    if (['rk225', 'rv225', 'rc225', 'task225', 'pname225', 'newprop225'].includes(d.a)) { e.stopPropagation(); return; }
    return o(e);
  }; }
  /* =========================================================
     v2.26: one button per place, all that concerns a thing in it.
     · Feed pages (home, subscriptions): the button by the search — the settings of the feed
       only; they work only there; one switch turns all of them off.
     · A video: one panel — from the button in the player, the right click on a cover and
       «Холст» in ⋮; it holds the video, its channel and its playlists. A channel: its panel
       from the button on the channel page. A playlist: on its own page. The icon of the
       extension — the work with Холст.
     · «Просмотрено» by hand; «в моих плейлистах» as a property; shelves of YouTube
       («Ещё темы» and others) are entities with their own settings; blocks scroll sideways
       or stand in a grid, with any number of rows; properties of every source are merged
       into yours, same names become one; the feed fills up without jumps; the dark theme of
       Dark Reader.
     ========================================================= */
  let W226 = new Set(), PLV226 = {}, SHELF226 = new Set();
  chrome.storage.local.get(['w226', 'plv226']).then(r => { W226 = new Set(r.w226 || []); PLV226 = r.plv226 || {}; }).catch(() => {});
  const feedPage226 = () => /^\/$|^\/feed\/subscriptions/.test(location.pathname);
  Object.assign(SYSN224, { inpl: ['В моих плейлистах', { 1: 'да', 0: 'нет' }], pln: ['Плейлист', {}], mine: ['Отмечено', { watched: 'просмотрено мной' }] });
  const plOf226 = id => Object.values(PLV226).filter(p => (p.ids || []).includes(id)).map(p => p.n);
  { const o = sys224; sys224 = (c, X) => { o(c, X); try { if (W226.has(X.id)) { X.seen = 100; X.sys.add('mine:watched'); } const P = plOf226(X.id); X.sys.add('inpl:' + (P.length ? 1 : 0)); P.forEach(n => X.sys.add('pln:' + n.toLowerCase())); } catch (e) { /* facts stay */ } }; }
  function watched226(id, on) { const st = YC.v[id] = YC.v[id] || {}; if (on) { W226.add(id); if (!(st.st225 || []).length) st.st225 = ['done']; } else { W226.delete(id); if ((st.st225 || [])[0] === 'done') delete st.st225; } chrome.storage.local.set({ w226: [...W226] }); ycSave(); applyFeed221(true); }
  function plCollect226() {
    const pl = plHere(); if (!pl) return; const ids = [...document.querySelectorAll('ytd-playlist-video-renderer a#thumbnail[href], ytd-playlist-video-renderer a#video-title[href]')].map(a => vid(a.href)).filter(Boolean); if (!ids.length) return;
    const P = PLV226[pl] || { n: '', ids: [] }, n = (document.querySelector('ytd-playlist-header-renderer #title, yt-page-header-view-model h1, h1') || {}).textContent || document.title.replace(/ - YouTube$/, '');
    const all = [...new Set(P.ids.concat(ids))]; if (all.length === P.ids.length && P.n === n.trim()) return; PLV226[pl] = { n: n.trim().slice(0, 80) || pl, ids: all.slice(-5000) }; clearTimeout(plCollect226.t); plCollect226.t = setTimeout(() => chrome.storage.local.set({ plv226: PLV226 }), 1500);
  }
  /* the feed only on feed pages; one switch for everything */
  function clear226() {
    for (const c of document.querySelectorAll('[data-holst-hide],[data-holst-dim]')) if (!c.closest('#holst-blocks')) { c.removeAttribute('data-holst-hide'); c.removeAttribute('data-holst-dim'); }
    for (const c of document.querySelectorAll('ytd-rich-item-renderer, ytd-rich-section-renderer')) if (c.style.order) c.style.order = '';
    const bl = document.getElementById('holst-blocks'); if (bl) bl.remove(); const st = document.getElementById('holst-feed-css'); if (st) st.textContent = '[data-holst-hide]{display:none!important}';
    for (const x of document.querySelectorAll('ytd-rich-grid-renderer')) x.style.removeProperty('--ytd-rich-grid-items-per-row');
  }
  { const o = applyFeed221; applyFeed221 = force => { const fp = feedPage226(); document.documentElement.classList.toggle('holst-feedpage', fp); if (!FEED || !fp || FEED.off226) { clear226(); return; } o(force); try { shelves226(); } catch (e) { /* shelves */ } }; }
  /* shelves of YouTube — «Ещё темы» and the like — as entities */
  const shTitle226 = s => ((s.querySelector('#title-text, #title, h2, yt-formatted-string#title') || {}).textContent || '').trim().slice(0, 60);
  function shelves226() {
    const S = FEED.sh226 = FEED.sh226 || {};
    for (const s of document.querySelectorAll('ytd-rich-section-renderer, ytd-rich-shelf-renderer')) {
      const t = shTitle226(s); if (!t) continue; SHELF226.add(t); const c = S[t] || {}, sec = s.closest('ytd-rich-section-renderer') || s;
      if (c.mode === 'hide') sec.setAttribute('data-holst-hide', '1'); else sec.removeAttribute('data-holst-hide');
      sec.style.order = c.mode === 'bottom' ? '9999' : '';
      for (const card of sec.querySelectorAll('ytd-rich-item-renderer')) { if (c.free) { card.removeAttribute('data-holst-hide'); card.removeAttribute('data-holst-dim'); } if (c.only) { const X = factsOf(card); if (X && !(X.cat && X.cat.has(c.only))) card.setAttribute('data-holst-hide', '1'); } }
      sec.toggleAttribute('data-holst-col226', c.mode === 'collapse');
    }
  }
  function shelfHTML226() {
    const S = (FEED && FEED.sh226) || {}, L = [...new Set([...SHELF226, ...Object.keys(S)])];
    const opts = YC.props.flatMap(P => P.opts.map(O => [P.id + ':' + O.id, P.n + ' — ' + O.n]));
    return `<h5>Полки YouTube в ленте</h5><p class="hint">«Ещё темы», «Шортсы», «Новое для вас» и другие полки главной — отдельные сущности: показать, скрыть, опустить вниз, свернуть; свои фильтры внутри.</p>${L.length ? L.map(t => { const c = S[t] || {}; return `<div class="blk224"><div class="row"><b style="flex:1">${esc(t)}</b><select data-sh226="${esc(t)}|mode">${[['', 'как есть'], ['hide', 'скрыть'], ['bottom', 'вниз ленты'], ['collapse', 'свернуть']].map(([v, l]) => `<option value="${v}"${(c.mode || '') === v ? ' selected' : ''}>${l}</option>`).join('')}</select></div><div class="row"><label style="display:inline-flex;gap:4px;align-items:center"><input type="checkbox" data-sh226="${esc(t)}|free"${c.free ? ' checked' : ''}>без фильтров ленты внутри</label><select data-sh226="${esc(t)}|only"><option value="">все ролики полки</option>${opts.map(([k, l]) => `<option value="${esc(k)}"${c.only === k ? ' selected' : ''}>только ${esc(l)}</option>`).join('')}</select></div></div>`; }).join('') : '<p class="hint">Полок пока не видно — пролистайте главную.</p>'}`;
  }
  /* properties of every source into yours: same names become one */
  function merge226(target) {
    core225(); const T = YC.props.find(P => P.id === target); if (!T) return 0; const remap = {}; let n = 0;
    const into = (P, O) => { let to = T.opts.find(x => x.n.trim().toLowerCase() === O.n.trim().toLowerCase()); if (!to) { to = Object.assign({}, O); delete to.par; if (T.opts.some(x => x.id === to.id)) to.id = 'o' + Math.random().toString(36).slice(2, 8); T.opts.push(to); n++; } remap[P.id + ':' + O.id] = T.id + ':' + to.id; };
    for (const P of YC.props.slice()) { if (P === T || P.src === 'core225') continue; if (P.src || P.n.trim().toLowerCase() === T.n.trim().toLowerCase()) { P.opts.forEach(O => into(P, O)); YC.props = YC.props.filter(x => x !== P); } }
    const byName = {}; for (const P of YC.props.slice()) { if (P.src === 'core225') continue; const k = P.n.trim().toLowerCase(); if (byName[k] && byName[k] !== P) { const A = byName[k]; for (const O of P.opts) { let to = A.opts.find(x => x.n.trim().toLowerCase() === O.n.trim().toLowerCase()); if (!to) { to = Object.assign({}, O); A.opts.push(to); } remap[P.id + ':' + O.id] = A.id + ':' + to.id; } YC.props = YC.props.filter(x => x !== P); } else byName[k] = P; }
    const rm = rec => { const out = {}; for (const [pp, L] of Object.entries(rec || {})) for (const o of L || []) { const [np, no] = (remap[pp + ':' + o] || pp + ':' + o).split(':'); out[np] = [...new Set((out[np] || []).concat(no))]; } return out; };
    for (const k of ['v', 'ch', 'pl']) for (const id of Object.keys(YC[k] || {})) YC[k][id] = rm(YC[k][id]);
    (YC.rules225 || []).forEach(R => { R.cats = (R.cats || []).map(k => remap[k] || k); });
    for (const id of Object.keys(YC.ai225 || {})) YC.ai225[id].set = YC.ai225[id].set.map(k => remap[k] || k);
    if (FEED) { if (FEED.cat) FEED.cat = remap[FEED.cat] || FEED.cat; if (FEED.catNo) FEED.catNo = remap[FEED.catNo] || FEED.catNo; }
    ycSave(); return n;
  }
  { const o = ycImportPT; ycImportPT = J => { const r = o(J); try { if (S225.mt226) merge226(S225.mt226); } catch (e) { /* the import stays */ } return r; }; }
  /* the one panel of a video — its channel and playlists inside */
  const chips226 = (kind, id, props) => { const cur = ycOf(kind, id); return props.map(P => `<div class="row"><span>${esc(P.n)}</span><div class="seg">${P.opts.map(O => `<button class="${(cur[P.id] || []).includes(O.id) ? 'on' : ''}" data-c226="${kind}|${esc(id)}|${esc(P.id + ':' + O.id)}">${O.par ? '↳ ' : ''}${esc(O.n)}</button>`).join('')}</div></div>`).join(''); };
  let VP226 = null;
  function vp226(T, at) {
    core225(); VP226 = T; let host = document.getElementById('holst-vp226');
    if (!host) { host = document.createElement('div'); host.id = 'holst-vp226'; document.documentElement.appendChild(host); host.attachShadow({ mode: 'open' }); host.shadowRoot.addEventListener('click', vpClick226, true); }
    host.toggleAttribute('data-dark', dark226());
    const id = T.id, w = W226.has(id), core = YC.props.filter(P => P.src === 'core225'), own = YC.props.filter(P => P.src !== 'core225'), pls = plOf226(id), page = T.page;
    host.shadowRoot.innerHTML = `<style>${FSTY}.p.vp{width:min(470px,calc(100vw - 24px))!important;top:${Math.max(64, Math.min(innerHeight - 420, (at && at.y) || 80))}px!important}</style><div class="p vp">
      <div class="h"><b title="${esc(T.t || '')}">${esc((T.t || 'Видео').slice(0, 70))}</b><button class="x" data-a="x" title="Закрыть">${XSVG}</button></div>
      <div class="sec"><h5>Видео</h5><div class="row"><button class="${w ? 'go' : 'go ghost'}" data-a="w226">${w ? '✓ Просмотрено' : 'Отметить просмотренным'}</button><button class="go ghost" data-a="toh">В Холст…</button>${T.card && T.card.querySelector('.holst-add') ? '<button class="go ghost" data-a="add">В источники</button>' : ''}${page ? '<button class="go ghost" data-a="mom" title="Момент на таймлайне: заметка, задача, вопрос">Момент</button>' : ''}</div>${chips226('v', id, core)}${own.length ? chips226('v', id, own) : ''}<div class="row"><button class="more" data-a="vall">Все свойства видео, цвета, новые опции…</button></div></div>
      <div class="sec"><h5>Канал${T.chn ? ': ' + esc(T.chn) : ''}</h5>${T.ch ? chips226('ch', T.ch, YC.props) : '<p class="hint">Канал не определился.</p>'}<div class="row">${T.card && T.card.querySelector('.holst-hide') ? '<button class="go ghost" data-a="hide">Скрыть канал…</button>' : ''}${T.ch ? '<button class="more" data-a="chall">Все свойства канала</button>' : ''}</div></div>
      <div class="sec"><h5>Плейлисты</h5><p class="hint">${pls.length ? 'В ваших плейлистах: ' + pls.map(esc).join(', ') : 'Нет в плейлистах, которые вы открывали. Откройте свой плейлист — Холст его запомнит.'}</p></div></div>`;
  }
  async function vpClick226(e) {
    const b = e.target.closest('button'); if (!b) return; e.stopPropagation(); const T = VP226, host = document.getElementById('holst-vp226'), a = b.dataset.a; if (!T) return;
    if (a === 'x') { host.remove(); return; }
    if (b.dataset.c226) { const [k, id, key] = b.dataset.c226.split('|'); quickToggle225({ kind: k, id }, key); applyFeed221(true); vp226(T); return; }
    if (a === 'w226') { watched226(T.id, !W226.has(T.id)); vp226(T); return; }
    if (a === 'toh') { host.remove(); openPanel(T.page ? {} : { vid: T.id, vt: T.t, vch: T.chn || '' }); return; }
    if (a === 'mom') { host.remove(); const m = document.querySelector('.holst-mom'); if (m) m.click(); return; }
    if (a === 'add') { host.remove(); const x = T.card && T.card.querySelector('.holst-add'); if (x) x.click(); return; }
    if (a === 'vall') { host.remove(); ycPanel({ kind: 'v', id: T.id, n: T.t || 'Видео' }); return; }
    if (a === 'chall') { host.remove(); ycPanel({ kind: 'ch', id: T.ch, n: T.chn || 'Канал' }); return; }
    if (a === 'hide') { host.remove(); const h = T.card && T.card.querySelector('.holst-hide'); if (h) hideMenu221(T.card, h); return; }
  }
  function vpFromCard226(c, at) { const X = factsOf(c); if (!X) return; vp226({ id: X.id, t: X.v.title, ch: chKey(c), chn: X.v.channel, card: c }, at); }
  function vpFromPage226() { const id = vid(location.href); if (!id) return; const a = document.querySelector('ytd-video-owner-renderer a[href^="/@"], ytd-video-owner-renderer a[href*="/channel/"], #owner a[href^="/@"]'); vp226({ id, t: document.title.replace(/ - YouTube$/, '').replace(/^\(\d+\)\s*/, ''), ch: a ? ('youtube.com' + new URL(a.getAttribute('href'), location.origin).pathname).toLowerCase().replace(/\/$/, '') : '', chn: a ? a.textContent.trim() : '', page: true }); }
  /* the channel page: one panel */
  function cp226() {
    const ch = chHere(); if (!ch) return; core225(); let host = document.getElementById('holst-vp226');
    if (!host) { host = document.createElement('div'); host.id = 'holst-vp226'; document.documentElement.appendChild(host); host.attachShadow({ mode: 'open' }); host.shadowRoot.addEventListener('click', vpClick226, true); }
    host.toggleAttribute('data-dark', dark226()); VP226 = { id: '', ch, chn: document.title.replace(/ - YouTube$/, '') };
    host.shadowRoot.innerHTML = `<style>${FSTY}.p.vp{width:min(470px,calc(100vw - 24px))!important;top:80px!important}</style><div class="p vp"><div class="h"><b>Канал: ${esc(VP226.chn.slice(0, 60))}</b><button class="x" data-a="x">${XSVG}</button></div>
      <div class="sec"><h5>Свойства канала</h5>${chips226('ch', ch, YC.props)}<div class="row"><button class="more" data-a="chall">Все свойства канала, цвета, новые опции…</button></div></div>
      <div class="sec"><h5>Холст</h5><div class="row"><button class="go ghost" data-a="csrc">Канал — в источники</button>${isList() ? '<button class="go ghost" data-a="clist">Видео этой страницы — в Холст</button>' : ''}</div></div></div>`;
    host.shadowRoot.querySelector('.p').addEventListener('click', ev => { const b = ev.target.closest('[data-a="csrc"],[data-a="clist"]'); if (!b) return; ev.stopPropagation(); host.remove(); if (b.dataset.a === 'csrc') srcAdd(); else listAll(); }, true);
  }
  /* the entry points: one per place */
  document.addEventListener('click', e => {
    const t = e.target; if (!t || !t.closest) return;
    if (t.closest('.holst-ytp')) { e.stopImmediatePropagation(); e.preventDefault(); vpFromPage226(); return; }
    if (t.closest('#holst-yt-mi')) { e.stopImmediatePropagation(); e.preventDefault(); const c = lastCard; document.body.click(); if (c) setTimeout(() => vpFromCard226(c, { y: 120 }), 60); return; }
    if (t.closest('#holst-yt-chb')) { e.stopImmediatePropagation(); e.preventDefault(); cp226(); return; }
    const h = document.getElementById('holst-vp226'); if (h && !e.composedPath().includes(h)) h.remove();
  }, true);
  ['pointerup', 'pointerdown', 'mousedown'].forEach(k => document.addEventListener(k, e => { if (e.target && e.target.closest && e.target.closest('.holst-ytp,#holst-yt-chb')) { e.stopImmediatePropagation(); if (k === 'pointerup') { e.preventDefault(); if (e.target.closest('.holst-ytp')) vpFromPage226(); else cp226(); } } }, true));
  document.addEventListener('contextmenu', e => { if (e.shiftKey) return; const th = e.target.closest && e.target.closest('a#thumbnail, ytd-thumbnail, yt-thumbnail-view-model, .yt-lockup-view-model__content-image, .ytLockupViewModelContentImage'); const c = th && th.closest(CARDS); if (!c) return; e.preventDefault(); e.stopPropagation(); vpFromCard226(c, { y: e.clientY }); }, true);
  /* a playlist page: its videos into Холст — next to its properties */
  function plList226() {
    if (!plHere() || document.getElementById('holst-yt-pll')) return; const c = document.getElementById('holst-yt-plc'), first = document.querySelector('ytd-playlist-video-renderer'); if (!c && !first) return;
    const b = document.createElement('button'); b.id = 'holst-yt-pll'; b.textContent = 'Видео плейлиста — в Холст'; b.title = 'Выбрать видео этого плейлиста и отправить в Холст';
    b.style.cssText = (c && c.getAttribute('style')) || 'height:36px;border-radius:18px;border:0;padding:0 14px;margin-left:8px;cursor:pointer;font:500 14px Roboto,Arial,sans-serif;background:var(--yt-spec-badge-chip-background,#0000000d);color:var(--yt-spec-text-primary,#0f0f0f)';
    b.addEventListener('click', e => { e.stopPropagation(); listAll(); }); if (c) c.after(b); else { b.style.margin = '8px 0'; first.parentElement.insertBefore(b, first.parentElement.firstChild); }
  }
  /* Dark Reader */
  const dark226 = () => { const m = S225.theme226 || 'auto'; return m === 'dark' || (m === 'auto' && (document.documentElement.hasAttribute('data-darkreader-mode') || document.documentElement.hasAttribute('data-darkreader-scheme') || !!document.querySelector('meta[name="darkreader"]') || (document.documentElement.hasAttribute('dark') && !!document.querySelector('html[dark]')))); };
  function theme226() {
    const d = dark226(); for (const id of ['holst-feed', 'holst-yt', 'holst-vp226', 'holst-panel']) { const h = document.getElementById(id); if (h && h.hasAttribute('data-dark') !== d) h.toggleAttribute('data-dark', d); }
    let st = document.getElementById('holst-ent226'); if (!st) { st = document.createElement('style'); st.id = 'holst-ent226'; document.documentElement.appendChild(st); }
    const css = '.holst-ytc,.holst-mom,#holst-yt-mc,#holst-yt-src,#holst-yt-subs,.holst-add,.holst-hide{display:none!important}html:not(.holst-feedpage) #holst-yt-mast,html:not(.holst-feedpage) #holst-pins225{display:none!important}[data-holst-col226] #contents,[data-holst-col226] #dismissible{max-height:56px;overflow:hidden}'
      + (d ? '#holst-quick225{background:#1e2022!important;border-color:#3a3e41!important;color:#e8e6e3!important}#holst-quick225 button,#holst-pins225 button{background:#232627!important;color:#e8e6e3!important;border-color:#3a3e41!important}#holst-quick225 button[data-on],#holst-pins225 button[data-on]{background:#4a3c0f!important;border-color:#d8a90e!important;color:#fff3c4!important}#holst-quick225 b{color:#a8a095!important}' : '');
    if (st.textContent !== css) st.textContent = css;
  }
  /* blocks: sideways or a grid, rows */
  const lim226 = b => { const rows = Math.max(1, Math.min(6, +b.rows || 1)), w = b.size === 's' ? 170 : b.size === 'l' ? 270 : 210, W = (document.querySelector('ytd-rich-grid-renderer, ytd-section-list-renderer') || {}).clientWidth || 1200, cols = Math.max(1, Math.floor(W / (w + 10))); return b.view === 'grid' ? rows * cols : rows * Math.max(cols + 3, 8); };
  const bl226 = b => b.view === 'grid' ? 'display:grid;grid-template-columns:repeat(auto-fill,minmax(var(--w224,210px),1fr));gap:12px 10px' : `display:grid;grid-auto-flow:column;grid-template-rows:repeat(${Math.max(1, Math.min(6, +b.rows || 1))},auto);grid-auto-columns:var(--w224,210px);gap:12px 10px;overflow-x:auto;padding-bottom:6px`;
  const bv226 = B => `<div class="row"><span>Вид блока</span><select data-be="view"><option value="scroll"${(B.view || 'scroll') === 'scroll' ? ' selected' : ''}>прокрутка вбок</option><option value="grid"${B.view === 'grid' ? ' selected' : ''}>сетка без прокрутки</option></select><span>Рядов</span><input type="number" min="1" max="6" data-be="rows" value="${esc(B.rows || 1)}"></div>`;
  /* the feed panel: tabs as tabs, settings as chips; groups by meaning */
  TABS225.splice(0, TABS225.length, ['yt', 'feed', 'Лента'], ['yt', 'shelf', 'Полки YouTube'], ['yt', 'props', 'Свойства'], ['yt', 'ai', 'ИИ'], ['yt', 'presets', 'Пресеты и передний слой']);
  { const o = tab225; tab225 = t => (t === 'shelf' ? shelfHTML226() : t === 'props' ? merHTML226() + o(t) : t === 'presets' ? o(t) + themeHTML226() : o(t)); }
  const merHTML226 = () => { const own = YC.props.filter(P => !P.src); return `<div class="blk224"><b>Свести всё в мои свойства</b><p class="hint">Метки из PocketTube и других источников переходят в ваше свойство; одинаковые названия становятся одной опцией, отметки сохраняются.</p><div class="row"><select data-a="mt226">${own.map(P => `<option value="${esc(P.id)}"${S225.mt226 === P.id ? ' selected' : ''}>в «${esc(P.n)}»</option>`).join('') || '<option value="">сначала создайте своё свойство</option>'}</select><button class="go" data-a="mgo226">Свести сейчас</button><label style="display:inline-flex;gap:4px;align-items:center"><input type="checkbox" data-a="mauto226"${S225.mt226 ? ' checked' : ''}>и всё новое — сразу туда</label></div></div>`; };
  const themeHTML226 = () => `<h5>Тема панелей</h5><div class="row"><div class="seg">${[['auto', 'как сайт (Dark Reader)'], ['light', 'светлая'], ['dark', 'тёмная']].map(([v, l]) => `<button class="${(S225.theme226 || 'auto') === v ? 'on' : ''}" data-th226="${v}">${l}</button>`).join('')}</div></div>`;
  const GROUPS226 = [['Пресет', ['Пресет']], ['Показ', ['Шортсы', 'В ряду', 'Новизна', 'Новое у каналов', 'Досмотренное']], ['Порядок и отбор', ['Сортировка', 'Категории', 'Свойства']]];
  { const o = feedPanel221; feedPanel221 = keep => {
    o(keep); const host = document.getElementById('holst-feed'); if (!host) return; host.toggleAttribute('data-dark', dark226()); const R = host.shadowRoot, p = R.querySelector('.p'); if (!p || p.querySelector('.pw226')) return;
    const F = FEED || feedDef221(), h = p.querySelector('.h'); h.querySelector('b').textContent = 'Лента';
    h.querySelector('.x').insertAdjacentHTML('beforebegin', `<button class="pw226${F.off226 ? '' : ' on'}" data-a="off226" title="Все настройки ленты: включить или выключить разом">${F.off226 ? 'Выключено' : 'Включено'}</button>`);
    const pa = p.querySelector('.panels224'); if (pa) pa.remove(); const pg = p.querySelector('.row.pa'); if (pg) pg.remove();
    if ((FOPEN.tab225 || 'feed') !== 'feed') return;
    const rows = [...p.children].filter(x => x.classList.contains('row')); let last = p.querySelector('.tabs225');
    for (const [title, labels] of GROUPS226) { const L = rows.filter(r => labels.includes(((r.querySelector(':scope > span') || {}).textContent || '').trim())); if (!L.length) continue; const s = document.createElement('div'); s.className = 'sec grp226'; s.innerHTML = `<h5>${title}</h5>`; L.forEach(r => s.appendChild(r)); last.after(s); last = s; }
    const g2 = [...p.querySelectorAll('.grp226')].pop(); if (g2) g2.insertAdjacentHTML('beforeend', '<div class="row"><button class="go ghost" data-a="p224subs">Каналы подписок: вес и порядок</button></div>');
    const more = p.querySelector('.more'); if (more) { more.classList.add('disc226'); more.textContent = (FOPEN.more ? '▾ ' : '▸ ') + 'Фильтры, системные свойства, блоки, скрытые каналы'; }
  }; }
  { const o = feedClick221; feedClick221 = async (e, host) => {
    const t = e.target.closest('button'); if (!t) return o(e, host); const a = t.dataset.a;
    if (a === 'off226') { e.stopPropagation(); FEED.off226 = !FEED.off226; feedSave221(); feedPanel221(true); return; }
    if (a === 'mgo226') { e.stopPropagation(); const v = host.shadowRoot.querySelector('[data-a=mt226]').value; if (!v) return; const n = merge226(v); applyFeed221(true); feedPanel221(true); return void n; }
    if (t.dataset.th226) { e.stopPropagation(); S225.theme226 = t.dataset.th226; s225Save(); theme226(); feedPanel221(true); return; }
    return o(e, host);
  }; }
  { const o = feedChange221; feedChange221 = e => {
    const t = e.target, d = t.dataset;
    if (d.sh226) { e.stopPropagation(); const [title, k] = d.sh226.split('|'), S = FEED.sh226 = FEED.sh226 || {}, c = S[title] = S[title] || {}; c[k] = t.type === 'checkbox' ? t.checked : t.value; feedSave221(); return; }
    if (d.a === 'mauto226') { e.stopPropagation(); S225.mt226 = t.checked ? (t.getRootNode().querySelector('[data-a=mt226]') || {}).value || '' : ''; s225Save(); return; }
    if (d.a === 'mt226') { e.stopPropagation(); if (S225.mt226) { S225.mt226 = t.value; s225Save(); } return; }
    if (d.be === 'view' || d.be === 'rows') { e.stopPropagation(); return; }
    return o(e);
  }; }
  /* YouTube changes pages without reloading */
  const tick = () => { if (!alive()) return; playerButton(); catButton(); listButton(); subsButton(); menuItem(); catMenuItem(); momentBtn(); mast221(); srcButton(); plButton(); marks(false); applyFeed221(); if (YW.id) drawTl(); try { pins225(); fill225(); quick225(); plTiles225(); plCollect226(); plList226(); theme226(); } catch (e) { /* 2.25 */ } };
  document.addEventListener('yt-navigate-finish', () => { close(); closePanel(); setTimeout(tick, 400); });
  new MutationObserver(() => { clearTimeout(tick.t); tick.t = setTimeout(tick, 150); }).observe(document.documentElement, { childList: true, subtree: true });
  tick();
})();
