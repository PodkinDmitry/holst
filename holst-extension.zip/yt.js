/* Холст on YouTube (v2.18: the player button, «В Холст» in ⋮ and the list button open the one clipper panel. v2.17: a board card with cover, channel avatar, duration and chapters; the network list with status):
   · a quiet white button in the player bar — the video into sources (with a weight), into the
     task manager (status, action, why it caught you), to the network for a breakdown, with
     suggested properties to approve in Холст;
   · «просмотрено» by itself when a video known to Холст is watched to the end;
   · playlists, channels and feeds: a button to take all or selected videos at once;
   · ⋮ under any video in the feed: «В Холст» — without opening the video;
   · subscriptions: weights of channels as sources. */
(() => {
  if (window.top !== window || window.__holstYt) return; window.__holstYt = 1;
  const bg = (op, data) => chrome.runtime.sendMessage({ to: 'bg', op, data }).catch(e => ({ ok: false, data: String(e && e.message || e) }));
  const esc = s => String(s || '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const vid = u => { const m = String(u || '').match(/(?:[?&]v=|youtu\.be\/|\/shorts\/)([\w-]{11})/); return m ? m[1] : ''; };
  const XSVG = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>';
  const ICON = '<svg viewBox="0 0 36 36" width="100%" height="100%"><path d="M11.5 10.5h13a2 2 0 0 1 2 2v8.5l-5.5 5.5h-9.5a2 2 0 0 1-2-2v-12a2 2 0 0 1 2-2z" fill="none" stroke="#fff" stroke-width="1.9" stroke-linejoin="round"/><path d="M26.5 21h-3.5a2 2 0 0 0-2 2v3.5" fill="none" stroke="#fff" stroke-width="1.9" stroke-linejoin="round"/><path d="M14 15h8M14 18.5h5" stroke="#fff" stroke-width="1.9" stroke-linecap="round"/></svg>';
  const STY = `:host{all:initial}*{box-sizing:border-box}.p{position:fixed;z-index:2147483646;width:360px;max-height:min(640px,calc(100vh - 80px));overflow:auto;background:#fff;color:#0f0f0f;border-radius:14px;box-shadow:0 18px 50px -12px rgba(0,0,0,.5);font:13px/1.4 Roboto,Arial,sans-serif;padding:12px 14px;display:flex;flex-direction:column;gap:8px}
    .h{display:flex;align-items:center;gap:8px}.h b{font-size:14.5px;flex:1}.x{border:0;background:none;cursor:pointer;color:inherit;line-height:0;padding:4px;border-radius:6px;display:inline-flex}.x:hover{background:#0000000f}
    .st{font-size:12px;color:#606060}.t{font-weight:600;font-size:13px}
    label{display:flex;flex-direction:column;gap:3px;font-size:12px;color:#606060}textarea,select,input[type=number]{border:1px solid #d9d9d9;border-radius:8px;padding:6px 8px;font:inherit;color:inherit;background:transparent}textarea{resize:vertical;min-height:52px}
    .ck{flex-direction:row;align-items:center;gap:7px;color:inherit;font-size:13px}
    .seg{display:flex;flex-wrap:wrap;gap:4px}.seg button{border:1px solid #d9d9d9;background:transparent;color:inherit;border-radius:999px;padding:3px 10px;font:500 12px Roboto,Arial,sans-serif;cursor:pointer}.seg button.on{background:#0f0f0f;color:#fff;border-color:#0f0f0f}
    .row{display:flex;align-items:center;gap:8px}.row>span{width:70px;color:#606060;font-size:12px;flex:none}input[type=range]{flex:1}
    .go{height:36px;border:0;border-radius:18px;background:#0f0f0f;color:#fff;font:600 13px Roboto,Arial,sans-serif;cursor:pointer}.go:disabled{opacity:.5}
    .l{display:flex;flex-direction:column;gap:2px;max-height:240px;overflow:auto;border:1px solid #e5e5e5;border-radius:10px;padding:4px}.l label{flex-direction:row;align-items:center;gap:8px;color:inherit;font-size:12.5px;padding:3px 4px}.l label span{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.l input[type=number]{width:62px;padding:3px 6px}
    .ok{color:#1a7f37;font-size:12px}.err{color:#c00;font-size:12px}
    @media (prefers-color-scheme:dark){.p{background:#212121;color:#f1f1f1}.st,label,.row>span{color:#aaa}textarea,select,input[type=number],.seg button,.l{border-color:#3f3f3f}.seg button.on,.go{background:#f1f1f1;color:#0f0f0f;border-color:#f1f1f1}.x:hover{background:#ffffff14}}`;
  let host = null, root = null, INFO = null, AIS = [];
  function panel(html, at) {
    if (!host || !host.isConnected) { host = document.createElement('div'); host.id = 'holst-yt'; document.documentElement.appendChild(host); root = host.attachShadow({ mode: 'open' }); }
    root.innerHTML = `<style>${STY}</style><div class="p">${html}</div>`;
    const p = root.querySelector('.p'); const r = at || { right: 24, bottom: 90 };
    Object.assign(p.style, r.left != null ? { left: r.left + 'px' } : { right: r.right + 'px' }, r.top != null ? { top: r.top + 'px' } : { bottom: r.bottom + 'px' });
    if (r.bottom != null) p.style.maxHeight = Math.max(220, innerHeight - r.bottom - 12) + 'px';
    root.querySelector('.x').addEventListener('click', close);
    root.querySelectorAll('.seg').forEach(s => s.addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; const on = b.classList.contains('on'); s.querySelectorAll('button').forEach(x => x.classList.remove('on')); if (!on) b.classList.add('on'); }));
    return p;
  }
  const close = () => { if (host) { host.remove(); host = null; root = null; } };
  const segVal = sel => { const b = root.querySelector(sel + ' button.on'); return b ? b.dataset.v : ''; };
  let MAIN = '';
  async function aiList() { if (AIS.length) return AIS; const r = await bg('ping'); const A = r && r.ok && r.data && r.data.ai217; MAIN = A && A.main ? A.mainName : ''; AIS = A ? A.list : (r && r.ok && r.data && r.data.ais) || []; return AIS; }
  const OPTS = (I, many) => `
    <label>Зачем это мне<textarea data-f="intent" placeholder="Чем зацепило, что хочу из этого взять — нейросеть учтёт">${esc(I && I.intent)}</textarea></label>
    <div class="row"><span>Статус</span><div class="seg" data-s="st">${((I && I.sts) || ['новое', 'просмотрено', 'в работе', 'разобрано', 'архив']).map(v => `<button data-v="${esc(v)}" class="${I && I.st216 === v ? 'on' : ''}">${esc(v)}</button>`).join('')}</div></div>
    <div class="row"><span>Действие</span><div class="seg" data-s="act">${((I && I.acts) || ['посмотреть', 'законспектировать', 'применить', 'обсудить', 'отложить', 'удалить']).map(v => `<button data-v="${esc(v)}" class="${I && I.act216 === v ? 'on' : ''}">${esc(v)}</button>`).join('')}</div></div>
    <div class="row"><span>Вес</span><input type="range" min="0" max="100" step="5" value="${I && I.w216 !== '' && I.w216 != null ? I.w216 : 60}" data-f="w"><b data-f="wv">${I && I.w216 !== '' && I.w216 != null ? I.w216 : 60}</b></div>
    <label class="ck"><input type="checkbox" data-f="kb" ${I && I.kb ? 'checked' : 'checked'}> В источники — расшифровка в базу знаний с этим весом</label>
    <label class="ck"><input type="checkbox" data-f="task" ${I && I.task ? 'checked' : many ? '' : 'checked'}> В задачник — со статусом и действием</label>
    <label class="ck"><input type="checkbox" data-f="cap"> Нейросеть: разобрать, как быстрый ввод, — на согласование</label>
    <label class="ck"><input type="checkbox" data-f="board"> На доску — красивой карточкой: обложка, канал, длительность, главы</label>
    <label class="ck"><input type="checkbox" data-f="tag" checked> Нейросеть: предложить ярлыки и свойства — утвердите в задачнике</label>
    <select data-f="pick"><option value="">Нейросеть: сначала бесплатные</option></select>`;
  function wireOpts(p) {
    const w = p.querySelector('[data-f="w"]'), wv = p.querySelector('[data-f="wv"]'); if (w) w.addEventListener('input', () => { wv.textContent = w.value; });
    aiList().then(L => { const s = p.querySelector('[data-f="pick"]'), add = (v, l, off) => { const o = document.createElement('option'); o.value = v; o.textContent = l; if (off) o.disabled = true; s.appendChild(o); return o; };
      add('__main', 'Личная платная основная' + (MAIN ? ' — ' + MAIN : ' — не подключена'), !MAIN); for (const a of L.filter(a => !a.st || a.st === 'ok')) add(a.p, a.l); for (const a of L.filter(a => a.st && a.st !== 'ok')) add(a.p, a.l, 1); add('__set', 'Подключить ещё нейросети…');
      s.addEventListener('change', () => { if (s.value === '__set') { s.value = ''; bg('open', { ai: 1 }); } });
      chrome.storage.local.get('ytPick').then(r => { if (r.ytPick && [...s.options].some(o => o.value === r.ytPick && !o.disabled)) s.value = r.ytPick; }); });
  }
  const optsOf = p => { const f = k => p.querySelector(`[data-f="${k}"]`); chrome.storage.local.set({ ytPick: f('pick').value }); return { intent: f('intent').value.trim(), st: segVal('[data-s="st"]'), act: segVal('[data-s="act"]'), w: +f('w').value, kb: f('kb').checked, task: f('task').checked, cap: f('cap').checked, tag: f('tag').checked, board: f('board') ? f('board').checked : false, pick: f('pick').value === '__set' ? '' : f('pick').value }; };
  /* ---------- one video: the player button ---------- */
  /* v2.17: everything a beautiful card needs — cover, channel avatar, duration, views, date, chapters */
  const secOf = t => { const p = String(t || '').trim().split(':').map(Number); return p.some(isNaN) ? 0 : p.reduce((a, b) => a * 60 + b, 0); };
  const chaptersOf = text => { const ch = []; for (const line of String(text || '').split('\n')) { const m = line.match(/^\s*((?:\d{1,2}:)?\d{1,2}:\d{2})\s*[-–—:|]?\s*(.{2,90})$/); if (m) ch.push({ s: secOf(m[1]), t: m[2].trim() }); } return ch.length >= 2 && ch[0].s === 0 ? ch.slice(0, 60) : []; };
  const ldVideo = () => { for (const sc of document.querySelectorAll('script[type="application/ld+json"]')) { try { const j = JSON.parse(sc.textContent); for (const x of [].concat(j)) if ([].concat(x['@type'] || []).includes('VideoObject')) return x; } catch (e) { /* broken */ } } return {}; };
  const curVideo = () => {
    const id = vid(location.href); if (!id) return null;
    const t = document.querySelector('h1.ytd-watch-metadata yt-formatted-string, h1.ytd-watch-metadata, #title h1'), ch = document.querySelector('#owner #channel-name a, ytd-video-owner-renderer #channel-name a, ytd-channel-name a'), ds = document.querySelector('#description-inline-expander, ytd-text-inline-expander, #description');
    const av = document.querySelector('#owner #avatar img, ytd-video-owner-renderer #avatar img, ytd-video-owner-renderer img'), V = ldVideo(), v = document.querySelector('video.html5-main-video, video');
    const iso = String(V.duration || '').match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/), ist = [].concat(V.interactionStatistic || [])[0], desc = ds ? ds.innerText.trim().slice(0, 3000) : String(V.description || '');
    const dur = iso && (iso[1] || iso[2] || iso[3]) ? (+iso[1] || 0) * 3600 + (+iso[2] || 0) * 60 + (+iso[3] || 0) : v && isFinite(v.duration) ? Math.round(v.duration) : 0;
    return { id, title: (t && t.textContent.trim()) || document.title.replace(/ - YouTube$/, ''), channel: ch ? ch.textContent.trim() : '', desc, meta: { yt: 1, id, thumb: 'https://i.ytimg.com/vi/' + id + '/hqdefault.jpg', ch: ch ? ch.textContent.trim() : '', chUrl: ch ? ch.href : '', chAv: av ? av.currentSrc || av.src || '' : '', dur, views: +(V.interactionCount || (ist && ist.userInteractionCount) || 0), date: V.uploadDate || V.datePublished || '', chapters: chaptersOf(desc), desc: desc.slice(0, 600) } };
  };
  async function openOne(v, at) {
    if (!v) return; const p = panel(`<div class="h"><b>В Холст</b><button class="x" title="Закрыть" aria-label="Закрыть">${XSVG}</button></div><div class="t">${esc(v.title)}</div><div class="st" data-f="info">Спрашиваю Холст…</div>${OPTS(null, false)}<button class="go">Сохранить в Холст</button><div data-f="res"></div>`, at);
    wireOpts(p);
    const r = await bg('yt-info', { id: v.id }); INFO = r && r.ok ? r.data : null;
    const inf = p.querySelector('[data-f="info"]');
    if (!INFO) inf.innerHTML = '<span class="err">Холст не ответил — откройте Холст во вкладке</span>';
    else { inf.textContent = [INFO.task ? 'в задачнике' : '', INFO.kb ? 'в источниках, вес ' + INFO.kb.w : ''].filter(Boolean).join(' · ') || 'Ещё нет в Холсте';
      const set = (k, v2) => { const b = p.querySelector(`[data-s="${k}"] button[data-v="${CSS.escape(v2)}"]`); if (b) b.classList.add('on'); };
      if (INFO.st216) set('st', INFO.st216); if (INFO.act216) set('act', INFO.act216); if (INFO.intent) p.querySelector('[data-f="intent"]').value = INFO.intent;
      if (INFO.w216 !== '' && INFO.w216 != null) { p.querySelector('[data-f="w"]').value = INFO.w216; p.querySelector('[data-f="wv"]').textContent = INFO.w216; } }
    p.querySelector('.go').addEventListener('click', async () => {
      const b = p.querySelector('.go'), o = optsOf(p); b.disabled = true; b.textContent = 'Сохраняю…';
      const res = await bg('yt-add', Object.assign({ videos: [v] }, o));
      p.querySelector('[data-f="res"]').innerHTML = res && res.ok ? '<div class="ok">Готово. Свойства от нейросети — на согласование в задачнике.</div>' : `<div class="err">${esc((res && res.data) || 'Холст не ответил')}</div>`;
      b.disabled = false; b.textContent = 'Сохранить в Холст'; if (res && res.ok) setTimeout(close, 1400);
    });
  }
  /* v2.18: one panel for every way in — the same clipper as the button of the browser, in a frame on the page */
  let frameHost = null;
  async function openPanel(q) {
    closePanel(); close();
    const r = await bg('my-tab'); const id = r && r.ok && r.id; if (!id) { alert('Холст: расширение не ответило. Перезапустите его: chrome://extensions → «Холст» → ⟳'); return; }
    frameHost = document.createElement('div'); frameHost.id = 'holst-panel';
    frameHost.style.cssText = 'all:initial;position:fixed;z-index:2147483646;right:16px;top:72px;width:400px;height:min(600px,calc(100vh - 88px));border-radius:16px;overflow:hidden;box-shadow:0 24px 70px -18px rgba(0,0,0,.55);background:#fff;transition:opacity .12s';
    const f = document.createElement('iframe'); f.src = chrome.runtime.getURL('popup.html') + '?' + new URLSearchParams(Object.assign({ tab: id, embed: 1 }, q || {})).toString();
    f.style.cssText = 'border:0;width:100%;height:100%;display:block;color-scheme:normal'; f.allow = 'clipboard-write';
    frameHost.appendChild(f); document.documentElement.appendChild(frameHost);
  }
  function closePanel() { if (frameHost) { frameHost.remove(); frameHost = null; } }
  addEventListener('message', e => { if (!frameHost || !e.data || !e.data.holst218) return; const f = frameHost.querySelector('iframe'); if (e.source !== (f && f.contentWindow)) return; const a = e.data.holst218; if (a === 'close') closePanel(); else if (a === 'hide') frameHost.style.opacity = '0'; else if (a === 'show') frameHost.style.opacity = '1'; });
  function playerButton() {
    const bar = document.querySelector('.ytp-right-controls'); if (!bar || bar.querySelector('.holst-ytp')) return;
    const b = document.createElement('button'); b.className = 'ytp-button holst-ytp'; b.title = 'В Холст'; b.setAttribute('aria-label', 'В Холст'); b.innerHTML = ICON; b.style.opacity = '.85';
    b.addEventListener('click', e => { e.stopPropagation(); frameHost ? closePanel() : openPanel({}); });
    bar.insertBefore(b, bar.firstChild);
  }
  /* watched to the end: «просмотрено» for videos Холст knows */
  const WATCHED = new Set();
  document.addEventListener('timeupdate', async e => {
    const v = e.target; if (!(v instanceof HTMLVideoElement) || !v.duration || v.currentTime / v.duration < 0.9) return; const id = vid(location.href); if (!id || WATCHED.has(id)) return; WATCHED.add(id);
    const r = await bg('yt-info', { id }); if (r && r.ok && r.data && (r.data.task || r.data.kb) && r.data.st216 !== 'просмотрено') bg('yt-status', { id, st: 'просмотрено' });
  }, true);
  /* ---------- many videos: playlists, channels, feeds ---------- */
  const CARDS = 'ytd-playlist-video-renderer, ytd-rich-item-renderer, ytd-grid-video-renderer, ytd-video-renderer, ytd-compact-video-renderer, yt-lockup-view-model';
  const cardVideo = c => {
    const a = c.querySelector('a[href*="/watch?v="], a[href*="/shorts/"]'); const id = a && vid(a.href); if (!id) return null;
    const t = c.querySelector('#video-title, h3 a, h3, [id="video-title-link"]'), ch = c.querySelector('ytd-channel-name a, #channel-name a, .yt-content-metadata-view-model-wiz__metadata-text, .yt-content-metadata-view-model__metadata-text');
    const av = c.querySelector('#avatar-link img, #avatar img, yt-decorated-avatar-view-model img, .yt-spec-avatar-shape__image'), d = c.querySelector('ytd-thumbnail-overlay-time-status-renderer #text, badge-shape .badge-shape-wiz__text, .yt-badge-shape__text');
    const title = ((t && (t.getAttribute('title') || t.textContent)) || '').trim() || 'Видео ' + id, chn = ch ? ch.textContent.trim() : '';
    return { id, title, channel: chn, meta: { yt: 1, id, thumb: 'https://i.ytimg.com/vi/' + id + '/hqdefault.jpg', ch: chn, chAv: av ? av.currentSrc || av.src || '' : '', dur: d ? secOf(d.textContent) : 0 } };
  };
  const isList = () => /\/playlist\?|\/(@[^/]+|channel\/[^/]+|c\/[^/]+|user\/[^/]+)\/(videos|streams|shorts|featured)?\/?$|\/results\?|^\/$|\/feed\/(subscriptions|history|playlists)/.test(location.pathname + location.search);
  function listButton() {
    let b = document.getElementById('holst-yt-list'); const show = isList() && !/\/feed\/channels/.test(location.pathname);
    if (!show) { if (b) b.remove(); return; }
    if (b) return; b = document.createElement('button'); b.id = 'holst-yt-list'; b.textContent = 'В Холст: видео этой страницы';
    b.style.cssText = 'position:fixed;left:16px;bottom:16px;z-index:2147483645;border:0;border-radius:18px;padding:9px 14px;background:#0f0f0f;color:#fff;font:600 13px Roboto,Arial,sans-serif;box-shadow:0 8px 24px -8px rgba(0,0,0,.5);cursor:pointer;opacity:.9';
    b.addEventListener('click', async () => { if (frameHost) { closePanel(); return; } const seen = new Set(), L = [...document.querySelectorAll(CARDS)].map(cardVideo).filter(v => v && !seen.has(v.id) && seen.add(v.id)); await chrome.storage.local.set({ many218: { videos: L, at: Date.now() } }); openPanel({ many: 1 }); });
    document.documentElement.appendChild(b);
  }
  function openMany(only) {
    const seen = new Set(), L = (only ? [only] : [...document.querySelectorAll(CARDS)].map(cardVideo)).filter(v => v && !seen.has(v.id) && seen.add(v.id));
    const p = panel(`<div class="h"><b>В Холст: ${L.length} видео</b><button class="x" title="Закрыть" aria-label="Закрыть">${XSVG}</button></div>
      ${only ? '' : `<label class="ck"><input type="checkbox" data-f="all" checked> Все</label>`}
      <div class="l">${L.map((v, i) => `<label><input type="checkbox" data-i="${i}" checked><span title="${esc(v.title)}">${esc(v.title)}</span></label>`).join('') || '<div class="st">Видео на странице не нашлось — прокрутите список, чтобы они загрузились.</div>'}</div>
      ${OPTS(null, true)}<button class="go">Сохранить выбранные</button><div data-f="res"></div>`, { left: 16, bottom: 64 });
    wireOpts(p);
    const all = p.querySelector('[data-f="all"]'); if (all) all.addEventListener('change', () => p.querySelectorAll('[data-i]').forEach(c => { c.checked = all.checked; }));
    p.querySelector('.go').addEventListener('click', async () => {
      const pick = [...p.querySelectorAll('[data-i]:checked')].map(c => L[+c.dataset.i]); if (!pick.length) return;
      const b = p.querySelector('.go'), o = optsOf(p); b.disabled = true; b.textContent = 'Сохраняю ' + pick.length + '…';
      const res = await bg('yt-add', Object.assign({ videos: pick }, o));
      p.querySelector('[data-f="res"]').innerHTML = res && res.ok ? `<div class="ok">Готово: ${res.data.task ? 'задач ' + res.data.task + ' ' : ''}${res.data.kb ? 'в источники ' + res.data.kb + ' ' : ''}${res.data.cap ? 'на разбор ' + res.data.cap : ''}</div>` : `<div class="err">${esc((res && res.data) || 'Холст не ответил')}</div>`;
      b.disabled = false; b.textContent = 'Сохранить выбранные';
    });
  }
  /* ---------- ⋮ under a video: «В Холст» without opening it ---------- */
  let lastCard = null;
  document.addEventListener('click', e => { const t = e.target; if (!t || !t.closest) return; if (t.closest('#holst-yt-mi')) return; const c = t.closest(CARDS); if (c && t.closest('ytd-menu-renderer, button[aria-label], yt-icon-button, .yt-lockup-metadata-view-model-wiz__menu-button, button-view-model')) { lastCard = c; setTimeout(() => tick(), 150); setTimeout(() => tick(), 500); } }, true);
  function menuItem() {
    const dd = [...document.querySelectorAll('tp-yt-iron-dropdown, ytd-popup-container yt-sheet-view-model, yt-contextual-sheet-layout')].find(d => d.getClientRects().length && getComputedStyle(d).display !== 'none' && d.getAttribute('aria-hidden') !== 'true');
    if (!dd || !lastCard) return; const list = dd.querySelector('tp-yt-paper-listbox#items, #items, yt-list-view-model'); if (!list || list.querySelector('#holst-yt-mi')) return;
    const v = cardVideo(lastCard); if (!v) return;
    const it = document.createElement('div'); it.id = 'holst-yt-mi'; it.setAttribute('role', 'menuitem'); it.tabIndex = 0;
    it.style.cssText = 'display:flex;align-items:center;gap:14px;padding:0 16px;height:36px;cursor:pointer;font:400 14px Roboto,Arial,sans-serif;color:var(--yt-spec-text-primary,#0f0f0f)';
    it.innerHTML = `<span style="width:24px;height:24px;display:inline-block;filter:var(--holst-ico,invert(1))">${ICON}</span><span>В Холст</span>`;
    if (document.documentElement.hasAttribute('dark')) it.querySelector('span').style.filter = 'none';
    it.addEventListener('mouseenter', () => { it.style.background = 'var(--yt-spec-10-percent-layer,#0000000d)'; }); it.addEventListener('mouseleave', () => { it.style.background = ''; });
    it.addEventListener('click', e => { e.stopPropagation(); document.body.click(); setTimeout(() => openPanel({ vid: v.id, vt: v.title, vch: v.channel || '' }), 60); });
    list.insertBefore(it, list.firstChild);
  }
  /* ---------- subscriptions: weights of channels ---------- */
  function subsButton() {
    let b = document.getElementById('holst-yt-subs'); const show = /\/feed\/channels/.test(location.pathname);
    if (!show) { if (b) b.remove(); return; } if (b) return;
    b = document.createElement('button'); b.id = 'holst-yt-subs'; b.textContent = 'В Холст: веса каналов';
    b.style.cssText = 'position:fixed;left:16px;bottom:16px;z-index:2147483645;border:0;border-radius:18px;padding:9px 14px;background:#0f0f0f;color:#fff;font:600 13px Roboto,Arial,sans-serif;box-shadow:0 8px 24px -8px rgba(0,0,0,.5);cursor:pointer;opacity:.9';
    b.addEventListener('click', () => (host ? close() : openSubs())); document.documentElement.appendChild(b);
  }
  async function openSubs() {
    const seen = new Set(), L = [...document.querySelectorAll('ytd-channel-renderer')].map(c => { const a = c.querySelector('a#main-link, a[href^="/@"], a[href*="/channel/"]'), n = c.querySelector('#channel-title, #text'); return a ? { url: new URL(a.getAttribute('href'), location.origin).href.replace(/\/$/, ''), name: (n && n.textContent.trim()) || a.textContent.trim() } : null; }).filter(c => c && !seen.has(c.url) && seen.add(c.url));
    const k = await bg('yt-known'), known = (k && k.ok && k.data.ch) || [], comps = (k && k.ok && k.data.comps) || [], key = u => u.replace(/^https?:\/\/(www\.)?/, '').toLowerCase().replace(/\/$/, '');
    const p = panel(`<div class="h"><b>Каналы как источники: ${L.length}</b><button class="x" title="Закрыть" aria-label="Закрыть">${XSVG}</button></div>
      <div class="st">Вес — насколько доверять каналу в «Источниках» Холста (0–100). Отметьте, какие каналы взять в источники; уже взятые — с весом.</div>
      <div class="l" style="max-height:340px">${L.map((c, i) => { const kn = known.find(x => key(x.url) === key(c.url)); return `<label><input type="checkbox" data-i="${i}"${kn ? ' checked disabled' : ''}><span title="${esc(c.name)}">${esc(c.name)}</span><input type="number" min="0" max="100" step="5" data-w="${i}" value="${kn ? kn.w : 60}"></label>`; }).join('') || '<div class="st">Каналы не нашлись — прокрутите список подписок.</div>'}</div>
      ${comps.length ? `<label>Компетенция для отмеченных<select data-f="comp"><option value="">Определит Холст</option>${comps.map(c => `<option value="${esc(c.k)}">${esc(c.l)}</option>`).join('')}</select></label>` : ''}
      <button class="go">Сохранить веса и источники</button><div data-f="res"></div>`, { left: 16, bottom: 64 });
    p.querySelector('.go').addEventListener('click', async () => {
      const comp = (p.querySelector('[data-f="comp"]') || {}).value || '';
      const list = L.map((c, i) => ({ url: c.url, name: c.name, w: +p.querySelector(`[data-w="${i}"]`).value, kb: p.querySelector(`[data-i="${i}"]`).checked, comp })).filter(c => c.kb || known.some(x => key(x.url) === key(c.url)));
      const res = await bg('yt-channels', { list });
      p.querySelector('[data-f="res"]').innerHTML = res && res.ok ? `<div class="ok">Обновлено весов: ${res.data.n}, новых источников: ${res.data.add}</div>` : `<div class="err">${esc((res && res.data) || 'Холст не ответил')}</div>`;
    });
  }
  /* YouTube changes pages without reloading */
  const tick = () => { playerButton(); listButton(); subsButton(); menuItem(); };
  document.addEventListener('yt-navigate-finish', () => { close(); closePanel(); setTimeout(tick, 400); });
  new MutationObserver(() => { clearTimeout(tick.t); tick.t = setTimeout(tick, 150); }).observe(document.documentElement, { childList: true, subtree: true });
  tick();
})();
