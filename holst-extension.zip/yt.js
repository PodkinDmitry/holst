/* Холст on YouTube (v2.20: watched zones and moments on the timeline, a moment panel (note, task, question, the network about the moment, a frame to the object on a board, a loop), the feed sorted by the properties of Холст, marks on covers, «+» on a cover, a channel or a playlist into sources, properties by the network for a page. v2.18: the player button, «В Холст» in ⋮ and the list button open the one clipper panel. v2.17: a board card with cover, channel avatar, duration and chapters; the network list with status):
   · a quiet white button in the player bar — the video into sources (with a weight), into the
     task manager (status, action, why it caught you), to the network for a breakdown, with
     suggested properties to approve in Холст;
   · «просмотрено» by itself when a video known to Холст is watched to the end;
   · playlists, channels and feeds: a button to take all or selected videos at once;
   · ⋮ under any video in the feed: «В Холст» — without opening the video;
   · subscriptions: weights of channels as sources. */
(() => {
  if (window.top !== window || window.__holstYt) return; window.__holstYt = 1;
  const bg = (op, data) => chrome.runtime.sendMessage({ to: 'bg', op, data }).catch(e => ({ ok: false, data: String(e && e.message || e) }));
  const esc = s => String(s || '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const vid = u => { const m = String(u || '').match(/(?:[?&]v=|youtu\.be\/|\/shorts\/)([\w-]{11})/); return m ? m[1] : ''; };
  const XSVG = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>';
  const ICON = '<svg viewBox="0 0 36 36" width="100%" height="100%"><path d="M11.5 10.5h13a2 2 0 0 1 2 2v8.5l-5.5 5.5h-9.5a2 2 0 0 1-2-2v-12a2 2 0 0 1 2-2z" fill="none" stroke="#fff" stroke-width="1.9" stroke-linejoin="round"/><path d="M26.5 21h-3.5a2 2 0 0 0-2 2v3.5" fill="none" stroke="#fff" stroke-width="1.9" stroke-linejoin="round"/><path d="M14 15h8M14 18.5h5" stroke="#fff" stroke-width="1.9" stroke-linecap="round"/></svg>';
  const STY = `:host{all:initial}*{box-sizing:border-box}.p{position:fixed;z-index:2147483646;width:360px;max-height:min(640px,calc(100vh - 80px));overflow:auto;background:#fff;color:#0f0f0f;border-radius:14px;box-shadow:0 18px 50px -12px rgba(0,0,0,.5);font:13px/1.4 Roboto,Arial,sans-serif;padding:12px 14px;display:flex;flex-direction:column;gap:8px}
    .h{display:flex;align-items:center;gap:8px}.h b{font-size:14.5px;flex:1}.x{border:0;background:none;cursor:pointer;color:inherit;line-height:0;padding:4px;border-radius:6px;display:inline-flex}.x:hover{background:#0000000f}
    .st{font-size:12px;color:#606060}.t{font-weight:600;font-size:13px}
    label{display:flex;flex-direction:column;gap:3px;font-size:12px;color:#606060}textarea,select,input[type=number]{border:1px solid #d9d9d9;border-radius:8px;padding:6px 8px;font:inherit;color:inherit;background:transparent}textarea{resize:vertical;min-height:52px}
    .ck{flex-direction:row;align-items:center;gap:7px;color:inherit;font-size:13px}
    .seg{display:flex;flex-wrap:wrap;gap:4px}.seg button{border:1px solid #d9d9d9;background:transparent;color:inherit;border-radius:999px;padding:3px 10px;font:500 12px Roboto,Arial,sans-serif;cursor:pointer}.seg button.on{background:#0f0f0f;color:#fff;border-color:#0f0f0f}
    .row{display:flex;align-items:center;gap:8px}.row>span{width:70px;color:#606060;font-size:12px;flex:none}input[type=range]{flex:1}
    .go{height:36px;border:0;border-radius:18px;background:#0f0f0f;color:#fff;font:600 13px Roboto,Arial,sans-serif;cursor:pointer}.go:disabled{opacity:.5}
    .l{display:flex;flex-direction:column;gap:2px;max-height:240px;overflow:auto;border:1px solid #e5e5e5;border-radius:10px;padding:4px}.l label{flex-direction:row;align-items:center;gap:8px;color:inherit;font-size:12.5px;padding:3px 4px}.l label span{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.l input[type=number]{width:62px;padding:3px 6px}
    .ok{color:#1a7f37;font-size:12px}.err{color:#c00;font-size:12px}
    @media (prefers-color-scheme:dark){.p{background:#212121;color:#f1f1f1}.st,label,.row>span{color:#aaa}textarea,select,input[type=number],.seg button,.l{border-color:#3f3f3f}.seg button.on,.go{background:#f1f1f1;color:#0f0f0f;border-color:#f1f1f1}.x:hover{background:#ffffff14}}`;
  let host = null, root = null, INFO = null, AIS = [];
  function panel(html, at) {
    if (!host || !host.isConnected) { host = document.createElement('div'); host.id = 'holst-yt'; document.documentElement.appendChild(host); root = host.attachShadow({ mode: 'open' }); }
    root.innerHTML = `<style>${STY}</style><div class="p">${html}</div>`;
    const p = root.querySelector('.p'); const r = at || { right: 24, bottom: 90 };
    Object.assign(p.style, r.left != null ? { left: r.left + 'px' } : { right: r.right + 'px' }, r.top != null ? { top: r.top + 'px' } : { bottom: r.bottom + 'px' });
    if (r.bottom != null) p.style.maxHeight = Math.max(220, innerHeight - r.bottom - 12) + 'px';
    root.querySelector('.x').addEventListener('click', close);
    root.querySelectorAll('.seg').forEach(s => s.addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; const on = b.classList.contains('on'); s.querySelectorAll('button').forEach(x => x.classList.remove('on')); if (!on) b.classList.add('on'); }));
    return p;
  }
  const close = () => { if (host) { host.remove(); host = null; root = null; } };
  const segVal = sel => { const b = root.querySelector(sel + ' button.on'); return b ? b.dataset.v : ''; };
  let MAIN = '';
  async function aiList() { if (AIS.length) return AIS; const r = await bg('ping'); const A = r && r.ok && r.data && r.data.ai217; MAIN = A && A.main ? A.mainName : ''; AIS = A ? A.list : (r && r.ok && r.data && r.data.ais) || []; return AIS; }
  const OPTS = (I, many) => `
    <label>Зачем это мне<textarea data-f="intent" placeholder="Чем зацепило, что хочу из этого взять — нейросеть учтёт">${esc(I && I.intent)}</textarea></label>
    <div class="row"><span>Статус</span><div class="seg" data-s="st">${((I && I.sts) || ['новое', 'просмотрено', 'в работе', 'разобрано', 'архив']).map(v => `<button data-v="${esc(v)}" class="${I && I.st216 === v ? 'on' : ''}">${esc(v)}</button>`).join('')}</div></div>
    <div class="row"><span>Действие</span><div class="seg" data-s="act">${((I && I.acts) || ['посмотреть', 'законспектировать', 'применить', 'обсудить', 'отложить', 'удалить']).map(v => `<button data-v="${esc(v)}" class="${I && I.act216 === v ? 'on' : ''}">${esc(v)}</button>`).join('')}</div></div>
    <div class="row"><span>Вес</span><input type="range" min="0" max="100" step="5" value="${I && I.w216 !== '' && I.w216 != null ? I.w216 : 60}" data-f="w"><b data-f="wv">${I && I.w216 !== '' && I.w216 != null ? I.w216 : 60}</b></div>
    <label class="ck"><input type="checkbox" data-f="kb" ${I && I.kb ? 'checked' : 'checked'}> В источники — расшифровка в базу знаний с этим весом</label>
    <label class="ck"><input type="checkbox" data-f="task" ${I && I.task ? 'checked' : many ? '' : 'checked'}> В задачник — со статусом и действием</label>
    <label class="ck"><input type="checkbox" data-f="cap"> Нейросеть: разобрать, как быстрый ввод, — на согласование</label>
    <label class="ck"><input type="checkbox" data-f="board"> На доску — красивой карточкой: обложка, канал, длительность, главы</label>
    <label class="ck"><input type="checkbox" data-f="tag" checked> Нейросеть: предложить ярлыки и свойства — утвердите в задачнике</label>
    <details data-f="pp"><summary class="st">Какие свойства и как</summary><div class="l" style="max-height:none">${[['w216', 'Вес'], ['st216', 'Статус'], ['act216', 'Действие'], ['tags', 'Ярлыки'], ['rel', 'Связи'], ['form216', 'Форма'], ['trust216', 'Доверие']].map(([k, l]) => `<label><input type="checkbox" data-pp="${k}" checked><span>${l}</span></label>`).join('')}<label><input type="checkbox" data-f="acc"><span>Принять сразу, без согласования</span></label></div></details>
    <select data-f="pick"><option value="">Нейросеть: сначала бесплатные</option></select>`;
  function wireOpts(p) {
    const w = p.querySelector('[data-f="w"]'), wv = p.querySelector('[data-f="wv"]'); if (w) w.addEventListener('input', () => { wv.textContent = w.value; });
    aiList().then(L => { const s = p.querySelector('[data-f="pick"]'), add = (v, l, off) => { const o = document.createElement('option'); o.value = v; o.textContent = l; if (off) o.disabled = true; s.appendChild(o); return o; };
      add('__main', 'Личная платная основная' + (MAIN ? ' — ' + MAIN : ' — не подключена'), !MAIN); for (const a of L.filter(a => !a.st || a.st === 'ok')) add(a.p, a.l); for (const a of L.filter(a => a.st && a.st !== 'ok')) add(a.p, a.l, 1); add('__set', 'Подключить ещё нейросети…');
      s.addEventListener('change', () => { if (s.value === '__set') { s.value = ''; bg('open', { ai: 1 }); } });
      chrome.storage.local.get('ytPick').then(r => { if (r.ytPick && [...s.options].some(o => o.value === r.ytPick && !o.disabled)) s.value = r.ytPick; }); });
  }
  const optsOf = p => { const f = k => p.querySelector(`[data-f="${k}"]`); chrome.storage.local.set({ ytPick: f('pick').value }); const pp = [...p.querySelectorAll('[data-pp]:checked')].map(c => c.dataset.pp), tg = f('tag') && f('tag').checked; return { props220: tg ? pp : undefined, accept220: tg && f('acc') && f('acc').checked ? 1 : 0, tag220: tg, intent: f('intent').value.trim(), st: segVal('[data-s="st"]'), act: segVal('[data-s="act"]'), w: +f('w').value, kb: f('kb').checked, task: f('task').checked, cap: f('cap').checked, tag: false, board: f('board') ? f('board').checked : false, pick: f('pick').value === '__set' ? '' : f('pick').value }; };
  /* ---------- one video: the player button ---------- */
  /* v2.17: everything a beautiful card needs — cover, channel avatar, duration, views, date, chapters */
  const secOf = t => { const p = String(t || '').trim().split(':').map(Number); return p.some(isNaN) ? 0 : p.reduce((a, b) => a * 60 + b, 0); };
  const chaptersOf = text => { const ch = []; for (const line of String(text || '').split('\n')) { const m = line.match(/^\s*((?:\d{1,2}:)?\d{1,2}:\d{2})\s*[-–—:|]?\s*(.{2,90})$/); if (m) ch.push({ s: secOf(m[1]), t: m[2].trim() }); } return ch.length >= 2 && ch[0].s === 0 ? ch.slice(0, 60) : []; };
  const ldVideo = () => { for (const sc of document.querySelectorAll('script[type="application/ld+json"]')) { try { const j = JSON.parse(sc.textContent); for (const x of [].concat(j)) if ([].concat(x['@type'] || []).includes('VideoObject')) return x; } catch (e) { /* broken */ } } return {}; };
  const curVideo = () => {
    const id = vid(location.href); if (!id) return null;
    const t = document.querySelector('h1.ytd-watch-metadata yt-formatted-string, h1.ytd-watch-metadata, #title h1'), ch = document.querySelector('#owner #channel-name a, ytd-video-owner-renderer #channel-name a, ytd-channel-name a'), ds = document.querySelector('#description-inline-expander, ytd-text-inline-expander, #description');
    const av = document.querySelector('#owner #avatar img, ytd-video-owner-renderer #avatar img, ytd-video-owner-renderer img'), V = ldVideo(), v = document.querySelector('video.html5-main-video, video');
    const iso = String(V.duration || '').match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/), ist = [].concat(V.interactionStatistic || [])[0], desc = ds ? ds.innerText.trim().slice(0, 3000) : String(V.description || '');
    const dur = iso && (iso[1] || iso[2] || iso[3]) ? (+iso[1] || 0) * 3600 + (+iso[2] || 0) * 60 + (+iso[3] || 0) : v && isFinite(v.duration) ? Math.round(v.duration) : 0;
    return { id, title: (t && t.textContent.trim()) || document.title.replace(/ - YouTube$/, ''), channel: ch ? ch.textContent.trim() : '', desc, meta: { yt: 1, id, thumb: 'https://i.ytimg.com/vi/' + id + '/hqdefault.jpg', ch: ch ? ch.textContent.trim() : '', chUrl: ch ? ch.href : '', chAv: av ? av.currentSrc || av.src || '' : '', dur, views: +(V.interactionCount || (ist && ist.userInteractionCount) || 0), date: V.uploadDate || V.datePublished || '', chapters: chaptersOf(desc), desc: desc.slice(0, 600) } };
  };
  async function openOne(v, at) {
    if (!v) return; const p = panel(`<div class="h"><b>В Холст</b><button class="x" title="Закрыть" aria-label="Закрыть">${XSVG}</button></div><div class="t">${esc(v.title)}</div><div class="st" data-f="info">Спрашиваю Холст…</div>${OPTS(null, false)}<button class="go">Сохранить в Холст</button><div data-f="res"></div>`, at);
    wireOpts(p);
    const r = await bg('yt-info', { id: v.id }); INFO = r && r.ok ? r.data : null;
    const inf = p.querySelector('[data-f="info"]');
    if (!INFO) inf.innerHTML = '<span class="err">Холст не ответил — откройте Холст во вкладке</span>';
    else { inf.textContent = [INFO.task ? 'в задачнике' : '', INFO.kb ? 'в источниках, вес ' + INFO.kb.w : ''].filter(Boolean).join(' · ') || 'Ещё нет в Холсте';
      const set = (k, v2) => { const b = p.querySelector(`[data-s="${k}"] button[data-v="${CSS.escape(v2)}"]`); if (b) b.classList.add('on'); };
      if (INFO.st216) set('st', INFO.st216); if (INFO.act216) set('act', INFO.act216); if (INFO.intent) p.querySelector('[data-f="intent"]').value = INFO.intent;
      if (INFO.w216 !== '' && INFO.w216 != null) { p.querySelector('[data-f="w"]').value = INFO.w216; p.querySelector('[data-f="wv"]').textContent = INFO.w216; } }
    p.querySelector('.go').addEventListener('click', async () => {
      const b = p.querySelector('.go'), o = optsOf(p); b.disabled = true; b.textContent = 'Сохраняю…';
      const res = await bg('yt-add', Object.assign({ videos: [v] }, o));
      p.querySelector('[data-f="res"]').innerHTML = res && res.ok ? '<div class="ok">Готово. Свойства от нейросети — на согласование в задачнике.</div>' : `<div class="err">${esc((res && res.data) || 'Холст не ответил')}</div>`;
      b.disabled = false; b.textContent = 'Сохранить в Холст'; if (res && res.ok) setTimeout(close, 1400);
    });
  }
  /* v2.18: one panel for every way in — the same clipper as the button of the browser, in a frame on the page */
  let frameHost = null;
  async function openPanel(q) {
    closePanel(); close();
    const r = await bg('my-tab'); const id = r && r.ok && r.id; if (!id) { alert('Холст: расширение не ответило. Перезапустите его: chrome://extensions → «Холст» → ⟳'); return; }
    frameHost = document.createElement('div'); frameHost.id = 'holst-panel';
    frameHost.style.cssText = 'all:initial;position:fixed;z-index:2147483646;right:16px;top:72px;width:400px;height:min(600px,calc(100vh - 88px));border-radius:16px;overflow:hidden;box-shadow:0 24px 70px -18px rgba(0,0,0,.55);background:#fff;transition:opacity .12s';
    const f = document.createElement('iframe'); f.src = chrome.runtime.getURL('popup.html') + '?' + new URLSearchParams(Object.assign({ tab: id, embed: 1 }, q || {})).toString();
    f.style.cssText = 'border:0;width:100%;height:100%;display:block;color-scheme:normal'; f.allow = 'clipboard-write';
    frameHost.appendChild(f); document.documentElement.appendChild(frameHost);
  }
  function closePanel() { if (frameHost) { frameHost.remove(); frameHost = null; } }
  addEventListener('message', e => { if (!frameHost || !e.data || !e.data.holst218) return; const f = frameHost.querySelector('iframe'); if (e.source !== (f && f.contentWindow)) return; const a = e.data.holst218; if (a === 'close') closePanel(); else if (a === 'hide') frameHost.style.opacity = '0'; else if (a === 'show') frameHost.style.opacity = '1'; });
  function playerButton() {
    const bar = document.querySelector('.ytp-right-controls'); if (!bar || bar.querySelector('.holst-ytp')) return;
    const b = document.createElement('button'); b.className = 'ytp-button holst-ytp'; b.title = 'В Холст'; b.setAttribute('aria-label', 'В Холст'); b.innerHTML = ICON; b.style.opacity = '.85';
    b.addEventListener('click', e => { e.stopPropagation(); frameHost ? closePanel() : openPanel({}); });
    bar.insertBefore(b, bar.firstChild);
  }
  /* watched to the end: «просмотрено» for videos Холст knows */
  const WATCHED = new Set();
  document.addEventListener('timeupdate', async e => {
    const v = e.target; if (!(v instanceof HTMLVideoElement) || !v.duration || v.currentTime / v.duration < 0.9) return; const id = vid(location.href); if (!id || WATCHED.has(id)) return; WATCHED.add(id);
    const r = await bg('yt-info', { id }); if (r && r.ok && r.data && (r.data.task || r.data.kb) && r.data.st216 !== 'просмотрено') bg('yt-status', { id, st: 'просмотрено' });
  }, true);
  /* ---------- many videos: playlists, channels, feeds ---------- */
  const CARDS = 'ytd-playlist-video-renderer, ytd-rich-item-renderer, ytd-grid-video-renderer, ytd-video-renderer, ytd-compact-video-renderer, yt-lockup-view-model';
  const cardVideo = c => {
    const a = c.querySelector('a[href*="/watch?v="], a[href*="/shorts/"]'); const id = a && vid(a.href); if (!id) return null;
    const t = c.querySelector('#video-title, h3 a, h3, [id="video-title-link"]'), ch = c.querySelector('ytd-channel-name a, #channel-name a, .yt-content-metadata-view-model-wiz__metadata-text, .yt-content-metadata-view-model__metadata-text');
    const av = c.querySelector('#avatar-link img, #avatar img, yt-decorated-avatar-view-model img, .yt-spec-avatar-shape__image'), d = c.querySelector('ytd-thumbnail-overlay-time-status-renderer #text, badge-shape .badge-shape-wiz__text, .yt-badge-shape__text');
    const title = ((t && (t.getAttribute('title') || t.textContent)) || '').trim() || 'Видео ' + id, chn = ch ? ch.textContent.trim() : '';
    return { id, title, channel: chn, meta: { yt: 1, id, thumb: 'https://i.ytimg.com/vi/' + id + '/hqdefault.jpg', ch: chn, chAv: av ? av.currentSrc || av.src || '' : '', dur: d ? secOf(d.textContent) : 0 } };
  };
  const isList = () => /\/playlist\?|\/(@[^/]+|channel\/[^/]+|c\/[^/]+|user\/[^/]+)\/(videos|streams|shorts|featured)?\/?$|\/results\?|^\/$|\/feed\/(subscriptions|history|playlists)/.test(location.pathname + location.search);
  function listButton() {
    let b = document.getElementById('holst-yt-list'); const show = isList() && !/\/feed\/channels/.test(location.pathname);
    if (!show) { if (b) b.remove(); return; }
    if (b) return; b = document.createElement('button'); b.id = 'holst-yt-list'; b.textContent = 'В Холст: видео этой страницы';
    b.style.cssText = 'position:fixed;left:16px;bottom:16px;z-index:2147483645;border:0;border-radius:18px;padding:9px 14px;background:#0f0f0f;color:#fff;font:600 13px Roboto,Arial,sans-serif;box-shadow:0 8px 24px -8px rgba(0,0,0,.5);cursor:pointer;opacity:.9';
    b.addEventListener('click', async () => { if (frameHost) { closePanel(); return; } const seen = new Set(), L = [...document.querySelectorAll(CARDS)].map(cardVideo).filter(v => v && !seen.has(v.id) && seen.add(v.id)); await chrome.storage.local.set({ many218: { videos: L, at: Date.now() } }); openPanel({ many: 1 }); });
    document.documentElement.appendChild(b);
  }
  function openMany(only) {
    const seen = new Set(), L = (only ? [only] : [...document.querySelectorAll(CARDS)].map(cardVideo)).filter(v => v && !seen.has(v.id) && seen.add(v.id));
    const p = panel(`<div class="h"><b>В Холст: ${L.length} видео</b><button class="x" title="Закрыть" aria-label="Закрыть">${XSVG}</button></div>
      ${only ? '' : `<label class="ck"><input type="checkbox" data-f="all" checked> Все</label>`}
      <div class="l">${L.map((v, i) => `<label><input type="checkbox" data-i="${i}" checked><span title="${esc(v.title)}">${esc(v.title)}</span></label>`).join('') || '<div class="st">Видео на странице не нашлось — прокрутите список, чтобы они загрузились.</div>'}</div>
      ${OPTS(null, true)}<button class="go">Сохранить выбранные</button><div data-f="res"></div>`, { left: 16, bottom: 64 });
    wireOpts(p);
    const all = p.querySelector('[data-f="all"]'); if (all) all.addEventListener('change', () => p.querySelectorAll('[data-i]').forEach(c => { c.checked = all.checked; }));
    p.querySelector('.go').addEventListener('click', async () => {
      const pick = [...p.querySelectorAll('[data-i]:checked')].map(c => L[+c.dataset.i]); if (!pick.length) return;
      const b = p.querySelector('.go'), o = optsOf(p); b.disabled = true; b.textContent = 'Сохраняю ' + pick.length + '…';
      const res = await bg('yt-add', Object.assign({ videos: pick }, o));
      p.querySelector('[data-f="res"]').innerHTML = res && res.ok ? `<div class="ok">Готово: ${res.data.task ? 'задач ' + res.data.task + ' ' : ''}${res.data.kb ? 'в источники ' + res.data.kb + ' ' : ''}${res.data.cap ? 'на разбор ' + res.data.cap : ''}</div>` : `<div class="err">${esc((res && res.data) || 'Холст не ответил')}</div>`;
      b.disabled = false; b.textContent = 'Сохранить выбранные';
    });
  }
  /* ---------- ⋮ under a video: «В Холст» without opening it ---------- */
  let lastCard = null;
  document.addEventListener('click', e => { const t = e.target; if (!t || !t.closest) return; if (t.closest('#holst-yt-mi')) return; const c = t.closest(CARDS); if (c && t.closest('ytd-menu-renderer, button[aria-label], yt-icon-button, .yt-lockup-metadata-view-model-wiz__menu-button, button-view-model')) { lastCard = c; setTimeout(() => tick(), 150); setTimeout(() => tick(), 500); } }, true);
  function menuItem() {
    const dd = [...document.querySelectorAll('tp-yt-iron-dropdown, ytd-popup-container yt-sheet-view-model, yt-contextual-sheet-layout')].find(d => d.getClientRects().length && getComputedStyle(d).display !== 'none' && d.getAttribute('aria-hidden') !== 'true');
    if (!dd || !lastCard) return; const list = dd.querySelector('tp-yt-paper-listbox#items, #items, yt-list-view-model'); if (!list || list.querySelector('#holst-yt-mi')) return;
    const v = cardVideo(lastCard); if (!v) return;
    const it = document.createElement('div'); it.id = 'holst-yt-mi'; it.setAttribute('role', 'menuitem'); it.tabIndex = 0;
    it.style.cssText = 'display:flex;align-items:center;gap:14px;padding:0 16px;height:36px;cursor:pointer;font:400 14px Roboto,Arial,sans-serif;color:var(--yt-spec-text-primary,#0f0f0f)';
    it.innerHTML = `<span style="width:24px;height:24px;display:inline-block;filter:var(--holst-ico,invert(1))">${ICON}</span><span>В Холст</span>`;
    if (document.documentElement.hasAttribute('dark')) it.querySelector('span').style.filter = 'none';
    it.addEventListener('mouseenter', () => { it.style.background = 'var(--yt-spec-10-percent-layer,#0000000d)'; }); it.addEventListener('mouseleave', () => { it.style.background = ''; });
    it.addEventListener('click', e => { e.stopPropagation(); document.body.click(); setTimeout(() => openPanel({ vid: v.id, vt: v.title, vch: v.channel || '' }), 60); });
    list.insertBefore(it, list.firstChild);
  }
  /* ---------- subscriptions: weights of channels ---------- */
  function subsButton() {
    let b = document.getElementById('holst-yt-subs'); const show = /\/feed\/channels/.test(location.pathname);
    if (!show) { if (b) b.remove(); return; } if (b) return;
    b = document.createElement('button'); b.id = 'holst-yt-subs'; b.textContent = 'В Холст: веса каналов';
    b.style.cssText = 'position:fixed;left:16px;bottom:16px;z-index:2147483645;border:0;border-radius:18px;padding:9px 14px;background:#0f0f0f;color:#fff;font:600 13px Roboto,Arial,sans-serif;box-shadow:0 8px 24px -8px rgba(0,0,0,.5);cursor:pointer;opacity:.9';
    b.addEventListener('click', () => (host ? close() : openSubs())); document.documentElement.appendChild(b);
  }
  async function openSubs() {
    const seen = new Set(), L = [...document.querySelectorAll('ytd-channel-renderer')].map(c => { const a = c.querySelector('a#main-link, a[href^="/@"], a[href*="/channel/"]'), n = c.querySelector('#channel-title, #text'); return a ? { url: new URL(a.getAttribute('href'), location.origin).href.replace(/\/$/, ''), name: (n && n.textContent.trim()) || a.textContent.trim() } : null; }).filter(c => c && !seen.has(c.url) && seen.add(c.url));
    const k = await bg('yt-known'), known = (k && k.ok && k.data.ch) || [], comps = (k && k.ok && k.data.comps) || [], key = u => u.replace(/^https?:\/\/(www\.)?/, '').toLowerCase().replace(/\/$/, '');
    const p = panel(`<div class="h"><b>Каналы как источники: ${L.length}</b><button class="x" title="Закрыть" aria-label="Закрыть">${XSVG}</button></div>
      <div class="st">Вес — насколько доверять каналу в «Источниках» Холста (0–100). Отметьте, какие каналы взять в источники; уже взятые — с весом.</div>
      <div class="l" style="max-height:340px">${L.map((c, i) => { const kn = known.find(x => key(x.url) === key(c.url)); return `<label><input type="checkbox" data-i="${i}"${kn ? ' checked disabled' : ''}><span title="${esc(c.name)}">${esc(c.name)}</span><input type="number" min="0" max="100" step="5" data-w="${i}" value="${kn ? kn.w : 60}"></label>`; }).join('') || '<div class="st">Каналы не нашлись — прокрутите список подписок.</div>'}</div>
      ${comps.length ? `<label>Компетенция для отмеченных<select data-f="comp"><option value="">Определит Холст</option>${comps.map(c => `<option value="${esc(c.k)}">${esc(c.l)}</option>`).join('')}</select></label>` : ''}
      <button class="go">Сохранить веса и источники</button><div data-f="res"></div>`, { left: 16, bottom: 64 });
    p.querySelector('.go').addEventListener('click', async () => {
      const comp = (p.querySelector('[data-f="comp"]') || {}).value || '';
      const list = L.map((c, i) => ({ url: c.url, name: c.name, w: +p.querySelector(`[data-w="${i}"]`).value, kb: p.querySelector(`[data-i="${i}"]`).checked, comp })).filter(c => c.kb || known.some(x => key(x.url) === key(c.url)));
      const res = await bg('yt-channels', { list });
      p.querySelector('[data-f="res"]').innerHTML = res && res.ok ? `<div class="ok">Обновлено весов: ${res.data.n}, новых источников: ${res.data.add}</div>` : `<div class="err">${esc((res && res.data) || 'Холст не ответил')}</div>`;
    });
  }

  /* ---------- v2.20: the timeline — watched zones and moments ---------- */
  const fmt = t => { t = Math.max(0, Math.floor(t || 0)); const h = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60), x = t % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0'); };
  const mainVideo = () => document.querySelector('#movie_player video.html5-main-video') || document.querySelector('video.html5-main-video') || document.querySelector('#movie_player video');
  const zMergeL = (a, b) => { const L = (a || []).concat(b || []).map(z => [+z[0], +z[1]]).filter(z => z[1] > z[0]).sort((p, q) => p[0] - q[0]), out = []; for (const z of L) { const l = out[out.length - 1]; if (l && z[0] <= l[1] + 2) l[1] = Math.max(l[1], z[1]); else out.push(z.slice()); } return out; };
  const zLocal = v => { const z = []; try { for (let i = 0; i < v.played.length; i++) z.push([Math.floor(v.played.start(i)), Math.ceil(v.played.end(i))]); } catch (e) { /* no ranges */ } return z; };
  let YW = { id: '', d: 0, z: [], mom: [], ab: null, sent: 0 };
  function hToast(t) { let d = document.getElementById('holst-toast'); if (!d) { d = document.createElement('div'); d.id = 'holst-toast'; d.style.cssText = 'position:fixed;left:50%;bottom:90px;transform:translateX(-50%);z-index:2147483646;background:#0f0f0f;color:#fff;padding:8px 14px;border-radius:18px;font:500 13px Roboto,Arial,sans-serif;box-shadow:0 8px 24px -8px rgba(0,0,0,.5);transition:opacity .2s'; document.documentElement.appendChild(d); } d.textContent = t; d.style.opacity = '1'; clearTimeout(d._t); d._t = setTimeout(() => { d.style.opacity = '0'; }, 2600); }
  async function ytLoad(id) {
    YW = { id, d: 0, z: [], mom: [], ab: null, sent: 0 }; const k = 'yw:' + id, st = await chrome.storage.local.get(k).catch(() => ({})), o = st[k]; if (o) { YW.d = o.d || 0; YW.z = o.z || []; }
    const r = await bg('yt-moments', { id }); if (YW.id !== id) return; if (r && r.ok && r.data) { YW.mom = r.data.list || []; if (r.data.w && r.data.w.z) YW.z = zMergeL(YW.z, r.data.w.z); } drawTl();
  }
  function drawTl() {
    const v = mainVideo(), bar = document.querySelector('#movie_player .ytp-progress-bar-container'); if (!v || !bar || !YW.id) return;
    let tl = bar.querySelector('.holst-tl'); if (!tl) { tl = document.createElement('div'); tl.className = 'holst-tl'; tl.style.cssText = 'position:absolute;left:0;right:0;bottom:calc(100% + 2px);height:3px;pointer-events:none;z-index:45';
      tl.addEventListener('click', e => { const b = e.target.closest('[data-hm]'); if (!b) return; e.stopPropagation(); const m = YW.mom[+b.dataset.hm], w = mainVideo(); if (m && w) w.currentTime = m.s; }, true); bar.appendChild(tl); }
    const d = isFinite(v.duration) && v.duration ? v.duration : YW.d; if (!d) return; const Z = zMergeL(YW.z, zLocal(v));
    tl.innerHTML = Z.map(z => `<i style="position:absolute;top:0;height:3px;left:${(z[0] / d * 100).toFixed(3)}%;width:${((z[1] - z[0]) / d * 100).toFixed(3)}%;background:#2fa36b;border-radius:2px"></i>`).join('')
      + (YW.ab && YW.ab.b != null ? `<i style="position:absolute;top:-2px;height:7px;left:${(YW.ab.a / d * 100).toFixed(3)}%;width:${((YW.ab.b - YW.ab.a) / d * 100).toFixed(3)}%;border:1px solid #ffd84d;border-radius:3px"></i>` : '')
      + YW.mom.map((m, i) => `<b data-hm="${i}" title="${esc(fmt(m.s) + ' — ' + m.t)}" style="position:absolute;bottom:5px;left:${Math.min(100, m.s / d * 100).toFixed(3)}%;width:9px;height:9px;margin-left:-4.5px;border-radius:50%;background:${m.ai ? '#a855f7' : '#ffd84d'};border:1px solid rgba(0,0,0,.5);pointer-events:auto;cursor:pointer"></b>`).join('');
  }
  async function sendWatch(force) {
    const v = mainVideo(), id = vid(location.href); if (!v || !id || id !== YW.id || !isFinite(v.duration) || !v.duration) return;
    const z = zMergeL(YW.z, zLocal(v)); if (!force && Date.now() - YW.sent < 15000) return; YW.sent = Date.now(); YW.z = z; YW.d = v.duration;
    const r = await bg('yt-watch', { id, d: Math.round(v.duration), z }); if (r && r.ok && r.data && r.data.z) YW.z = zMergeL(YW.z, r.data.z); drawTl();
  }
  setInterval(() => { const id = vid(location.href); if (!id || !/\/watch|\/live\//.test(location.pathname)) return; if (id !== YW.id) { ytLoad(id); return; } const v = mainVideo(); if (v && !v.paused) { sendWatch(false); drawTl(); } if (YW.ab && YW.ab.b != null && v && v.currentTime > YW.ab.b) v.currentTime = YW.ab.a; }, 2500);
  document.addEventListener('pause', e => { if (e.target instanceof HTMLVideoElement) sendWatch(true); }, true);
  document.addEventListener('ended', e => { if (e.target instanceof HTMLVideoElement) sendWatch(true); }, true);
  addEventListener('beforeunload', () => sendWatch(true));
  /* the moment: a button next to the time, Alt+N */
  const MOM = '<svg viewBox="0 0 24 24" width="100%" height="100%" fill="none" stroke="#fff" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M7 4h10a1 1 0 0 1 1 1v15l-6-4-6 4V5a1 1 0 0 1 1-1z"/><path d="M12 8v5M9.5 10.5h5"/></svg>';
  function momentBtn() {
    const bar = document.querySelector('#movie_player .ytp-left-controls'); if (!bar || bar.querySelector('.holst-mom')) return;
    const b = document.createElement('button'); b.className = 'ytp-button holst-mom'; b.title = 'Момент в Холст: заметка, задача, вопрос, кадр (Alt+N)'; b.setAttribute('aria-label', 'Момент в Холст'); b.innerHTML = `<span style="display:inline-block;width:24px;height:24px;margin:12px">${MOM}</span>`; b.style.opacity = '.85';
    b.addEventListener('click', e => { e.stopPropagation(); host ? close() : openMoment(); }); bar.appendChild(b);
  }
  function openMoment() {
    const v = mainVideo(), id = vid(location.href); if (!v || !id) return; const t = Math.floor(v.currentTime), cv = curVideo();
    const p = panel(`<div class="h"><b>Момент ${fmt(t)}</b><button class="x" title="Закрыть" aria-label="Закрыть">${XSVG}</button></div>
      <div class="seg" data-s="k"><button data-v="note" class="on">Заметка</button><button data-v="task">Задача</button><button data-v="q">Вопрос</button></div>
      <textarea data-f="t" placeholder="Что здесь важно — или вопрос нейросети"></textarea>
      <button class="go" data-a="save">Сохранить момент</button>
      <div class="row" style="flex-wrap:wrap"><button class="go" style="background:#7b61ff;flex:1" data-a="ask">Спросить нейросеть</button><button class="go" style="background:#2fa36b;flex:1" data-a="frame">Кадр к объекту</button></div>
      <div class="seg"><button data-a="ab">${YW.ab ? (YW.ab.b == null ? 'Конец повтора здесь' : 'Убрать повтор') : 'Повтор: начало здесь'}</button><button data-a="next">К следующему моменту</button></div>
      <div data-f="res" class="st">Ваши моменты — жёлтые точки на таймлайне, моменты нейросети — фиолетовые.</div>`, { left: 16, bottom: 90 });
    const res = p.querySelector('[data-f="res"]'), txt = () => p.querySelector('[data-f="t"]').value.trim();
    setTimeout(() => p.querySelector('[data-f="t"]').focus(), 30);
    p.querySelector('[data-f="t"]').addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) p.querySelector('[data-a="save"]').click(); });
    p.addEventListener('click', async e => { const b = e.target.closest('[data-a]'); if (!b) return; const a = b.dataset.a;
      if (a === 'save') { const x = txt(); if (!x) { res.textContent = 'Напишите, что здесь важно'; return; } b.disabled = true; const r = await bg('yt-moment', { id, s: t, text: x, kind: segVal('[data-s="k"]') || 'note', title: cv && cv.title }); b.disabled = false; if (r && r.ok) { YW.mom.push({ s: t, t: x, ai: false }); drawTl(); res.innerHTML = '<span class="ok">' + (r.queued ? 'Холст закрыт — момент в очереди' : 'Сохранено в задачник') + '</span>'; setTimeout(close, 900); } else res.innerHTML = '<span class="err">' + esc((r && (r.data && r.data.err || r.data)) || 'не получилось') + '</span>'; }
      else if (a === 'ask') { const q = txt() || 'Что здесь главное?'; b.disabled = true; res.textContent = 'Нейросеть читает расшифровку вокруг момента…'; const r = await bg('yt-ask', { id, s: t, q, title: cv && cv.title }); b.disabled = false; if (r && r.ok && r.data && r.data.text) { res.innerHTML = '<div style="white-space:pre-wrap;color:inherit">' + esc(r.data.text) + '</div><div class="ok">Ответ сохранён заметкой на этот момент</div>'; YW.mom.push({ s: t, t: q, ai: true }); drawTl(); } else res.innerHTML = '<span class="err">' + esc((r && r.data && (r.data.err || r.data.message)) || (r && r.data) || 'нейросеть не ответила') + '</span>'; }
      else if (a === 'frame') { let img = '', iw = 16, ih = 9; try { const c = document.createElement('canvas'); iw = c.width = v.videoWidth; ih = c.height = v.videoHeight; c.getContext('2d').drawImage(v, 0, 0); img = c.toDataURL('image/jpeg', 0.85); } catch (er) { res.innerHTML = '<span class="err">Кадр не снялся — видео защищено</span>'; return; } b.disabled = true; res.textContent = 'Ищу объект этого видео на досках…'; const r = await bg('yt-attach', { id, s: t, image: img, iw, ih, text: txt(), title: cv && cv.title }); b.disabled = false; res.innerHTML = r && r.ok && r.data && r.data.ok ? `<span class="ok">Кадр — к объекту на доске «${esc(r.data.where)}»</span>` : `<span class="err">${esc((r && r.data && r.data.err) || 'не получилось')}. Сохраните видео на доску — кнопкой Холста в плеере.</span>`; }
      else if (a === 'ab') { if (!YW.ab) YW.ab = { a: t, b: null }; else if (YW.ab.b == null && t > YW.ab.a) YW.ab.b = t; else YW.ab = null; drawTl(); close(); hToast(!YW.ab ? 'Повтор убран' : YW.ab.b == null ? 'Начало повтора: ' + fmt(t) + '. Нажмите ещё раз в конце' : 'Повтор ' + fmt(YW.ab.a) + '–' + fmt(YW.ab.b)); }
      else if (a === 'next') { const n = YW.mom.filter(m => m.s > t + 1).sort((x, y) => x.s - y.s)[0]; if (n) { v.currentTime = n.s; close(); } else res.textContent = 'Дальше моментов нет'; }
    });
  }
  addEventListener('keydown', e => { if (!e.altKey || e.ctrlKey || e.metaKey || /input|textarea/i.test((e.target && e.target.tagName) || '') || (e.target && e.target.isContentEditable)) return; const k = e.code;
    if (k === 'KeyN' && vid(location.href)) { e.preventDefault(); e.stopPropagation(); host ? close() : openMoment(); }
    if (k === 'KeyS' && vid(location.href)) { e.preventDefault(); e.stopPropagation(); const v = curVideo(); if (v) bg('yt-add', { videos: [v], kb: true, task: true, w: 60, intent: '', st: '', act: '', tag: false }).then(r => hToast(r && r.ok ? (r.queued ? 'В очереди — уйдёт в Холст сам' : 'Сохранено в Холст') : 'Холст не ответил')); } }, true);
  /* ---------- the feed: sorted by Холст, marks on covers, «+» on a cover ---------- */
  let SYS = { v: {}, ch: {} }, YWALL = {};
  async function sysLoad() { const all = await chrome.storage.local.get(null).catch(() => ({})); SYS = all.sys220 || { v: {}, ch: {} }; YWALL = {}; for (const k of Object.keys(all)) if (k.startsWith('yw:')) { const o = all[k]; YWALL[k.slice(3)] = o.d ? Math.min(100, Math.round(o.z.reduce((s, z) => s + z[1] - z[0], 0) / o.d * 100)) : 0; } }
  chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && Object.keys(ch).some(k => k === 'sys220' || k.startsWith('yw:'))) sysLoad().then(() => { marks(true); }); });
  sysLoad();
  const seenOf = id => Math.max(YWALL[id] || 0, (SYS.v[id] || {}).seen || 0);
  const chKey = c => { const a = c.querySelector('a[href^="/@"], a[href*="/channel/"]'); return a ? ('youtube.com' + new URL(a.getAttribute('href'), location.origin).pathname).toLowerCase().replace(/\/$/, '') : ''; };
  const isFeed = () => /^\/$|^\/feed\/subscriptions|^\/results|\/(videos|streams)\/?$|^\/playlist/.test(location.pathname);
  let SORT = { by: '', hide: 0, only: '' }; chrome.storage.local.get('ytSort220').then(r => { if (r.ytSort220) SORT = r.ytSort220; });
  function sortBar() {
    let b = document.getElementById('holst-yt-sort'); if (!isFeed()) { if (b) b.remove(); return; } if (b) return;
    b = document.createElement('div'); b.id = 'holst-yt-sort'; b.style.cssText = 'position:fixed;left:16px;bottom:64px;z-index:2147483645;display:flex;gap:6px;align-items:center;background:#0f0f0f;color:#fff;border-radius:18px;padding:5px 8px 5px 12px;font:500 12.5px Roboto,Arial,sans-serif;box-shadow:0 8px 24px -8px rgba(0,0,0,.5);opacity:.92';
    b.innerHTML = `<span>Холст:</span><select data-s="by" style="background:#272727;color:#fff;border:0;border-radius:10px;padding:3px 6px;font:inherit">${[['', 'порядок YouTube'], ['w', 'по весу'], ['imp', 'по важности'], ['st', 'по статусу'], ['seen', 'меньше просмотрено'], ['ch', 'по весу канала'], ['in', 'сначала из Холста']].map(([k, l]) => `<option value="${k}"${SORT.by === k ? ' selected' : ''}>${l}</option>`).join('')}</select><label style="display:flex;gap:4px;align-items:center;cursor:pointer"><input type="checkbox" data-s="hide"${SORT.hide ? ' checked' : ''}>скрыть досмотренное</label><select data-s="only" style="background:#272727;color:#fff;border:0;border-radius:10px;padding:3px 6px;font:inherit">${[['', 'все'], ['in', 'только из Холста'], ['new', 'только новые']].map(([k, l]) => `<option value="${k}"${SORT.only === k ? ' selected' : ''}>${l}</option>`).join('')}</select>`;
    b.addEventListener('change', e => { const t = e.target; if (t.dataset.s === 'hide') SORT.hide = t.checked ? 1 : 0; else SORT[t.dataset.s] = t.value; chrome.storage.local.set({ ytSort220: SORT }); applySort(); });
    document.documentElement.appendChild(b);
  }
  const ST_ORD = { 'в работе': 0, 'новое': 1, 'просмотрено': 2, 'разобрано': 3, 'архив': 4 };
  function applySort() {
    if (!isFeed()) return; const cards = [...document.querySelectorAll('ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer, ytd-playlist-video-renderer')];
    const by = new Map(); for (const c of cards) { const p = c.parentElement; if (!by.has(p)) by.set(p, []); by.get(p).push(c); }
    for (const [par, L] of by) {
      const flex = /flex|grid/.test(getComputedStyle(par).display);
      const key = c => { const v = cardVideo(c), P = v && SYS.v[v.id] && SYS.v[v.id].in ? SYS.v[v.id] : null, seen = v ? seenOf(v.id) : 0; return { P, seen, w: P ? (+P.w || 0) : -1, imp: P ? (+P.imp || 0) : -1, st: P && P.st in ST_ORD ? ST_ORD[P.st] : 9, ch: SYS.ch[chKey(c)] != null ? +SYS.ch[chKey(c)] : -1 }; };
      const K = L.map((c, i) => ({ c, i, k: key(c) }));
      for (const x of K) { const hide = (SORT.hide && x.k.seen >= 90) || (SORT.only === 'in' && !x.k.P) || (SORT.only === 'new' && (x.k.P || x.k.seen >= 20)); x.c.style.display = hide ? 'none' : ''; }
      const cmp = { w: (a, b) => b.k.w - a.k.w, imp: (a, b) => b.k.imp - a.k.imp, st: (a, b) => a.k.st - b.k.st, seen: (a, b) => a.k.seen - b.k.seen, ch: (a, b) => b.k.ch - a.k.ch, in: (a, b) => (!!b.k.P) - (!!a.k.P) }[SORT.by];
      const S2 = cmp ? K.slice().sort((a, b) => cmp(a, b) || a.i - b.i) : K;
      if (flex) S2.forEach((x, n) => { x.c.style.order = cmp ? String(n) : ''; });
    }
  }
  function marks(force) {
    for (const c of document.querySelectorAll(CARDS)) {
      const v = cardVideo(c); if (!v) continue; const P0 = SYS.v[v.id], P = P0 && P0.in ? P0 : null, seen = seenOf(v.id), sig = (P ? 'p' + (P.w || '') + (P.imp || '') + (P.st || '') : '') + '|' + seen;
      const th = c.querySelector('ytd-thumbnail, yt-thumbnail-view-model, a#thumbnail, .yt-lockup-view-model-wiz__content-image, .yt-lockup-view-model__content-image'); if (!th) continue;
      if (!th.dataset.holstPos) { th.dataset.holstPos = '1'; if (getComputedStyle(th).position === 'static') th.style.position = 'relative'; }
      if (!th.querySelector('.holst-add')) { const a = document.createElement('button'); a.className = 'holst-add'; a.title = 'В Холст — сразу, с весом 60'; a.textContent = '+'; a.style.cssText = 'position:absolute;right:6px;top:6px;z-index:5;width:26px;height:26px;border-radius:50%;border:0;background:rgba(15,15,15,.85);color:#fff;font:700 17px/26px Roboto,Arial;cursor:pointer;opacity:0;transition:opacity .12s';
        a.addEventListener('click', async e => { e.preventDefault(); e.stopPropagation(); const vv = cardVideo(c); if (!vv) return; a.textContent = '…'; const r = await bg('yt-add', { videos: [vv], kb: true, task: true, w: 60, intent: '', st: '', act: '', tag: false }); a.textContent = r && r.ok ? '✓' : '!'; a.title = r && r.ok ? (r.queued ? 'В очереди — уйдёт сам' : 'В Холсте') : 'Холст не ответил'; }, true);
        th.addEventListener('mouseenter', () => { a.style.opacity = '1'; }); th.addEventListener('mouseleave', () => { if (a.textContent === '+') a.style.opacity = '0'; }); th.appendChild(a); }
      if (!force && th.dataset.holstB === sig) continue; th.dataset.holstB = sig;
      let m = th.querySelector('.holst-b'); if (!P && !seen) { if (m) m.remove(); continue; }
      if (!m) { m = document.createElement('div'); m.className = 'holst-b'; m.style.cssText = 'position:absolute;left:0;right:0;top:0;bottom:0;pointer-events:none;z-index:4'; th.appendChild(m); }
      m.innerHTML = (P ? `<span style="position:absolute;left:6px;top:6px;background:#ffd84d;color:#3d2f00;border-radius:9px;padding:1px 7px;font:700 11px/18px Roboto,Arial">Холст${P.imp ? ' ★' + P.imp : P.w != null ? ' ' + P.w : ''}</span>` : '') + (seen ? `<i style="position:absolute;left:0;bottom:0;height:4px;width:${seen}%;background:#2fa36b"></i>` : '');
    }
  }
  /* a channel or a playlist into sources — with the plan of the analysis in Холст */
  function srcButton() {
    let b = document.getElementById('holst-yt-src'); const ch = /^\/(@[^/]+|channel\/[^/]+|c\/[^/]+|user\/[^/]+)/.test(location.pathname), pl = /^\/playlist/.test(location.pathname) && /list=/.test(location.search);
    if (!ch && !pl) { if (b) b.remove(); return; } const want = ch ? 'ch' : 'pl'; if (b && b.dataset.k === want) return; if (b) b.remove();
    b = document.createElement('button'); b.id = 'holst-yt-src'; b.dataset.k = want; b.textContent = ch ? 'Канал — в источники Холста' : 'Плейлист — в источники Холста'; b.title = 'Холст покажет план разбора: что брать, сколько и сколько токенов — до запуска нейросети';
    b.style.cssText = 'position:fixed;left:16px;bottom:112px;z-index:2147483645;border:0;border-radius:18px;padding:9px 14px;background:#7b61ff;color:#fff;font:600 13px Roboto,Arial,sans-serif;box-shadow:0 8px 24px -8px rgba(0,0,0,.5);cursor:pointer;opacity:.92';
    b.addEventListener('click', async () => { const url = ch ? location.origin + location.pathname.match(/^\/(@[^/]+|channel\/[^/]+|c\/[^/]+|user\/[^/]+)/)[0] : location.href; b.disabled = true; b.textContent = 'Открываю план в Холсте…'; const r = await bg('kb-add', { url }); b.disabled = false; b.textContent = r && r.ok ? 'План разбора — в Холсте' : 'Холст не ответил'; });
    document.documentElement.appendChild(b);
  }
  /* YouTube changes pages without reloading */
  const tick = () => { playerButton(); listButton(); subsButton(); menuItem(); momentBtn(); sortBar(); srcButton(); marks(false); if (SORT.by || SORT.hide || SORT.only) applySort(); if (YW.id) drawTl(); };
  document.addEventListener('yt-navigate-finish', () => { close(); closePanel(); setTimeout(tick, 400); });
  new MutationObserver(() => { clearTimeout(tick.t); tick.t = setTimeout(tick, 150); }).observe(document.documentElement, { childList: true, subtree: true });
  tick();
})();
