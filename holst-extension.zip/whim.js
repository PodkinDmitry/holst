/* Холст 2.23 — Whimsical: the formatting of a whole board without Ctrl+A and Ctrl+C.
   Холст asks the extension; the extension opens the board, selects everything and takes the copy that
   Whimsical itself puts into the clipboard — straight from its copy event, the clipboard is not touched. */
(() => {
  if (window.__holstWhim) return; window.__holstWhim = 1;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const key = (t, k, code) => { for (const meta of [false, true]) t.dispatchEvent(new KeyboardEvent('keydown', { key: k, code, keyCode: k.toUpperCase().charCodeAt(0), which: k.toUpperCase().charCodeAt(0), ctrlKey: !meta, metaKey: meta, bubbles: true, cancelable: true, composed: true })); };
  function copyNow() {
    let got = null;
    const cap = e => { setTimeout(() => {}, 0); const dt = e.clipboardData; if (dt) { const h = dt.getData('text/html'); if (h && h.includes('data-whi-clipboard')) got = { html: h, txt: dt.getData('text/plain') }; } };
    document.addEventListener('copy', cap, false);
    for (const t of [document.activeElement, document.querySelector('canvas'), document.body, document].filter(Boolean)) {
      const dt = new DataTransfer(); const ev = new ClipboardEvent('copy', { clipboardData: dt, bubbles: true, cancelable: true, composed: true });
      t.dispatchEvent(ev);
      const h = dt.getData('text/html'); if (h && h.includes('data-whi-clipboard')) { got = { html: h, txt: dt.getData('text/plain') }; break; }
      if (got) break;
    }
    document.removeEventListener('copy', cap, false);
    return got;
  }
  async function grab() {
    const t0 = Date.now();
    while (Date.now() - t0 < 30000 && !document.querySelector('canvas, [data-testid*="board"], [class*="Board"], [class*="canvas"]')) await sleep(400);
    await sleep(2500);
    for (let i = 0; i < 6; i++) {
      try { window.focus(); document.body.focus(); } catch (e) { /* ignore */ }
      for (const t of [document.activeElement, document.querySelector('canvas'), document.body, document, window].filter(Boolean)) key(t, 'a', 'KeyA');
      await sleep(500);
      const g = copyNow(); if (g) return Object.assign({ ok: true }, g);
      await sleep(1200);
    }
    return { ok: false, err: 'Whimsical не отдал копию' };
  }
  chrome.runtime.onMessage.addListener((m, s, reply) => { if (!m || m.op !== 'whim-grab') return; grab().then(reply, e => reply({ ok: false, err: String(e && e.message || e) })); return true; });
})();
