/* A task widget on any site: drag it, resize it, switch «this page» / «whole task manager». */
(() => {
  if (window.top !== window || window.__holstWidget) return; window.__holstWidget = 1;
  const bg = (op, data) => chrome.runtime.sendMessage({ to: 'bg', op, data });
  let host, root, rule, key, list = [];
  async function find() {
    const W = (await chrome.storage.local.get('widgets')).widgets || {};
    const p = 'page:' + location.href, s = 'site:' + location.hostname;
    if (W[p] && W[p].on) return [p, W[p]]; if (W[s] && W[s].on) return [s, W[s]]; return [null, null];
  }
  async function save() { const W = (await chrome.storage.local.get('widgets')).widgets || {}; if (W[key]) { W[key] = rule; await chrome.storage.local.set({ widgets: W }); } }
  async function mount() {
    [key, rule] = await find();
    if (!rule) { if (host) { host.remove(); host = null; } return; }
    if (!host) {
      host = document.createElement('div'); host.style.cssText = 'all:initial;position:fixed;z-index:2147483646'; document.documentElement.appendChild(host);
      root = host.attachShadow({ mode: 'open' });
      root.innerHTML = `<style>
        .w{position:fixed;width:300px;height:360px;min-width:220px;min-height:140px;resize:both;overflow:hidden;display:flex;flex-direction:column;background:#fff;color:#1c1d21;border:1px solid #e3e5ea;border-radius:12px;box-shadow:0 12px 40px -12px rgba(0,0,0,.35);font:13px/1.35 system-ui,"Segoe UI",sans-serif}
        .h{display:flex;align-items:center;gap:6px;padding:7px 8px 7px 10px;background:#1c1d21;color:#fff;cursor:move;user-select:none}.h b{font-size:12.5px;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        .h button{border:0;background:rgba(255,255,255,.12);color:#fff;border-radius:6px;padding:3px 7px;font:600 11px system-ui;cursor:pointer}.h button.on{background:#ffd84d;color:#1c1d21}
        .l{flex:1;overflow:auto;padding:4px 6px}.r{display:flex;gap:7px;align-items:flex-start;padding:5px 4px;border-radius:7px}.r:hover{background:#f1f2f5}.r input{margin:2px 0 0}.r span{flex:1}.r small{display:block;color:#8a90a0;font-size:11px}.dn span{text-decoration:line-through;color:#8a90a0}
        form{display:flex;gap:6px;padding:6px;border-top:1px solid #e3e5ea}form input{flex:1;height:30px;border:1px solid #e3e5ea;border-radius:8px;padding:0 8px;font:inherit}
        .e{color:#8a90a0;padding:12px 8px;font-size:12px}.min .l,.min form{display:none}.min{height:auto!important;resize:none}
        @media (prefers-color-scheme:dark){.w{background:#212329;color:#e6e7ea;border-color:#33363c}.r:hover{background:#2b2e35}form{border-color:#33363c}form input{background:#2b2e35;color:#e6e7ea;border-color:#33363c}}
      </style><div class="w"><div class="h"><b>Холст</b><button data-a="page">Эта страница</button><button data-a="all">Всё</button><button data-a="min" title="Свернуть">–</button><button data-a="x" title="Скрыть на этом сайте">✕</button></div><div class="l"></div><form><input placeholder="+ задача к этой странице"></form></div>`;
      const w = root.querySelector('.w');
      w.style.left = (rule.x != null ? rule.x : innerWidth - 330) + 'px'; w.style.top = (rule.y != null ? rule.y : 90) + 'px'; if (rule.w) w.style.width = rule.w + 'px'; if (rule.h) w.style.height = rule.h + 'px';
      root.querySelector('.h').addEventListener('pointerdown', e => {
        if (e.target.closest('button')) return; e.preventDefault(); const x0 = e.clientX - w.offsetLeft, y0 = e.clientY - w.offsetTop;
        const mv = ev => { w.style.left = Math.max(0, Math.min(innerWidth - 60, ev.clientX - x0)) + 'px'; w.style.top = Math.max(0, Math.min(innerHeight - 30, ev.clientY - y0)) + 'px'; };
        const up = () => { removeEventListener('pointermove', mv); removeEventListener('pointerup', up); rule.x = w.offsetLeft; rule.y = w.offsetTop; save(); };
        addEventListener('pointermove', mv); addEventListener('pointerup', up);
      });
      new ResizeObserver(() => { clearTimeout(w._t); w._t = setTimeout(() => { if (w.classList.contains('min')) return; rule.w = w.offsetWidth; rule.h = w.offsetHeight; save(); }, 400); }).observe(w);
      root.addEventListener('click', async e => {
        const b = e.target.closest('button[data-a]'); if (!b) return; const a = b.dataset.a;
        if (a === 'page' || a === 'all') { rule.mode = a; save(); load(); }
        else if (a === 'min') { w.classList.toggle('min'); }
        else if (a === 'x') { rule.on = 0; save(); host.remove(); host = null; }
      });
      root.addEventListener('change', async e => { const c = e.target.closest('input[data-id]'); if (!c) return; await bg('set', { id: c.dataset.id, patch: { st: c.checked ? 'done' : 'todo' } }); load(); });
      root.querySelector('form').addEventListener('submit', async e => { e.preventDefault(); const i = e.target.querySelector('input'), t = i.value.trim(); if (!t) return; i.value = ''; await bg('clip', { kind: 'task', title: t, url: location.href, site: location.hostname }); rule.mode === 'all' || load(); load(); });
    }
    load();
  }
  async function load() {
    if (!root) return;
    root.querySelectorAll('button[data-a="page"],button[data-a="all"]').forEach(b => b.classList.toggle('on', b.dataset.a === rule.mode));
    const l = root.querySelector('.l'); l.innerHTML = '<div class="e">Загружаю из Холста…</div>';
    let r = null; for (let k = 0; k < 3 && !(r && r.ok); k++) { if (k) await new Promise(ok => setTimeout(ok, 2500)); r = await bg('list', { mode: rule.mode, url: location.href, scope: rule.scope }).catch(() => null); }
    if (!r || !r.ok) { l.innerHTML = '<div class="e">Холст не ответил. Откройте Холст во вкладке — расширение подхватит.</div>'; return; }
    list = r.data || [];
    l.innerHTML = list.length ? list.map(t => `<label class="r${t.st === 'done' ? ' dn' : ''}"><input type="checkbox" data-id="${t.id}"${t.st === 'done' ? ' checked' : ''}><span>${esc(t.t)}<small>${[t.due, t.par].filter(Boolean).map(esc).join(' · ')}</small></span></label>`).join('') : `<div class="e">${rule.mode === 'page' ? 'К этой странице задач нет. Добавьте ниже или через значок расширения.' : 'Открытых задач нет.'}</div>`;
  }
  const esc = s => String(s || '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  chrome.runtime.onMessage.addListener(m => { if (m && m.op === 'widget-refresh') mount(); });
  /* v2.16: sites that change pages without reloading (YouTube, Notion, Gmail…) — the widget follows */
  let href = location.href; setInterval(() => { if (location.href !== href) { href = location.href; mount(); } }, 1000);
  addEventListener('popstate', () => mount()); document.addEventListener('yt-navigate-finish', () => mount());
  mount();
})();
