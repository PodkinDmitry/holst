/* Холст: a widget on any site (v2.17) — everything about this page from the task manager:
   tasks, notes, materials, projects… Add any kind right here. Drag it, resize it.
   It survives updates of the extension: an old copy left by the previous version is replaced. */
(() => {
  if (window.top !== window) return;
  const ME = (window.__holstWidget = (typeof window.__holstWidget === 'number' ? window.__holstWidget : 0) + 1);
  const alive = () => { try { return !!chrome.runtime.id && window.__holstWidget === ME; } catch (e) { return false; } };
  const bg = (op, data) => chrome.runtime.sendMessage({ to: 'bg', op, data });
  const I = { min: '<path d="M6 12h12"/>', close: '<path d="M6 6l12 12M18 6L6 18"/>', plus: '<path d="M12 5v14M5 12h14"/>', open: '<path d="M14 4h6v6M20 4l-9 9"/><path d="M18 14v4.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 4 18.5v-11A1.5 1.5 0 0 1 5.5 6H10"/>' };
  const svg = n => `<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${I[n]}</svg>`;
  const KINDS = [['task', 'Задача', '#2fa36b'], ['note', 'Заметка', '#6b7080'], ['resource', 'Материал', '#897a5f'], ['project', 'Проект', '#3355ff'], ['goal', 'Цель', '#d6409f'], ['habit', 'Привычка', '#d9a300']];
  let host, root, rule, key, list = [];
  async function find() {
    const W = (await chrome.storage.local.get('widgets')).widgets || {};
    const p = 'page:' + location.href, s = 'site:' + location.hostname;
    if (W[p] && W[p].on) return [p, W[p]]; if (W[s] && W[s].on) return [s, W[s]]; return [null, null];
  }
  async function save() { if (!alive()) return; const W = (await chrome.storage.local.get('widgets')).widgets || {}; if (W[key]) { W[key] = rule; await chrome.storage.local.set({ widgets: W }); } }
  const drop = () => { document.querySelectorAll('[data-holst-widget]').forEach(h => { if (h !== host) h.remove(); }); };
  async function mount() {
    if (!alive()) return;
    [key, rule] = await find();
    if (!rule) { if (host) { host.remove(); host = null; } return; }
    drop();
    if (!host || !host.isConnected) {
      host = document.createElement('div'); host.dataset.holstWidget = String(ME); host.style.cssText = 'all:initial;position:fixed;z-index:2147483646'; document.documentElement.appendChild(host);
      root = host.attachShadow({ mode: 'open' });
      root.innerHTML = `<style>
        .w{position:fixed;width:310px;height:380px;min-width:230px;min-height:150px;resize:both;overflow:hidden;display:flex;flex-direction:column;background:#fff;color:#1c1d21;border:1px solid #e3e5ea;border-radius:12px;box-shadow:0 12px 40px -12px rgba(0,0,0,.35);font:13px/1.35 system-ui,"Segoe UI",sans-serif}
        .h{display:flex;align-items:center;gap:5px;padding:6px 6px 6px 10px;background:#1c1d21;color:#fff;cursor:move;user-select:none}.h b{font-size:12.5px;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        .h button{border:0;background:rgba(255,255,255,.12);color:#fff;border-radius:6px;padding:3px 7px;font:600 11px system-ui;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;min-height:22px}.h button.on{background:#ffd84d;color:#1c1d21}.h button.i{width:24px;padding:0;background:transparent}.h button.i:hover{background:rgba(255,255,255,.14)}
        .l{flex:1;overflow:auto;padding:4px 6px}.r{display:flex;gap:7px;align-items:flex-start;padding:5px 4px;border-radius:7px}.r:hover{background:#f1f2f5}.r input{margin:2px 0 0}.r .d{width:9px;height:9px;border-radius:3px;margin:4px 2px 0;flex:none}.r span{flex:1;min-width:0}.r small{display:block;color:#8a90a0;font-size:11px}.r i{font-style:normal;font-size:10.5px;font-weight:700;color:#7c3aed;border:1px solid #d9ccff;border-radius:5px;padding:0 4px;flex:none;height:16px;line-height:14px}.r i.x{color:#e5484d;border-color:#f4b4b6}.dn span{text-decoration:line-through;color:#8a90a0}
        form{display:flex;gap:5px;padding:6px;border-top:1px solid #e3e5ea}form input{flex:1;min-width:0;height:30px;border:1px solid #e3e5ea;border-radius:8px;padding:0 8px;font:inherit}form select{height:30px;border:1px solid #e3e5ea;border-radius:8px;font:12px system-ui;padding:0 4px;background:#fff;color:inherit}form button{width:30px;height:30px;border:0;border-radius:8px;background:#1c1d21;color:#fff;cursor:pointer;display:inline-flex;align-items:center;justify-content:center}
        .e{color:#8a90a0;padding:12px 8px;font-size:12px}.min .l,.min form{display:none}.min{height:auto!important;resize:none}
        @media (prefers-color-scheme:dark){.w{background:#212329;color:#e6e7ea;border-color:#33363c}.r:hover{background:#2b2e35}form{border-color:#33363c}form input,form select{background:#2b2e35;color:#e6e7ea;border-color:#33363c}form button{background:#e6e7ea;color:#1c1d21}}
      </style><div class="w"><div class="h"><b>Холст</b><button data-a="page" title="Всё об этой странице">Эта страница</button><button data-a="all" title="Открытые задачи всего задачника">Всё</button><button class="i" data-a="min" title="Свернуть">${svg('min')}</button><button class="i" data-a="x" title="Скрыть на этом сайте">${svg('close')}</button></div><div class="l"></div><form><select title="Что добавить">${KINDS.map(([k, l]) => `<option value="${k}">${l}</option>`).join('')}</select><input placeholder="Добавить к этой странице"><button title="Добавить">${svg('plus')}</button></form></div>`;
      const w = root.querySelector('.w');
      w.style.left = (rule.x != null ? Math.min(rule.x, innerWidth - 80) : innerWidth - 340) + 'px'; w.style.top = (rule.y != null ? Math.min(rule.y, innerHeight - 40) : 90) + 'px'; if (rule.w) w.style.width = rule.w + 'px'; if (rule.h) w.style.height = rule.h + 'px'; if (rule.min) w.classList.add('min');
      if (rule.k) root.querySelector('form select').value = rule.k;
      root.querySelector('.h').addEventListener('pointerdown', e => {
        if (e.target.closest('button')) return; e.preventDefault(); const x0 = e.clientX - w.offsetLeft, y0 = e.clientY - w.offsetTop;
        const mv = ev => { w.style.left = Math.max(0, Math.min(innerWidth - 60, ev.clientX - x0)) + 'px'; w.style.top = Math.max(0, Math.min(innerHeight - 30, ev.clientY - y0)) + 'px'; };
        const up = () => { removeEventListener('pointermove', mv); removeEventListener('pointerup', up); rule.x = w.offsetLeft; rule.y = w.offsetTop; save(); };
        addEventListener('pointermove', mv); addEventListener('pointerup', up);
      });
      new ResizeObserver(() => { clearTimeout(w._t); w._t = setTimeout(() => { if (w.classList.contains('min')) return; rule.w = w.offsetWidth; rule.h = w.offsetHeight; save(); }, 400); }).observe(w);
      root.addEventListener('click', async e => {
        const b = e.target.closest('button[data-a]'); if (!b) return; const a = b.dataset.a;
        if (a === 'page' || a === 'all') { rule.mode = a; save(); load(); }
        else if (a === 'min') { w.classList.toggle('min'); rule.min = w.classList.contains('min') ? 1 : 0; save(); }
        else if (a === 'x') { rule.on = 0; save(); host.remove(); host = null; }
      });
      root.addEventListener('change', async e => { if (e.target.matches('form select')) { rule.k = e.target.value; save(); return; } const c = e.target.closest('input[data-id]'); if (!c) return; await bg('set', { id: c.dataset.id, patch: { st: c.checked ? 'done' : 'todo' } }); load(); });
      root.querySelector('form').addEventListener('submit', async e => { e.preventDefault(); const i = e.target.querySelector('input'), t = i.value.trim(); if (!t) return; i.value = ''; await bg('add', { k: e.target.querySelector('select').value, title: t, url: location.href, site: location.hostname, v217: 1 }); load(); });
    }
    load();
  }
  async function load() {
    if (!root || !alive()) return;
    root.querySelectorAll('button[data-a="page"],button[data-a="all"]').forEach(b => b.classList.toggle('on', b.dataset.a === rule.mode));
    const l = root.querySelector('.l'); l.innerHTML = '<div class="e">Загружаю из Холста…</div>';
    let r = null; for (let k = 0; k < 3 && !(r && r.ok); k++) { if (k) await new Promise(ok => setTimeout(ok, 2500)); if (!alive()) return; r = await bg('list', { mode: rule.mode, url: location.href, scope: rule.scope, v217: 1 }).catch(() => null); }
    if (!r || !r.ok) { l.innerHTML = '<div class="e">Холст не ответил. Откройте Холст во вкладке — расширение подхватит.</div>'; return; }
    list = r.data || []; const col = k => (KINDS.find(x => x[0] === k) || ['', '', '#8a90a0'])[2];
    l.innerHTML = list.length ? list.map(t => `<label class="r${t.st === 'done' ? ' dn' : ''}">${t.k === 'task' || !t.k ? `<input type="checkbox" data-id="${t.id}"${t.st === 'done' ? ' checked' : ''}>` : `<span class="d" style="background:${col(t.k)}" title="${esc(t.kn || '')}"></span>`}<span>${esc(t.t)}<small>${[t.k && t.k !== 'task' ? t.kn : '', t.due, t.par, t.hl ? 'цитат: ' + t.hl : ''].filter(Boolean).map(esc).join(' · ')}</small></span>${t.imp ? `<i class="${t.imp === '11' ? 'x' : ''}" title="Важность">${esc(t.imp)}</i>` : ''}</label>`).join('') : `<div class="e">${rule.mode === 'page' ? 'Об этой странице в Холсте пока ничего. Добавьте ниже — задачу, заметку, материал…' : 'Открытых задач нет.'}</div>`;
  }
  const esc = s => String(s || '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  chrome.runtime.onMessage.addListener(m => { if (alive() && m && m.op === 'widget-refresh') mount(); });
  /* sites that change pages without reloading (YouTube, Notion, Gmail…) — the widget follows */
  let href = location.href; const t = setInterval(() => { if (!alive()) { clearInterval(t); return; } if (location.href !== href) { href = location.href; mount(); } }, 1000);
  addEventListener('popstate', () => alive() && mount()); document.addEventListener('yt-navigate-finish', () => alive() && mount());
  mount();
})();
